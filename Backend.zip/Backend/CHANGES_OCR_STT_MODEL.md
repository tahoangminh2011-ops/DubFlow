# FlowAI OCR/STT separation update

- STT and OCR are independent pipeline branches. STT never calls OCR/fusion.
- OCR mode never extracts audio or calls STT.
- Legacy PP-OCRv5 remains local and one worker.
- Added xKiro Vision OCR with up to 8 keys / 8 parallel workers.
- xKiro OCR sees only the selected ROI image and returns subtitle text; no audio is sent.
- Added live xKiro model catalog endpoint: `/api/models?modality=all`.
- Added per-stage model fields: STT, OCR, translation, TTS, and full catalog.
- Model catalog is live rather than hardcoded, so vendor/model additions are picked up from xKiro's catalog.
- Timeline values are source-frame based; normal 25/30fps video gives frame quantization below 0.1s.

Important: no OCR implementation can honestly guarantee 100% recognition or a fixed 5-10 minute runtime for every arbitrary 2-hour video. The implementation is designed for high recall and parallel throughput, but actual speed/accuracy depends on resolution, subtitle style, GPU/CPU, network, model latency, and provider rate limits.
