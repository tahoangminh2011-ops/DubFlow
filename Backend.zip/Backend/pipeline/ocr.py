"""Local hard-subtitle OCR with a frame-locked master timeline.

OCR mode is intentionally image-only:
    VIDEO -> ROI -> OCR detections -> subtitle tracks -> frame boundaries -> SRT

No STT/audio/translation text is used to create, repair, or time OCR subtitles.
The implementation keeps OCR bounding boxes so watermark/background text can be
filtered spatially and temporally instead of blindly concatenating every OCR box.
"""
from __future__ import annotations

import concurrent.futures
import difflib
import logging
import math
import os
import re
import threading
import time
import queue
import base64
import json
import requests
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence, Tuple

import cv2
import numpy as np

try:
    from . import config
except Exception:  # pragma: no cover
    import config  # type: ignore

log = logging.getLogger(__name__)

# Keep the OCR worker lightweight on 8 GB RAM / mobile-CPU systems.
OCR_CPU_THREADS = max(1, min(4, int(os.getenv("OCR_CPU_THREADS", "1"))))
try:
    cv2.setNumThreads(OCR_CPU_THREADS)
except Exception:
    pass
for _env_name in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS"):
    os.environ.setdefault(_env_name, str(OCR_CPU_THREADS))

try:
    import psutil  # optional; used only as a CPU safety governor
except Exception:  # pragma: no cover
    psutil = None

# ---------------------------------------------------------------------------
# Configuration. Accuracy is preferred over the old candidate-heavy pipeline.
# The cheap ROI scan is decoded by parallel FFmpeg workers; OCR is only run
# around likely transitions and sparse recovery checkpoints.
# ---------------------------------------------------------------------------
SCAN_FPS = max(1.0, min(15.0, float(os.getenv("OCR_SCAN_FPS", "12.0"))))
SCAN_WIDTH = max(320, min(640, int(os.getenv("OCR_SCAN_WIDTH", "320"))))
SCAN_DIFF_THRESHOLD = float(os.getenv("OCR_DIFF_THRESHOLD", "0.012"))
SCAN_MIN_GAP = max(0.08, float(os.getenv("OCR_CANDIDATE_GAP", "0.10")))
SCAN_CHECKPOINT = float(os.getenv("OCR_CHECKPOINT_SECONDS", "0"))
SCAN_LOCAL_MAX_RADIUS = max(1, int(os.getenv("SCAN_LOCAL_MAX_RADIUS", "1")))
# Dense source-time OCR sampling: prevents transition-only scanning from skipping short cues.
OCR_TIMELINE_FPS = max(2.0, min(15.0, float(os.getenv("OCR_TIMELINE_FPS", "15.0"))))
OCR_DENSE_TIMELINE = os.getenv("OCR_DENSE_TIMELINE", "1").strip().lower() not in {"0", "false", "no", "off"}
# Long-video fast mode: avoid 15-FPS OCR on hours-long sources. Transition scan still checks the ROI; OCR verifies only likely subtitle changes.
OCR_FAST_LONG_VIDEO = os.getenv("OCR_FAST_LONG_VIDEO", "1").strip().lower() not in {"0", "false", "no", "off"}
OCR_FAST_LONG_SECONDS = max(600.0, float(os.getenv("OCR_FAST_LONG_SECONDS", "1800")))
OCR_FAST_LONG_RECOVERY_SECONDS = max(0.75, float(os.getenv("OCR_FAST_LONG_RECOVERY_SECONDS", "1.0")))
OCR_FAST_LONG_CANDIDATE_GAP = max(0.25, float(os.getenv("OCR_FAST_LONG_CANDIDATE_GAP", "0.10")))
OCR_FAST_LONG_BOUNDARY_FPS = max(2.0, min(8.0, float(os.getenv("OCR_FAST_LONG_BOUNDARY_FPS", "6.0"))))
OCR_FAST_LONG_BOUNDARY_RADIUS = max(0.20, min(0.60, float(os.getenv("OCR_FAST_LONG_BOUNDARY_RADIUS", "0.25"))))

OCR_MIN_CONF = float(os.getenv("PP_OCR_MIN_CONF", "0.10"))
OCR_MAX_TEXT = int(os.getenv("OCR_MAX_TEXT", "220"))
OCR_MIN_CHARS = int(os.getenv("OCR_MIN_CHARS", "1"))
OCR_PROBE_OFFSETS = tuple(float(x.strip()) for x in os.getenv("PP_OCR_PROBE_OFFSETS", "-0.10,0.0,0.10").split(",") if x.strip())
OCR_FAST_LONG_PROBE_OFFSETS = tuple(float(x.strip()) for x in os.getenv("OCR_FAST_LONG_PROBE_OFFSETS", "-0.10,0.0,0.10").split(",") if x.strip())
OCR_WORKERS = max(1, min(2, int(os.getenv("PP_OCR_WORKERS", "2"))))
OCR_BACKEND = os.getenv("OCR_BACKEND", "auto").strip().lower() or "auto"
OCR_LANG = os.getenv("PP_OCR_LANG", "ch").strip() or "ch"
OCR_MODEL_DIR = os.getenv("PP_OCR_MODEL_DIR", "").strip()
OCR_RETRY_PASSES = max(1, min(4, int(os.getenv("OCR_RETRY_PASSES", "1"))))
OCR_BOUNDARY_RADIUS = float(os.getenv("OCR_BOUNDARY_RADIUS", "0.60"))
OCR_BOUNDARY_FPS = float(os.getenv("OCR_BOUNDARY_FPS", "12"))
OCR_SIMILARITY = float(os.getenv("OCR_TEXT_SIMILARITY", "0.84"))
OCR_STATIC_OCCUPANCY = float(os.getenv("OCR_STATIC_OCCUPANCY", "0.96"))
OCR_STATIC_CHANGE_MAX = float(os.getenv("OCR_STATIC_CHANGE_MAX", "0.08"))
OCR_MIN_TRACK_OBS = int(os.getenv("OCR_MIN_TRACK_OBS", "2"))
OCR_EXPECTED_SUBTITLE_Y = float(os.getenv("OCR_EXPECTED_SUBTITLE_Y", "0.78"))
OCR_SUBTITLE_Y_MIN = float(os.getenv("OCR_SUBTITLE_Y_MIN", "0.0"))
OCR_ADAPTIVE_POSITION = False  # Frontend ROI is authoritative; never move or expand the user-selected ROI.
OCR_STATE_CONFIRM_WINDOW = float(os.getenv("OCR_STATE_CONFIRM_WINDOW", "0.45"))
OCR_USE_GPU = "0"  # CPU-only build: ignore GPU environment overrides
# CUDA device ordinal is among CUDA/NVIDIA devices, not Windows Task Manager GPU labels.
OCR_CUDA_DEVICE_ID = max(0, int(os.getenv("OCR_CUDA_DEVICE_ID", "0")))
OCR_GPU_REQUIRED = False  # CPU-only build
OCR_VARIANTS = max(1, min(2, int(os.getenv("OCR_VARIANTS", "1"))))
OCR_CPU_TARGET = max(10.0, min(100.0, float(os.getenv("OCR_CPU_TARGET", "60"))))
OCR_GPU_TARGET = max(10.0, min(100.0, float(os.getenv("OCR_GPU_TARGET", "50"))))
# CPU-fast detector: never upscale a thin subtitle ROI to 736px on its short side.
# RapidOCR\'s default Det.limit_type="min" would otherwise massively enlarge a
# 1024x60-ish subtitle strip before detection, which is a major CPU bottleneck.
OCR_DET_MAX_SIDE = int(os.getenv("OCR_DET_MAX_SIDE", "1280"))
# ROI scan uses multiple independent FFmpeg processes. The legacy
# OCR_SCAN_FFMPEG_THREADS environment variable is retained as the worker-count
# control so existing manual settings such as 12 continue to mean "12 scan
# workers". Each worker uses one FFmpeg decode thread by default, avoiding the
# accidental 12x12=144-thread explosion that would happen if every process also
# used 12 internal threads.
_scan_workers_value = os.getenv("OCR_SCAN_WORKERS", os.getenv("OCR_SCAN_FFMPEG_THREADS", "12"))
OCR_SCAN_WORKERS = max(1, min(12, int(_scan_workers_value)))
OCR_SCAN_FFMPEG_THREADS = max(1, min(2, int(os.getenv("OCR_SCAN_FFMPEG_THREADS_PER_WORKER", "1"))))
OCR_SCAN_OVERLAP = max(0.10, min(1.00, float(os.getenv("OCR_SCAN_OVERLAP", "0.50"))))
OCR_SCAN_QUEUE_SIZE = max(4, min(32, int(os.getenv("OCR_SCAN_QUEUE_SIZE", "8"))))
OCR_SCAN_CPU_TARGET = max(30.0, min(69.0, float(os.getenv("OCR_SCAN_CPU_TARGET", "68"))))
OCR_SCAN_CPU_CHECK_EVERY = max(5, int(os.getenv("OCR_SCAN_CPU_CHECK_EVERY", "15")))
OCR_SCAN_CPU_MAX_SLEEP = max(0.02, min(0.50, float(os.getenv("OCR_SCAN_CPU_MAX_SLEEP", "0.10"))))
OCR_RETRY_CONF = float(os.getenv("OCR_RETRY_CONF", "0.45"))
OCR_RETRY_OFFSETS = tuple(float(x.strip()) for x in os.getenv("OCR_RETRY_OFFSETS", "-0.16,0.16").split(",") if x.strip())

_BOUNDARY_READER = threading.local()

_ENGINE_LOCK = threading.Lock()
_ENGINE = None
_ENGINE_NAME = "uninitialized"
_LAST_AUDIT: Dict[str, Any] = {}
_CPU_CHECK_EVERY = 1  # enforce resource checks after every scan/OCR operation
_cpu_check_counter = 0

_BAD_ONLY = re.compile(r"^[\W_]+$", re.UNICODE)
_SPACE_RE = re.compile(r"\s+")
_REPEAT_RE = re.compile(r"(.)\1{5,}", re.UNICODE)


class _RapidOCREmptyDetectionFilter(logging.Filter):
    """Hide only RapidOCR's noisy per-frame empty-detection warning.

    Empty detections are normal for video frames without subtitles. Do not hide
    other warnings/errors, and do not alter OCR results or exception handling.
    """
    _message = "The text detection result is empty"

    def filter(self, record: logging.LogRecord) -> bool:
        try:
            msg = record.getMessage()
        except Exception:
            return True
        # Match the exact, library-specific message regardless of the logger
        # name chosen by different RapidOCR releases.
        if self._message in msg:
            return False
        return True


def _install_rapidocr_empty_warning_filter() -> None:
    """Filter only RapidOCR's repeated empty-detection warning.

    Install on handlers currently present (including application-owned handlers)
    and on RapidOCR loggers. Called both after engine initialization and just
    before inference because some applications attach console handlers later.
    Other warnings/errors and all OCR return values are preserved.
    """
    filt = _RapidOCREmptyDetectionFilter()
    try:
        manager = logging.Logger.manager.loggerDict
        loggers = [logging.getLogger()]
        for name, obj in list(manager.items()):
            if isinstance(obj, logging.Logger):
                loggers.append(obj)
                if "rapidocr" in str(name).lower():
                    if not any(isinstance(f, _RapidOCREmptyDetectionFilter) for f in obj.filters):
                        obj.addFilter(filt)
        seen = set()
        for logger_obj in loggers:
            for handler in list(logger_obj.handlers):
                if id(handler) in seen:
                    continue
                seen.add(id(handler))
                if not any(isinstance(f, _RapidOCREmptyDetectionFilter) for f in handler.filters):
                    handler.addFilter(filt)
    except Exception:
        # Log filtering must never break OCR.
        pass

    # RapidOCR versions using Loguru may bypass stdlib handlers. Wrap each sink's
    # filter without removing sinks or changing their existing filtering rules.
    try:
        from loguru import logger as _loguru_logger  # type: ignore
        core_handlers = getattr(getattr(_loguru_logger, "_core", None), "handlers", {})
        for handler in list(core_handlers.values()):
            if getattr(handler, "_lingvo_empty_filter", False):
                continue
            old_filter = getattr(handler, "_filter", None)
            def _combined_loguru_filter(record, _old=old_filter):
                try:
                    if _RapidOCREmptyDetectionFilter._message in str(record.get("message", "")):
                        return False
                except Exception:
                    pass
                if _old is None:
                    return True
                try:
                    return bool(_old(record))
                except Exception:
                    return True
            handler._filter = _combined_loguru_filter
            handler._lingvo_empty_filter = True
    except Exception:
        pass


def _recognition_language(lang_rec_enum: Any, requested: str) -> Any:
    """Resolve common language aliases to RapidOCR recognition enums.

    The previous implementation always selected Chinese recognition even when
    PP_OCR_LANG requested another language, silently hurting Latin subtitles.
    """
    key = re.sub(r"[^a-z]", "", str(requested or "ch").lower())
    aliases = {
        "ch": ("CH",), "zh": ("CH",), "chinese": ("CH",),
        "en": ("LATIN", "EN"), "english": ("LATIN", "EN"),
        "latin": ("LATIN", "EN"), "vi": ("LATIN", "EN"),
        "vietnamese": ("LATIN", "EN"), "fr": ("LATIN", "EN"),
        "es": ("LATIN", "EN"), "de": ("LATIN", "EN"),
        "it": ("LATIN", "EN"), "pt": ("LATIN", "EN"),
        "tr": ("LATIN", "EN"), "ru": ("CYRILLIC",),
        "cyrillic": ("CYRILLIC",), "ja": ("JAPANESE", "JP"),
        "japanese": ("JAPANESE", "JP"), "ko": ("KOREAN",),
        "korean": ("KOREAN",), "ar": ("ARABIC",), "arabic": ("ARABIC",),
        "th": ("THAI",), "thai": ("THAI",),
        "hi": ("DEVANAGARI",), "hindi": ("DEVANAGARI",),
    }
    for candidate in aliases.get(key, (str(requested or "CH").upper(), "CH")):
        try:
            return getattr(lang_rec_enum, candidate)
        except Exception:
            continue
    return getattr(lang_rec_enum, "CH")


def get_last_audit() -> Dict[str, Any]:
    return dict(_LAST_AUDIT)


def _set_audit(**values: Any) -> None:
    global _LAST_AUDIT
    _LAST_AUDIT = dict(values)


def _read_gpu_utilization() -> Optional[float]:
    """Best-effort whole-NVIDIA-GPU utilization from nvidia-smi; None if unavailable."""
    try:
        import subprocess
        result = subprocess.run(
            ["nvidia-smi", "--query-gpu=utilization.gpu", "--format=csv,noheader,nounits"],
            capture_output=True, text=True, timeout=0.7, check=False,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        if result.returncode != 0:
            return None
        vals = [float(line.strip()) for line in result.stdout.splitlines() if line.strip()]
        return max(vals) if vals else None
    except Exception:
        return None


def _cpu_yield(seconds: float = 0.03) -> None:
    """Best-effort CPU/NVIDIA utilization governor, checked after every operation.

    When system CPU or the NVIDIA GPU is above its configured target, pause the
    OCR pipeline and poll again. This limits sustained load rather than trying
    to cap hardware clocks; short spikes and load from other applications remain
    outside the process's control.
    """
    global _cpu_check_counter
    _cpu_check_counter += 1
    try:
        cpu_usage = float(psutil.cpu_percent(interval=0.0)) if psutil is not None else None
    except Exception:
        cpu_usage = None

    gpu_enabled = OCR_USE_GPU in {"1", "true", "yes", "cuda", "gpu", "auto"}
    gpu_usage = _read_gpu_utilization() if gpu_enabled else None
    # Bound the wait so unrelated GPU applications cannot freeze OCR forever.
    max_wait = max(1.0, min(12.0, float(os.getenv("OCR_GOVERNOR_MAX_WAIT", "8"))))
    poll_interval = max(0.20, min(1.0, float(os.getenv("OCR_GOVERNOR_POLL_SECONDS", "0.5"))))
    waited = 0.0

    while waited < max_wait:
        over_cpu = cpu_usage is not None and cpu_usage > OCR_CPU_TARGET
        over_gpu = gpu_usage is not None and gpu_usage > OCR_GPU_TARGET
        if not (over_cpu or over_gpu):
            return

        # Longer idle when significantly over target; re-check to avoid sleeping
        # blindly for a long period after the load has already dropped.
        excess = max(
            (cpu_usage - OCR_CPU_TARGET) if over_cpu else 0.0,
            (gpu_usage - OCR_GPU_TARGET) if over_gpu else 0.0,
        )
        delay = max(seconds, min(poll_interval, 0.20 + excess / 100.0))
        delay = min(delay, max_wait - waited)
        time.sleep(delay)
        waited += delay
        try:
            cpu_usage = float(psutil.cpu_percent(interval=0.0)) if psutil is not None else None
        except Exception:
            cpu_usage = None
        gpu_usage = _read_gpu_utilization() if gpu_enabled else None

    # Keep the log useful without claiming a hard cap; another app may be using
    # the GPU, or Windows may report a different engine than nvidia-smi.
    log.warning(
        "[OCR RESOURCE] Vẫn vượt mục tiêu sau %.1fs | CPU=%s%% (mục tiêu %.0f%%) | NVIDIA GPU=%s%% (mục tiêu %.0f%%). Tạm tiếp tục để tránh treo OCR.",
        waited,
        f"{cpu_usage:.0f}" if cpu_usage is not None else "không đo được",
        OCR_CPU_TARGET,
        f"{gpu_usage:.0f}" if gpu_usage is not None else "không đo được",
        OCR_GPU_TARGET,
    )

def _available_ort_providers() -> List[str]:
    """Return providers installed in the active Python environment."""
    try:
        import onnxruntime as ort
        return list(ort.get_available_providers())
    except Exception:
        return []


def _engine_session_providers(engine: Any, max_depth: int = 5) -> List[List[str]]:
    """Best-effort inspect ONNX sessions created by RapidOCR.

    Available providers alone do not prove a model session actually uses CUDA.
    RapidOCR internals differ between releases, so inspect reachable objects
    conservatively and never fail OCR if a session is not introspectable.
    """
    found: List[List[str]] = []
    seen = set()
    queue = [(engine, 0)]
    while queue:
        obj, depth = queue.pop(0)
        if obj is None or id(obj) in seen or depth > max_depth:
            continue
        seen.add(id(obj))
        get_providers = getattr(obj, "get_providers", None)
        if callable(get_providers):
            try:
                providers = list(get_providers())
                if providers:
                    found.append([str(x) for x in providers])
            except Exception:
                pass
            continue
        if isinstance(obj, dict):
            children = list(obj.values())
        elif isinstance(obj, (list, tuple, set)):
            children = list(obj)
        else:
            try:
                children = list(vars(obj).values())
            except Exception:
                children = []
        for child in children:
            if child is not None and (isinstance(child, (dict, list, tuple, set)) or hasattr(child, "__dict__") or callable(getattr(child, "get_providers", None))):
                queue.append((child, depth + 1))
    # De-duplicate while preserving discovery order.
    unique: List[List[str]] = []
    for providers in found:
        if providers not in unique:
            unique.append(providers)
    return unique

def _video_meta(path: Path) -> Tuple[float, float, int, int]:
    cap = cv2.VideoCapture(str(path))
    if not cap.isOpened():
        raise RuntimeError(f"Không mở được video: {path}")
    fps = float(cap.get(cv2.CAP_PROP_FPS) or 25.0)
    n = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 0)
    h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 0)
    cap.release()
    if fps <= 0:
        fps = 25.0
    duration = n / fps if n > 0 else 0.0
    if duration <= 0:
        try:
            import subprocess
            p = subprocess.run([
                getattr(config, "FFPROBE_PATH", "ffprobe"), "-v", "error",
                "-show_entries", "format=duration", "-of", "default=nw=1:nk=1", str(path)
            ], capture_output=True, text=True, timeout=20)
            duration = float((p.stdout or "").strip())
        except Exception:
            duration = 0.0
    return duration, fps, w, h


def _roi_pixels(region: Dict[str, float], w: int, h: int) -> Tuple[int, int, int, int]:
    """Convert the frontend's percentage rectangle into clamped pixel bounds.

    Zero is a valid coordinate. Never use ``value or default`` here: that turns
    y=0 into the old 72%-down default and makes the displayed ROI disagree with
    the actual crop sent to OCR.
    """
    def number(key, alias, default):
        value = region.get(key, region.get(alias, default))
        try:
            return float(default if value is None else value)
        except (TypeError, ValueError):
            return float(default)
    x = max(0.0, min(100.0, number("x", "x", 0)))
    y = max(0.0, min(100.0, number("y", "y", 72)))
    rw = max(0.1, min(100.0 - x, number("w", "width", 100)))
    rh = max(0.1, min(100.0 - y, number("h", "height", 25)))
    if w <= 1 or h <= 1:
        raise ValueError(f"Kích thước video không hợp lệ: {w}x{h}")
    x0 = max(0, min(w - 1, int(round(w * x / 100.0))))
    y0 = max(0, min(h - 1, int(round(h * y / 100.0))))
    x1 = max(x0 + 1, min(w, int(round(w * (x + rw) / 100.0))))
    y1 = max(y0 + 1, min(h, int(round(h * (y + rh) / 100.0))))
    return x0, y0, x1, y1


def _write_debug_image(path: Path, image: np.ndarray) -> bool:
    """Write a PNG even when the Windows path contains non-ASCII characters."""
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        ok, encoded = cv2.imencode(".png", image)
        if not ok:
            return False
        encoded.tofile(str(path))
        return True
    except Exception as exc:
        log.warning("[OCR DIAGNOSTIC] Không lưu được ảnh %s: %s", path, exc)
        return False


def _run_roi_diagnostic(
    path: Path,
    region: Dict[str, float],
    duration: float,
    fps: float,
    frame_size: Tuple[int, int],
    roi_pixels: Tuple[int, int, int, int],
) -> None:
    """Save one real source frame + exact ROI and test OCR once, then stop."""
    requested_time = max(0.0, min(
        max(0.0, duration - 0.02),
        float(os.getenv("OCR_DIAGNOSTIC_TIME", "1.0") or 1.0),
    ))
    cap = cv2.VideoCapture(str(path))
    if not cap.isOpened():
        raise RuntimeError(f"[OCR DIAGNOSTIC] Không mở được video: {path}")
    try:
        frame_no = max(0, int(round(requested_time * max(fps, 1.0))))
        cap.set(cv2.CAP_PROP_POS_FRAMES, frame_no)
        ok, frame = cap.read()
    finally:
        cap.release()
    if not ok or frame is None or frame.size == 0:
        raise RuntimeError(f"[OCR DIAGNOSTIC] Không đọc được frame tại {requested_time:.3f}s")

    x0, y0, x1, y1 = roi_pixels
    roi = frame[y0:y1, x0:x1].copy()
    if roi.size == 0:
        raise RuntimeError(
            f"[OCR DIAGNOSTIC] ROI rỗng: {roi_pixels}, frame={frame.shape[1]}x{frame.shape[0]}"
        )

    stem = path.stem
    frame_path = path.with_name(f"{stem}_ocr_diag_frame.png")
    roi_path = path.with_name(f"{stem}_ocr_diag_roi.png")
    zoom_path = path.with_name(f"{stem}_ocr_diag_roi_3x.png")
    report_path = path.with_name(f"{stem}_ocr_diag.txt")

    marked = frame.copy()
    cv2.rectangle(marked, (x0, y0), (max(x0, x1 - 1), max(y0, y1 - 1)), (0, 255, 0), 3)
    _write_debug_image(frame_path, marked)
    _write_debug_image(roi_path, roi)
    zoom = cv2.resize(
        roi,
        (max(1, roi.shape[1] * 3), max(1, roi.shape[0] * 3)),
        interpolation=cv2.INTER_CUBIC,
    )
    _write_debug_image(zoom_path, zoom)

    # Run the same local OCR function against exactly the saved ROI.
    detections = _ocr_image(roi)
    report = [
        "OCR ROI diagnostic",
        f"video={path}",
        f"sample_time_seconds={requested_time:.3f}",
        f"sample_frame={frame_no}",
        f"frame_size={frame.shape[1]}x{frame.shape[0]}",
        f"roi_percent={region}",
        f"roi_pixels={roi_pixels}",
        f"roi_size={roi.shape[1]}x{roi.shape[0]}",
        f"roi_mean_bgr={np.mean(roi, axis=(0, 1)).round(2).tolist()}",
        f"roi_std_bgr={np.std(roi, axis=(0, 1)).round(2).tolist()}",
        f"ocr_engine={_ENGINE_NAME}",
        f"detection_count={len(detections)}",
        "detections=" + repr([
            {"text": d.get("text", ""), "confidence": round(float(d.get("confidence", 0.0)), 4),
             "bbox": [round(float(v), 2) for v in d.get("bbox", [])]}
            for d in detections[:30]
        ]),
        f"marked_frame={frame_path}",
        f"roi_image={roi_path}",
        f"roi_zoom={zoom_path}",
    ]
    report_path.write_text("\n".join(report) + "\n", encoding="utf-8")
    log.warning(
        "[OCR DIAGNOSTIC] Kết thúc chẩn đoán nhanh; không quét video. "
        "ROI=%s ROIpx=%s size=%dx%d detections=%d report=%s",
        region, roi_pixels, roi.shape[1], roi.shape[0], len(detections), report_path,
    )
    log.warning("[OCR DIAGNOSTIC] Ảnh ROI: %s | ảnh full-frame đánh dấu: %s", roi_path, frame_path)


def _normalize(text: str) -> str:
    s = str(text or "").replace("\u200b", " ").replace("\ufeff", " ")
    s = _SPACE_RE.sub(" ", s).strip()
    s = re.sub(r"^[|¦•·~`^_=+*#@$%\\/]+", "", s)
    s = re.sub(r"[|¦•·~`^_=+*#@$%\\/]+$", "", s).strip()
    return s[:OCR_MAX_TEXT]


def _looks_like_environment_glyph_noise(text: str) -> bool:
    """Reject isolated Latin glyphs / keyboard-like letter rows, not subtitle words.

    These are commonly picked up from UI overlays, game controls, keyboard hints,
    signs, or scene graphics when OCR is meant to read hard subtitles only.
    """
    s = _normalize(text)
    if not s:
        return True
    # A row made entirely of single Latin letters (e.g. "A B C D V B N M").
    if re.fullmatch(r"(?:[A-Za-z](?:\s+|$)){1,16}", s):
        return True
    # Tiny all-caps labels are usually HUD / environment noise, not dialogue.
    if re.fullmatch(r"[A-Z]{1,2}", s):
        return True
    # Very short mixed letter/digit tokens (e.g. 3J, 7B, A1) are usually
    # UI/HUD artifacts. Keep normal 3+ character words and standalone numbers.
    compact = re.sub(r"\s+", "", s)
    if len(compact) <= 2 and re.fullmatch(r"(?=.*[A-Za-z])(?=.*\d)[A-Za-z0-9]+", compact):
        return True
    # Isolated decorative OCR symbols should not become subtitle cues.
    if len(compact) <= 2 and not any(ch.isalpha() for ch in compact) and not any(ch.isdigit() for ch in compact):
        return True
    return False


def _text_similarity(a: str, b: str) -> float:
    aa = _normalize(a).casefold()
    bb = _normalize(b).casefold()
    if aa == bb:
        return 1.0
    if not aa or not bb:
        return 0.0
    compact_a = re.sub(r"\s+", "", aa)
    compact_b = re.sub(r"\s+", "", bb)
    return max(
        difflib.SequenceMatcher(None, aa, bb).ratio(),
        difflib.SequenceMatcher(None, compact_a, compact_b).ratio(),
    )


def _quality(text: str, conf: float) -> float:
    s = _normalize(text)
    if not s or _BAD_ONLY.fullmatch(s) or _REPEAT_RE.search(s):
        return 0.0
    chars = [c for c in s if c.isalnum()]
    if len(chars) < OCR_MIN_CHARS:
        return 0.0
    weird = sum(1 for c in s if not c.isalnum() and not c.isspace() and c not in ".,!?;:'\"-()[]{}%&+/…，。！？：；（）【】《》“”‘’、·")
    if weird / max(1, len(s)) > 0.45:
        return 0.0
    return max(0.0, min(1.0, float(conf or 0.0)))


def _box_to_xyxy(box: Any) -> Optional[Tuple[float, float, float, float]]:
    try:
        arr = np.asarray(box, dtype=np.float32)
        if arr.size >= 8:
            arr = arr.reshape(-1, 2)
            return float(arr[:, 0].min()), float(arr[:, 1].min()), float(arr[:, 0].max()), float(arr[:, 1].max())
        if arr.size >= 4:
            a = arr.reshape(-1)[:4]
            x0, y0, x1, y1 = map(float, a)
            return min(x0, x1), min(y0, y1), max(x0, x1), max(y0, y1)
    except Exception:
        return None
    return None


def _make_engine():
    global _ENGINE, _ENGINE_NAME
    if _ENGINE is not None:
        return _ENGINE, _ENGINE_NAME
    with _ENGINE_LOCK:
        if _ENGINE is not None:
            return _ENGINE, _ENGINE_NAME
        errors = []

        # Preferred path on Windows/NVIDIA: RapidOCR + PP-OCRv5 mobile through
        # ONNX Runtime. CUDA is optional; CPU fallback is deliberately limited to
        # a small number of threads so the whole machine stays responsive.
        if OCR_BACKEND in {"auto", "rapid", "rapidocr"}:
            try:
                # Install a narrow warning filter; do not disable the whole library logger.
                _install_rapidocr_empty_warning_filter()
                from rapidocr import (
                    RapidOCR, EngineType, LangDet, LangRec, ModelType, OCRVersion
                )
                use_cuda = False  # CPU-only build: never request CUDA for OCR
                # RapidOCR >= 3.x validates these fields as Enum instances, not strings.
                # Using the official enum types also keeps this compatible with PP-OCRv5.
                params = {
                    "Global.text_score": 0.18,
                    "Global.use_cls": False,
                    "Global.use_vertical_padding": False,
                    "Global.min_height": 32,
                    "Det.engine_type": EngineType.ONNXRUNTIME,
                    "Det.lang_type": LangDet.CH,
                    "Det.model_type": ModelType.MOBILE,
                    "Det.ocr_version": OCRVersion.PPOCRV5,
                    "Det.limit_side_len": OCR_DET_MAX_SIDE,
                    "Det.limit_type": "max",
                    "Det.box_thresh": 0.28,
                    "Det.max_candidates": 200,
                    "Rec.engine_type": EngineType.ONNXRUNTIME,
                    "Rec.lang_type": _recognition_language(LangRec, OCR_LANG),
                    "Rec.model_type": ModelType.MOBILE,
                    "Rec.ocr_version": OCRVersion.PPOCRV5,
                    "EngineConfig.onnxruntime.intra_op_num_threads": OCR_CPU_THREADS,
                    "EngineConfig.onnxruntime.inter_op_num_threads": 1,
                    "EngineConfig.onnxruntime.use_cuda": use_cuda,
                    "EngineConfig.onnxruntime.cuda_ep_cfg.device_id": OCR_CUDA_DEVICE_ID,
                    "EngineConfig.onnxruntime.cuda_ep_cfg.do_copy_in_default_stream": True,
                }
                providers = _available_ort_providers()
                log.info(
                    "[OCR GPU] request_cuda=%s | available_providers=%s | cuda_device_id=%s",
                    use_cuda, providers or "unavailable", OCR_CUDA_DEVICE_ID,
                )
                if use_cuda and "CUDAExecutionProvider" not in providers:
                    log.warning(
                        "[OCR GPU] CUDA được yêu cầu nhưng ONNX Runtime không có CUDAExecutionProvider; OCR có thể chạy CPU."
                    )
                _ENGINE = RapidOCR(params=params)
                # RapidOCR may configure/reset its logger during construction;
                # install a narrow message filter after initialization as well.
                _install_rapidocr_empty_warning_filter()
                session_providers = _engine_session_providers(_ENGINE)
                if session_providers:
                    cuda_active = any("CUDAExecutionProvider" in p for p in session_providers)
                    log.info("[OCR GPU] session_providers=%s", session_providers)
                    if use_cuda and OCR_GPU_REQUIRED and not cuda_active:
                        raise RuntimeError(
                            "GPU bắt buộc nhưng session RapidOCR chỉ có CPU provider. "
                            "Không tiếp tục âm thầm bằng CPU. Kiểm tra CUDA/cuDNN và cấu hình RapidOCR/ONNX Runtime. "
                            f"session_providers={session_providers}; available_providers={providers}"
                        )
                    _ENGINE_NAME = (
                        "RapidOCR-PP-OCRv5-mobile-CUDA" if cuda_active
                        else "RapidOCR-PP-OCRv5-mobile-CPU"
                    )
                elif use_cuda and "CUDAExecutionProvider" in providers:
                    # CUDA is configured and installed, but this RapidOCR version
                    # does not expose its internal sessions for direct inspection.
                    _ENGINE_NAME = "RapidOCR-PP-OCRv5-mobile-CUDA-requested-unverified"
                    log.warning(
                        "[OCR GPU] CUDA đã được yêu cầu và provider có sẵn, nhưng không đọc được provider của session; cần kiểm tra GPU thực tế khi chạy."
                    )
                else:
                    _ENGINE_NAME = "RapidOCR-PP-OCRv5-mobile-CPU"
                return _ENGINE, _ENGINE_NAME
            except Exception as exc:
                errors.append(f"RapidOCR: {exc}")
                if OCR_BACKEND not in {"auto"}:
                    raise RuntimeError("Không khởi tạo được RapidOCR: " + str(exc)) from exc

        # Compatibility fallback for environments that still carry PaddleOCR.
        if OCR_BACKEND in {"auto", "paddle", "paddleocr"}:
            try:
                from paddleocr import PaddleOCR
                kwargs: Dict[str, Any] = dict(
                    ocr_version="PP-OCRv5",
                    text_detection_model_name="PP-OCRv5_mobile_det",
                    text_recognition_model_name="PP-OCRv5_mobile_rec",
                    lang=OCR_LANG,
                    device="cpu",
                    use_doc_orientation_classify=False,
                    use_doc_unwarping=False,
                    use_textline_orientation=False,
                )
                if OCR_MODEL_DIR:
                    kwargs["text_detection_model_dir"] = str(Path(OCR_MODEL_DIR) / "det")
                    kwargs["text_recognition_model_dir"] = str(Path(OCR_MODEL_DIR) / "rec")
                _ENGINE = PaddleOCR(**kwargs)
                _ENGINE_NAME = "PP-OCRv5-mobile-PaddleCPU"
                return _ENGINE, _ENGINE_NAME
            except Exception as exc:
                errors.append(f"PaddleOCR: {exc}")
                if OCR_BACKEND != "auto":
                    raise RuntimeError("Không khởi tạo được PaddleOCR: " + str(exc)) from exc

        raise RuntimeError("Không có OCR local khả dụng. " + " | ".join(errors))


def _extract_detections(result: Any) -> List[Dict[str, Any]]:
    """Parse PaddleOCR 2/3 and RapidOCR outputs while retaining bboxes."""
    found: List[Dict[str, Any]] = []

    def add(box: Any, text: Any, score: Any) -> None:
        t = _normalize(str(text or ""))
        try:
            c = float(score or 0.0)
        except Exception:
            c = 0.0
        xyxy = _box_to_xyxy(box)
        if not t or xyxy is None or _quality(t, c) <= 0:
            return
        found.append({"text": t, "confidence": c, "bbox": [float(x) for x in xyxy]})

    def walk(obj: Any) -> None:
        if obj is None:
            return
        # RapidOCR 3.x returns dataclasses exposing boxes/txts/scores directly.
        boxes_attr = getattr(obj, "boxes", None)
        txts_attr = getattr(obj, "txts", None)
        scores_attr = getattr(obj, "scores", None)
        if boxes_attr is not None and txts_attr is not None:
            try:
                for i, text in enumerate(tuple(txts_attr)):
                    score = tuple(scores_attr)[i] if scores_attr is not None and i < len(tuple(scores_attr)) else 0.0
                    box = tuple(boxes_attr)[i] if i < len(tuple(boxes_attr)) else None
                    add(box, text, score)
                return
            except Exception:
                pass
        if hasattr(obj, "json") and callable(getattr(obj, "json")):
            try:
                j = obj.json
                if callable(j):
                    j = j()
                if isinstance(j, str):
                    import json as _json
                    j = _json.loads(j)
                walk(j)
                return
            except Exception:
                pass
        if isinstance(obj, dict):
            texts = obj.get("rec_texts")
            scores = obj.get("rec_scores")
            boxes = obj.get("rec_boxes") or obj.get("dt_polys") or obj.get("rec_polys") or obj.get("dt_boxes")
            if isinstance(texts, (list, tuple)):
                for i, text in enumerate(texts):
                    score = scores[i] if isinstance(scores, (list, tuple)) and i < len(scores) else 0.0
                    box = boxes[i] if isinstance(boxes, (list, tuple)) and i < len(boxes) else None
                    add(box, text, score)
                return
            for v in obj.values():
                walk(v)
            return
        if isinstance(obj, (list, tuple)):
            # RapidOCR: [[box, text, score], ...]
            for item in obj:
                if isinstance(item, (list, tuple)) and len(item) >= 3 and isinstance(item[1], (str, bytes)):
                    add(item[0], item[1], item[2])
                # PaddleOCR 2.x: [box, [text, score]]
                elif isinstance(item, (list, tuple)) and len(item) >= 2:
                    pair = item[-1]
                    if isinstance(pair, (list, tuple)) and len(pair) >= 2 and isinstance(pair[0], str):
                        add(item[0], pair[0], pair[1])
                    else:
                        walk(item)
                else:
                    walk(item)

    walk(result)
    # Stable de-duplication: same text + almost same box should be one detection.
    dedup: List[Dict[str, Any]] = []
    for d in found:
        duplicate = False
        x0, y0, x1, y1 = d["bbox"]
        for e in dedup:
            ex0, ey0, ex1, ey1 = e["bbox"]
            iou_x = max(0.0, min(x1, ex1) - max(x0, ex0))
            iou_y = max(0.0, min(y1, ey1) - max(y0, ey0))
            inter = iou_x * iou_y
            area = max(1.0, (x1-x0)*(y1-y0) + (ex1-ex0)*(ey1-ey0) - inter)
            sim = _text_similarity(d["text"], e["text"])
            if inter / area > 0.65 and sim > 0.92:
                if d["confidence"] > e["confidence"]:
                    e.update(d)
                duplicate = True
                break
        if not duplicate:
            dedup.append(d)
    dedup.sort(key=lambda z: (z["bbox"][1], z["bbox"][0]))
    return dedup


def _ocr_image(img: np.ndarray) -> List[Dict[str, Any]]:
    if img is None or img.size == 0:
        return []
    engine, _ = _make_engine()
    h, w = img.shape[:2]
    all_det: List[Dict[str, Any]] = []

    def run_pass(work: np.ndarray) -> List[Dict[str, Any]]:
        try:
            _install_rapidocr_empty_warning_filter()
            if hasattr(engine, "predict"):
                result = engine.predict(work)
            elif hasattr(engine, "ocr"):
                result = engine.ocr(work, cls=False)
            else:
                result = engine(work)
            det = _extract_detections(result)
            if work.shape[:2] != img.shape[:2]:
                sx = img.shape[1] / max(1, work.shape[1])
                sy = img.shape[0] / max(1, work.shape[0])
                for d in det:
                    x0, y0, x1, y1 = d["bbox"]
                    d["bbox"] = [x0*sx, y0*sy, x1*sx, y1*sy]
            return det
        except Exception as exc:
            log.debug("OCR variant failed: %s", exc)
            return []

    # Always try the original pixels first. Run contrast enhancement only when
    # the native pass finds nothing or only very weak text; this improves recall
    # without doubling CPU cost on every clear frame.
    native = run_pass(img)
    all_det.extend(native)
    native_best = max((float(d.get("confidence", 0.0)) for d in native), default=0.0)
    if OCR_VARIANTS >= 2 and (not native or native_best < 0.55):
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) if img.ndim == 3 else img
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8)).apply(gray)
        enhanced = cv2.cvtColor(clahe, cv2.COLOR_GRAY2BGR)
        all_det.extend(run_pass(enhanced))

        # Thin/blurred subtitle strokes are frequently missed by PP-OCRv5 on the
        # first pass. A controlled 2x upscale is used only for weak frames, so it
        # improves recall without turning the normal path into a full upscale.
        if max(img.shape[:2]) <= 1600:
            up = cv2.resize(enhanced, None, fx=2.0, fy=2.0, interpolation=cv2.INTER_CUBIC)
            all_det.extend(run_pass(up))

    final: List[Dict[str, Any]] = []
    for d in sorted(all_det, key=lambda z: (-z["confidence"], -max(1.0, (z["bbox"][2]-z["bbox"][0])*(z["bbox"][3]-z["bbox"][1])))):
        is_dup = False
        x0, y0, x1, y1 = d["bbox"]
        for e in final:
            ex0, ey0, ex1, ey1 = e["bbox"]
            inter = max(0.0, min(x1, ex1)-max(x0, ex0)) * max(0.0, min(y1, ey1)-max(y0, ey0))
            union = max(1.0, (x1-x0)*(y1-y0) + (ex1-ex0)*(ey1-ey0) - inter)
            if inter/union > 0.55 and _text_similarity(d["text"], e["text"]) > 0.78:
                is_dup = True
                if d["confidence"] > e["confidence"]:
                    e.update(d)
                break
        if not is_dup:
            final.append(d)
    final.sort(key=lambda z: (z["bbox"][1], z["bbox"][0]))
    return final


def _textlike_mask(roi: np.ndarray) -> np.ndarray:
    """Cheap subtitle-stroke map for the first pass; no OCR here."""
    gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY) if roi.ndim == 3 else roi
    gray = cv2.GaussianBlur(gray, (3, 3), 0)
    # Bright and dark subtitle strokes via local top-hat / black-hat contrast.
    k = cv2.getStructuringElement(cv2.MORPH_RECT, (7, 3))
    top = cv2.morphologyEx(gray, cv2.MORPH_TOPHAT, k)
    black = cv2.morphologyEx(gray, cv2.MORPH_BLACKHAT, k)
    contrast = cv2.max(top, black)
    _, mask = cv2.threshold(contrast, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_RECT, (5, 2)))
    return cv2.resize(mask, (160, 72), interpolation=cv2.INTER_AREA)


def _scan_score(prev_mask: Optional[np.ndarray], cur_mask: np.ndarray, prev_gray: Optional[np.ndarray], cur_gray: np.ndarray) -> float:
    """Score changes in text-like strokes only; never score raw scene motion.

    ``prev_gray`` and ``cur_gray`` remain in the signature for compatibility
    with the existing scan loop, but are intentionally not compared. Raw
    grayscale differences make moving people, camera pans, and animated
    backgrounds create OCR candidates even when no subtitle changes.
    """
    if prev_mask is None:
        return 0.0
    # The mask is built from local bright/dark stroke contrast. Comparing only
    # this representation prevents broad luminance/motion changes from driving
    # OCR. OCR recognition + spatial/temporal checks remain the final gate.
    return float(np.mean(cv2.absdiff(prev_mask, cur_mask)) / 255.0)


def _scan_cpu_backpressure(frame_index: int) -> None:
    """Throttle FFmpeg readers without dropping frames when system CPU is high.

    The worker simply pauses before reading more decoded frames. FFmpeg then blocks
    naturally on its stdout pipe, so no source frame is skipped or discarded.
    """
    if psutil is None or (frame_index % OCR_SCAN_CPU_CHECK_EVERY) != 0:
        return
    try:
        cpu = float(psutil.cpu_percent(interval=0.0))
    except Exception:
        return
    if cpu <= OCR_SCAN_CPU_TARGET:
        return
    excess = cpu - OCR_SCAN_CPU_TARGET
    delay = min(OCR_SCAN_CPU_MAX_SLEEP, 0.02 + excess / 200.0)
    if delay > 0:
        time.sleep(delay)


def _ffmpeg_scan_segment_worker(
    path: Path,
    x0: int,
    y0: int,
    x1: int,
    y1: int,
    out_w: int,
    out_h: int,
    scan_fps: float,
    video_duration: float,
    logical_start: float,
    logical_end: float,
    out_queue: "queue.Queue",
    stop_event: threading.Event,
) -> None:
    """Decode one logical video slice with its own FFmpeg process.

    A small decode overlap is used at each partition edge so a fast seek or
    codec keyframe boundary cannot hide a subtitle that starts exactly where
    two workers meet. Frames are emitted only for the worker's logical window,
    so downstream code still receives one chronological scan stream.
    """
    import subprocess

    # Align every worker to the same global scan grid. This keeps timestamps
    # identical to a single FFmpeg pass even though decoding is partitioned.
    grid = max(scan_fps, 0.5)
    decode_start = max(0.0, math.floor((logical_start - OCR_SCAN_OVERLAP) * grid + 1e-9) / grid)
    decode_end = min(video_duration, logical_end + OCR_SCAN_OVERLAP)
    decode_duration = max(0.001, decode_end - decode_start)
    ffmpeg = str(getattr(config, "FFMPEG_PATH", "ffmpeg"))
    use_cuda_decode = os.getenv("OCR_FFMPEG_CUDA", "0").strip().lower() in {
        "1", "true", "yes", "cuda", "gpu"
    }
    cmd = [ffmpeg, "-hide_banner", "-loglevel", "error", "-ss", f"{decode_start:.6f}"]
    if use_cuda_decode:
        cmd += ["-hwaccel", "cuda"]
    vf = (
        f"fps={max(0.5, scan_fps):.4f},"
        f"crop={max(2, x1-x0)}:{max(2, y1-y0)}:{x0}:{y0},"
        f"scale={out_w}:{out_h}:flags=fast_bilinear,format=bgr24"
    )
    cmd += [
        "-an", "-sn", "-dn", "-i", str(path),
        "-t", f"{decode_duration:.6f}",
        "-vf", vf,
        "-f", "rawvideo", "-pix_fmt", "bgr24",
        "-threads", str(OCR_SCAN_FFMPEG_THREADS),
        "pipe:1",
    ]

    frame_bytes = out_w * out_h * 3
    proc = None
    try:
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            bufsize=frame_bytes * 4,
        )
        idx = 0
        while not stop_event.is_set():
            _scan_cpu_backpressure(idx)
            raw = proc.stdout.read(frame_bytes) if proc.stdout else b""
            if len(raw) != frame_bytes:
                break
            tm = decode_start + idx / max(scan_fps, 0.5)
            idx += 1
            # Logical ownership is exact on the global scan grid; the decode
            # overlap exists only to protect seeking near partition edges.
            if tm < logical_start - 1e-7 or tm >= logical_end - 1e-7:
                continue
            roi = np.frombuffer(raw, dtype=np.uint8).reshape((out_h, out_w, 3)).copy()
            while not stop_event.is_set():
                try:
                    out_queue.put((tm, roi), timeout=0.5)
                    break
                except queue.Full:
                    continue
    except Exception as exc:
        try:
            out_queue.put((None, exc), timeout=1.0)
        except Exception:
            pass
    finally:
        if proc is not None:
            if stop_event.is_set() and proc.poll() is None:
                try:
                    proc.terminate()
                except Exception:
                    pass
            if proc.stdout:
                try:
                    proc.stdout.close()
                except Exception:
                    pass
            try:
                proc.wait(timeout=10)
            except Exception:
                try:
                    proc.kill()
                except Exception:
                    pass
        # Sentinel means this segment has no more frames.
        try:
            out_queue.put((None, None), timeout=2.0)
        except Exception:
            pass


def _iter_scan_frames(path: Path, region: Dict[str, float], scan_fps: float):
    """Yield ROI scan frames from multiple parallel FFmpeg processes.

    FFmpeg is still the only video-frame decoder used by the normal scan path.
    The source is partitioned into chronological slices and all FFmpeg workers
    start together. Each slice has a small decode overlap, then the main thread
    consumes slices in order so timestamp ordering remains deterministic.
    """
    duration, src_fps, w, h = _video_meta(path)
    x0, y0, x1, y1 = _roi_pixels(region, w, h)
    out_w = max(160, min(SCAN_WIDTH, x1-x0))
    out_h = max(72, int(round((y1-y0) * out_w / max(1, x1-x0))))
    # Partition the fixed global scan-time grid, not arbitrary floating-time
    # boundaries. Every worker owns complete scan samples, so 12 FFmpeg
    # processes produce the same chronological sample lattice as one pass.
    total_scan_samples = max(1, int(math.ceil(duration * max(scan_fps, 0.5))))
    workers = min(OCR_SCAN_WORKERS, total_scan_samples)
    sample_bounds = [int(round(total_scan_samples * i / workers)) for i in range(workers + 1)]
    sample_bounds[0] = 0
    sample_bounds[-1] = total_scan_samples
    boundaries = [min(duration, k / max(scan_fps, 0.5)) for k in sample_bounds]
    log.info(
        "[OCR FASTSCAN] FFmpeg parallel ROI | workers=%d | ffmpeg_threads_per_worker=%d | overlap=%.3fs | scan_fps=%.2f",
        workers, OCR_SCAN_FFMPEG_THREADS, OCR_SCAN_OVERLAP, scan_fps,
    )

    queues = [queue.Queue(maxsize=OCR_SCAN_QUEUE_SIZE) for _ in range(workers)]
    stop_event = threading.Event()
    executor = concurrent.futures.ThreadPoolExecutor(max_workers=workers, thread_name_prefix="ffmpeg-roi")
    futures = []
    for i in range(workers):
        futures.append(executor.submit(
            _ffmpeg_scan_segment_worker,
            path, x0, y0, x1, y1, out_w, out_h, scan_fps, duration,
            float(boundaries[i]), float(boundaries[i + 1]), queues[i], stop_event,
        ))

    try:
        last_emitted_time = -1.0
        for q in queues:
            while True:
                tm, payload = q.get()
                if tm is None and payload is None:
                    break
                if tm is None and isinstance(payload, Exception):
                    raise RuntimeError(f"FFmpeg ROI worker failed: {payload}") from payload
                tm = float(tm)
                # Decode overlap can make the same sample appear in two adjacent
                # workers. Keep one chronological copy; never suppress a unique
                # sample, and never let overlap move the stream backwards.
                if tm <= last_emitted_time + 1e-6:
                    continue
                last_emitted_time = tm
                yield None, tm, payload
    except Exception:
        stop_event.set()
        raise
    finally:
        stop_event.set() if any(f.done() and f.exception() for f in futures) else None
        for f in futures:
            try:
                f.result(timeout=15)
            except Exception:
                stop_event.set()
        executor.shutdown(wait=True, cancel_futures=True)


def _candidate_times(path: Path, region: Dict[str, float], duration: float, progress_event_cb=None, progress_cb=None, candidate_gap: Optional[float] = None) -> List[float]:
    """FAST-RECALL transition scan.

    The scan is deliberately cheap and permissive.  It never decides that a
    subtitle is valid; it only schedules OCR work.  This is the key difference
    from the previous aggressive percentile gate: a small visual change is
    allowed to create an OCR candidate, and the OCR/state stage decides what is
    actually a subtitle.

    Long-video recovery: if the visual detector has a quiet interval, add one
    sparse OCR checkpoint every few seconds.  This is a safety net for subtitles
    whose rendered pixels change too little for a pure difference detector.
    """
    scores: List[Tuple[float, float]] = []
    prev_mask = None
    prev_gray = None
    gap = max(SCAN_MIN_GAP, float(candidate_gap)) if candidate_gap is not None else SCAN_MIN_GAP
    total = max(1, int(math.ceil(duration * SCAN_FPS)))
    done = 0
    for _, tm, roi in _iter_scan_frames(path, region, SCAN_FPS):
        gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
        mask = _textlike_mask(roi)
        score = _scan_score(prev_mask, mask, prev_gray, gray)
        scores.append((tm, score))
        prev_mask = mask
        prev_gray = cv2.resize(gray, (160, 72), interpolation=cv2.INTER_AREA)
        done += 1
        if progress_cb and (done == total or done % max(1, int(SCAN_FPS)) == 0):
            progress_cb(min(done, total), total, {"score": score})
        if progress_event_cb and (done == total or done % max(1, int(SCAN_FPS * 3)) == 0):
            progress_event_cb({"phase": "scan", "phase_done": done, "phase_total": total,
                               "overall_percent": 25.0 * done / total, "candidates": 0})

    if len(scores) < 2:
        return []

    vals = np.asarray([v for _, v in scores], dtype=np.float32)
    med = float(np.median(vals))
    mad = float(np.median(np.abs(vals - med))) + 1e-6

    # Three permissive gates.  The lowest gate catches small subtitle changes;
    # the robust gate catches normal changes; the high gate catches hard cuts.
    low_gate = max(0.010, med + 1.15 * mad)
    mid_gate = max(0.014, med + 1.70 * mad)
    high_gate = max(0.030, med + 2.50 * mad)

    peaks: List[Tuple[float, float]] = []
    for i, (tm, sc) in enumerate(scores):
        if sc < low_gate:
            continue
        lo = max(0, i - SCAN_LOCAL_MAX_RADIUS)
        hi = min(len(scores), i + SCAN_LOCAL_MAX_RADIUS + 1)
        local_max = max(x[1] for x in scores[lo:hi])
        # Require a local maximum for weak changes, but allow plateau edges for
        # stronger changes.  This prevents thousands of candidates from a static
        # subtitle while retaining subtle transitions.
        if sc >= local_max or sc >= high_gate or (sc >= mid_gate and sc >= local_max * 0.94):
            peaks.append((tm, sc))

    # Collapse nearby peaks but retain the strongest point in each gap.
    merged: List[Tuple[float, float]] = []
    for tm, sc in peaks:
        if not merged or tm - merged[-1][0] >= gap:
            merged.append((tm, sc))
        elif sc > merged[-1][1]:
            merged[-1] = (tm, sc)

    # A very quiet detector is still allowed a lower recovery threshold.
    if not merged and float(np.max(vals)) >= 0.025:
        recovery_gate = max(0.008, med + 0.80 * mad)
        for i, (tm, sc) in enumerate(scores):
            if sc < recovery_gate:
                continue
            lo = max(0, i - 1)
            hi = min(len(scores), i + 2)
            if sc >= max(x[1] for x in scores[lo:hi]):
                if not merged or tm - merged[-1][0] >= gap:
                    merged.append((tm, sc))

    out: List[float] = []
    for tm, _ in merged:
        t = round(max(0.02, min(duration - 0.02, tm)), 4)
        if not out or t - out[-1] >= gap:
            out.append(t)

    # Long-video recall safety net.  This does NOT run on every scan frame:
    # it inserts at most one OCR checkpoint per recovery interval where there is
    # no transition candidate.  A short subtitle is still normally caught by the
    # 5-FPS visual scan, while the checkpoint protects against low-contrast or
    # nearly-identical rendered subtitle changes.
    recovery_step = OCR_FAST_LONG_RECOVERY_SECONDS
    if duration >= OCR_FAST_LONG_SECONDS and recovery_step > 0:
        recovery: List[float] = []
        cursor = 0.05
        candidate_idx = 0
        while cursor < max(0.05, duration - 0.05):
            while candidate_idx < len(out) and out[candidate_idx] < cursor:
                candidate_idx += 1
            next_candidate = out[candidate_idx] if candidate_idx < len(out) else duration
            if next_candidate - cursor > recovery_step:
                recovery.append(round(cursor, 4))
            cursor += recovery_step
        out = sorted(set(out + recovery))

    return out

def _read_roi_frames(path: Path, times: Sequence[float], region: Dict[str, float]) -> List[Tuple[float, np.ndarray]]:
    """Read requested source frames while avoiding repeated random seeks.

    The old reader performed one ``CAP_PROP_POS_FRAMES`` seek for every timestamp.
    With xKiro recovery/checkpoint timestamps this caused large seek overhead.
    When the requested timestamps are reasonably dense, decode forward once and
    emit only the exact requested frames. The ROI and source-frame timestamps are
    unchanged, so no subtitle content or timing information is synthesized here.
    """
    wanted = sorted(set(max(0.0, float(x)) for x in times))
    if not wanted:
        return []
    cap = cv2.VideoCapture(str(path))
    if not cap.isOpened():
        return []
    fps = float(cap.get(cv2.CAP_PROP_FPS) or 25.0)
    w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 0)
    h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 0)
    x0, y0, x1, y1 = _roi_pixels(region, w, h)

    wanted_frames = [max(0, int(round(tm * fps))) for tm in wanted]
    # Avoid a full-video decode when timestamps are extremely sparse.
    span_frames = wanted_frames[-1] - wanted_frames[0] if wanted_frames else 0
    density = len(wanted_frames) / max(1, span_frames + 1)
    sequential = (
        len(wanted_frames) >= 24
        and span_frames <= max(int(fps * 900.0), len(wanted_frames) * 12)
        and density >= 0.002
    )

    out: List[Tuple[float, np.ndarray]] = []
    try:
        if sequential:
            target_idx = 0
            frame_no = 0
            # Seek only once to the first requested frame, then read forward.
            first_frame = wanted_frames[0]
            if first_frame > 0:
                cap.set(cv2.CAP_PROP_POS_FRAMES, first_frame)
                frame_no = first_frame
            while target_idx < len(wanted_frames):
                ok, frame = cap.read()
                if not ok:
                    break
                while target_idx < len(wanted_frames) and wanted_frames[target_idx] < frame_no:
                    target_idx += 1
                if target_idx >= len(wanted_frames):
                    break
                if frame_no == wanted_frames[target_idx]:
                    actual_tm = frame_no / max(fps, 1.0)
                    roi = frame[y0:y1, x0:x1]
                    if roi.size:
                        out.append((actual_tm, roi.copy()))
                    target_idx += 1
                frame_no += 1
        else:
            for frame_no in wanted_frames:
                cap.set(cv2.CAP_PROP_POS_FRAMES, frame_no)
                ok, frame = cap.read()
                if not ok:
                    continue
                actual_frame = int(round(cap.get(cv2.CAP_PROP_POS_FRAMES) - 1))
                actual_tm = max(0.0, float(actual_frame) / max(fps, 1.0))
                roi = frame[y0:y1, x0:x1]
                if roi.size:
                    out.append((actual_tm, roi.copy()))
    finally:
        cap.release()
    return out

def _line_group(detections: Sequence[Dict[str, Any]], roi_h: int) -> List[Dict[str, Any]]:
    if not detections:
        return []
    rows: List[List[Dict[str, Any]]] = []
    for d in sorted(detections, key=lambda z: (z["bbox"][1], z["bbox"][0])):
        x0, y0, x1, y1 = d["bbox"]
        cy = (y0+y1)/2.0
        h = max(1.0, y1-y0)
        placed = False
        for row in rows:
            rcy = np.mean([(q["bbox"][1]+q["bbox"][3])/2 for q in row])
            rh = np.median([max(1.0,q["bbox"][3]-q["bbox"][1]) for q in row])
            if abs(cy-rcy) <= max(8.0, 0.65*max(h,rh)):
                row.append(d); placed=True; break
        if not placed:
            rows.append([d])
    out=[]
    for row in rows:
        row=sorted(row,key=lambda z:z["bbox"][0])
        xs=[q["bbox"][0] for q in row]+[q["bbox"][2] for q in row]
        ys=[q["bbox"][1] for q in row]+[q["bbox"][3] for q in row]
        text=_normalize(" ".join(q["text"] for q in row).strip())
        conf=min(q["confidence"] for q in row)
        # Drop UI/environment glyph rows before tracking or subtitle-position learning.
        if text and not _looks_like_environment_glyph_noise(text):
            out.append({"text":text,"confidence":conf,"bbox":[min(xs),min(ys),max(xs),max(ys)]})
    return out


def _subtitle_candidate_score(det: Dict[str, Any], roi_w: int, roi_h: int, active_ratio: float, text_change_ratio: float) -> float:
    x0,y0,x1,y1=det["bbox"]
    bw=max(1.0,x1-x0); bh=max(1.0,y1-y0)
    area=(bw*bh)/(max(1,roi_w*roi_h))
    cy=((y0+y1)/2)/max(1,roi_h)
    cx=((x0+x1)/2)/max(1,roi_w)
    center=max(0.0,1.0-abs(cx-0.5)*1.4)
    ybias=max(0.0,1.0-abs(cy-OCR_EXPECTED_SUBTITLE_Y)*1.6)
    # High occupancy + very low text change is the typical watermark/logo pattern.
    dynamic=max(0.0, 1.0-active_ratio) * (0.5+0.5*text_change_ratio)
    return 2.7*area + 0.9*center + 0.75*ybias + 1.7*dynamic + 0.55*float(det.get("confidence",0.0))


def _annotate_tracks(observations: Sequence[Dict[str, Any]], roi_w: int, roi_h: int) -> Tuple[List[Dict[str, Any]], set]:
    """Track OCR lines without allowing unrelated subtitle events to share one track.

    IMPORTANT: a track is spatial *and textual*.  The previous implementation
    matched almost any line at the same coordinates, so every subtitle at the
    same y-position could become one long track.  That contaminated static
    filtering and was one of the causes of text leaking into unrelated
    timeline intervals.
    """
    tracks: List[Dict[str, Any]] = []
    max_gap = max(1.0, min(8.0, max(2.0, SCAN_MIN_GAP * 4.0)))

    for oi, obs in enumerate(observations):
        obs_time = float(obs.get("time", 0.0))
        for li, det in enumerate(obs.get("lines") or []):
            x0, y0, x1, y1 = det["bbox"]
            cy = (y0 + y1) / 2.0
            h = max(1.0, y1 - y0)
            cx = (x0 + x1) / 2.0
            text = _normalize(det.get("text", ""))
            best = None
            best_cost = 1e9

            for tr in tracks:
                if not tr["items"]:
                    continue
                last = tr["items"][-1]
                if obs_time - float(last["time"]) > max_gap:
                    continue
                tx, ty, th = tr["last"]
                spatial = (
                    abs(cx - tx) / max(1, roi_w)
                    + 1.8 * abs(cy - ty) / max(1, roi_h)
                    + 0.9 * abs(math.log(max(1, h) / max(1, th)))
                )
                text_sim = _text_similarity(text, last["text"])
                # Same visual line with completely different text is a new cue.
                if text_sim < 0.30 and spatial > 0.08:
                    continue
                cost = spatial + 0.75 * (1.0 - text_sim)
                if cost < 0.48 and cost < best_cost:
                    best = tr
                    best_cost = cost

            item = {
                "obs_index": oi,
                "line_index": li,
                "time": obs_time,
                "text": text,
                "confidence": float(det.get("confidence", 0.0)),
                "bbox": list(det["bbox"]),
            }

            if best is None:
                tr = {"items": [item], "last": (cx, cy, h)}
                tracks.append(tr)
                det["_track_id"] = len(tracks) - 1
            else:
                best["items"].append(item)
                best["last"] = (cx, cy, h)
                det["_track_id"] = tracks.index(best)

    static_ids = set()
    for tid, tr in enumerate(tracks):
        items = tr["items"]
        if not items:
            continue
        counts = Counter(_normalize(x["text"]).casefold() for x in items)
        dominant = counts.most_common(1)[0][0] if counts else ""
        active_ratio = len(items) / max(1, len(observations))
        dominant_ratio = counts.get(dominant, 0) / max(1, len(items))

        yvals = []
        hvals = []
        for x in items:
            bx = x["bbox"]
            yvals.append((bx[1] + bx[3]) / 2)
            hvals.append(max(1.0, bx[3] - bx[1]))

        yspread = (max(yvals) - min(yvals)) / max(1.0, roi_h) if yvals else 1.0
        hmed = max(1.0, float(np.median(hvals))) if hvals else 1.0
        hspread = (max(hvals) - min(hvals)) / hmed if hvals else 1.0
        text_consistency = 1.0
        if dominant:
            text_consistency = float(
                np.mean([_text_similarity(dominant, x["text"]) for x in items])
            )
        span = (
            float(items[-1]["time"]) - float(items[0]["time"])
            if len(items) > 1 else 0.0
        )

        # Static text must be genuinely persistent, spatially fixed and almost
        # identical. A subtitle that changes wording therefore cannot be
        # globally discarded as a watermark.
        if (
            active_ratio >= OCR_STATIC_OCCUPANCY
            and dominant_ratio >= 1.0 - OCR_STATIC_CHANGE_MAX
            and span >= 20.0
            and yspread <= 0.025
            and hspread <= 0.35
            and text_consistency >= 0.96
        ):
            static_ids.add(tid)

    return tracks, static_ids


def _learn_subtitle_y_modes(observations: Sequence[Dict[str, Any]], static_ids: set, roi_h: int) -> List[float]:
    """Learn one or more likely subtitle vertical bands from non-static OCR tracks.

    This intentionally does not assume bottom subtitles. It supports center/top
    subtitles and videos whose subtitle position changes between scenes.
    """
    if not observations or roi_h<=0 or not OCR_ADAPTIVE_POSITION:
        return [OCR_EXPECTED_SUBTITLE_Y]
    bins=np.zeros(20,dtype=np.float64)
    samples=[]
    for obs in observations:
        for d in obs.get("lines") or []:
            if d.get("_track_id") in static_ids: continue
            x0,y0,x1,y1=d["bbox"]
            cy=((y0+y1)/2.0)/max(1,roi_h)
            cy=max(0.0,min(1.0,cy))
            conf=max(0.05,float(d.get("confidence",0.0)))
            roi_shape = obs.get("roi_shape")
            if roi_shape:
                roi_h0, roi_w0 = int(roi_shape[0]), int(roi_shape[1])
            else:
                roi0 = obs.get("roi")
                roi_h0, roi_w0 = roi0.shape[:2] if roi0 is not None else (roi_h, roi_w)
            area=max(1.0,(x1-x0)*(y1-y0))/max(1.0,(roi_w0*roi_h0))
            weight=conf*(0.5+min(1.5,area*25.0))
            samples.append((cy,weight))
            bins[min(19,max(0,int(cy*20)))]+=weight
    if not samples or float(bins.max())<=0:
        return [OCR_EXPECTED_SUBTITLE_Y]
    modes=[]
    order=np.argsort(-bins)
    for bi in order:
        if bins[bi]<=0: break
        center=(bi+0.5)/20.0
        if all(abs(center-m)>=0.10 for m in modes):
            band=[(c,w) for c,w in samples if abs(c-center)<=0.075]
            if band:
                total=sum(w for _,w in band)
                modes.append(sum(c*w for c,w in band)/max(total,1e-9))
        if len(modes)>=3: break
    return modes or [OCR_EXPECTED_SUBTITLE_Y]


def _choose_subtitle_from_observation(
    obs: Dict[str, Any],
    static_ids: set,
    roi_w: int,
    roi_h: int,
    y_modes: Optional[Sequence[float]] = None,
) -> Tuple[str, List[Dict[str, Any]], Dict[str, Any]]:
    """Choose subtitle text from THIS observation only.

    No text from another timestamp is ever copied into the current observation.
    The selection prefers the learned subtitle band but has a confidence-based
    fallback so a moving subtitle is not silently converted to an empty state.
    """
    roi_shape = obs.get("roi_shape")
    roi = obs.get("roi")
    if roi_shape and len(roi_shape) >= 2:
        actual_h, actual_w = max(1, int(roi_shape[0])), max(1, int(roi_shape[1]))
    elif isinstance(roi, np.ndarray) and roi.ndim >= 2:
        actual_h, actual_w = max(1, int(roi.shape[0])), max(1, int(roi.shape[1]))
    else:
        actual_h, actual_w = max(1, roi_h), max(1, roi_w)

    modes = list(y_modes or [OCR_EXPECTED_SUBTITLE_Y])
    lines = []
    for d in (obs.get("lines") or []):
        if d.get("_track_id") in static_ids:
            continue
        text = _normalize(d.get("text", ""))
        if not text or _looks_like_environment_glyph_noise(text):
            continue
        x0, y0, x1, y1 = d["bbox"]
        bw = max(1.0, x1 - x0)
        bh = max(1.0, y1 - y0)
        # Subtitle text is usually a horizontal line, not a tiny moving object
        # or isolated texture. Geometry is a soft gate so short cues/languages
        # remain possible, while face/scene fragments are less likely to survive.
        aspect = bw / max(1.0, bh)
        alnum_count = sum(1 for ch in text if ch.isalnum())
        conf = float(d.get("confidence", 0.0))
        if bw < max(6.0, actual_w * 0.018) or bh < 2.5:
            continue
        if alnum_count < 2:
            continue
        if aspect < 0.72 and not (conf >= 0.88 and alnum_count >= 3):
            continue
        if bh > actual_h * 0.62 and not (conf >= 0.90 and alnum_count >= 4):
            continue
        item = dict(d)
        item["text"] = text
        lines.append(item)

    if not lines:
        return "", [], {
            "candidates": len(obs.get("lines") or []),
            "filtered_static": len(obs.get("lines") or []),
            "confidence": 0.0,
        }

    def score(d: Dict[str, Any]) -> float:
        x0, y0, x1, y1 = d["bbox"]
        bw = max(1.0, x1 - x0)
        bh = max(1.0, y1 - y0)
        area = (bw * bh) / max(1.0, actual_w * actual_h)
        cx = ((x0 + x1) / 2.0) / max(1.0, actual_w)
        cy = ((y0 + y1) / 2.0) / max(1.0, actual_h)
        ydist = min(abs(cy - m) for m in modes) if modes else 0.0
        ymatch = max(0.0, 1.0 - ydist / 0.22)
        center = max(0.0, 1.0 - abs(cx - 0.5) * 1.1)
        conf = float(d.get("confidence", 0.0))
        return 2.2 * ymatch + 1.4 * conf + 0.7 * min(1.0, area * 20.0) + 0.25 * center

    ranked = sorted(lines, key=score, reverse=True)
    main = ranked[0]

    # Position is a ranking hint, never a hard rejection: some videos move
    # subtitles between bottom/center/top, and short cues may occur only once.
    mx0, my0, mx1, my1 = main["bbox"]
    selected = [main]
    main_cy = (my0 + my1) / 2.0
    main_h = max(1.0, my1 - my0)
    for d in ranked[1:]:
        x0, y0, x1, y1 = d["bbox"]
        dcy = (y0 + y1) / 2.0
        dh = max(1.0, y1 - y0)
        if (
            abs(dcy - main_cy) <= 2.75 * max(main_h, dh)
            and abs(x0 - mx0) < actual_w * 0.75
            and _text_similarity(d.get("text", ""), main.get("text", "")) < 0.98
        ):
            selected.append(d)
            if len(selected) >= 4:
                break

    selected.sort(key=lambda d: d["bbox"][1])
    text = "\n".join(_normalize(d["text"]) for d in selected).strip()
    if _looks_like_environment_glyph_noise(text):
        return "", [], {
            "candidates": len(lines),
            "filtered_static": len(obs.get("lines") or []),
            "confidence": 0.0,
        }
    conf = min(
        (float(d.get("confidence", 0.0)) for d in selected),
        default=0.0,
    )
    return _normalize(text), selected, {
        "candidates": len(lines),
        "filtered_static": len(obs.get("lines") or []) - len(lines),
        "confidence": conf,
    }


def _state_at_time(observations: Sequence[Dict[str, Any]], target: float, static_ids: Optional[set]=None, y_modes: Optional[Sequence[float]]=None) -> Tuple[str, List[Dict[str, Any]], float]:
    if not observations:
        return "", [], 0.0
    static_ids=static_ids or set()
    ordered=sorted(observations,key=lambda x:abs(float(x["time"])-target))
    for nearest in ordered[:6]:
        roi = nearest.get("roi")
        shape = nearest.get("roi_shape")
        if roi is None and not shape:
            continue
        if shape and len(shape) >= 2:
            h0, w0 = int(shape[0]), int(shape[1])
        else:
            h0, w0 = roi.shape[0], roi.shape[1]
        text,boxes,_=_choose_subtitle_from_observation(nearest,static_ids,w0,h0,y_modes)
        if text:
            conf=min((float(b.get("confidence",0.0)) for b in boxes),default=0.0)
            return text,boxes,conf
    return "", [], 0.0


def _recognize_times(path: Path, region: Dict[str, float], times: Sequence[float], progress_event_cb=None, progress_offset: int = 0, progress_total: Optional[int] = None, candidate_count: Optional[int] = None) -> List[Dict[str, Any]]:
    """OCR frames, with a bounded retry pass so empty frames cannot stall progress.

    Empty detector results are common when the subtitle is absent or outside the
    configured ROI. Retrying every such frame multiplies OCR work and makes the
    UI appear frozen after the first pass (e.g. 177/180). Retry low-confidence
    text first, plus only a small, evenly-spaced sample of completely empty frames.
    """
    frames = _read_roi_frames(path, times, region)
    observations = []
    weak_text = []
    empty_frames = []
    for i, (tm, roi) in enumerate(frames, 1):
        det = _ocr_image(roi)
        _cpu_yield()
        lines = _line_group(det, roi.shape[0])
        observations.append({"time": tm, "lines": lines, "detections": det, "roi_shape": tuple(roi.shape[:2])})
        if not lines:
            empty_frames.append(tm)
        elif min((float(x.get("confidence", 0.0)) for x in lines), default=0.0) < OCR_RETRY_CONF:
            weak_text.append(tm)
        if progress_event_cb:
            total_progress = max(1, int(progress_total or len(frames)))
            done_progress = min(total_progress, int(progress_offset) + i)
            progress_event_cb({
                "phase": "recognition",
                "phase_done": done_progress,
                "phase_total": total_progress,
                "overall_percent": 25 + 45 * done_progress / total_progress,
                "segments": 0,
                "candidates": int(candidate_count if candidate_count is not None else len(times)),
                "probe_frames": total_progress,
            })

    if OCR_RETRY_PASSES > 1 and (weak_text or empty_frames) and OCR_RETRY_OFFSETS:
        # Recovery mode: by default retry EVERY weak/empty source frame rather
        # than silently capping at 8 seeds. OCR_RETRY_MAX_SEEDS=0 means unlimited;
        # a positive value is an explicit operator-configured safety cap.
        try:
            retry_seed_cap = max(0, int(os.getenv("OCR_RETRY_MAX_SEEDS", "0")))
        except (TypeError, ValueError):
            retry_seed_cap = 0
        # Weak text is always retried because it is positive evidence of a subtitle.
        # Empty detections are different: on long videos most candidate timestamps
        # may legitimately contain no readable text. Retrying every empty frame at
        # two offsets multiplies CPU work dramatically. Sample empty frames evenly
        # within each batch, while retaining all weak-text seeds for recall.
        weak_seeds = list(dict.fromkeys(weak_text))
        empty_seeds = list(dict.fromkeys(empty_frames))
        try:
            empty_retry_cap = max(0, int(os.getenv("OCR_RETRY_EMPTY_MAX_SEEDS", "24")))
        except (TypeError, ValueError):
            empty_retry_cap = 0
        if empty_retry_cap > 0 and len(empty_seeds) > empty_retry_cap:
            if empty_retry_cap == 1:
                empty_seeds = [empty_seeds[len(empty_seeds) // 2]]
            else:
                pick = sorted(set(round(i * (len(empty_seeds) - 1) / (empty_retry_cap - 1))
                                  for i in range(empty_retry_cap)))
                empty_seeds = [empty_seeds[i] for i in pick]
        seeds = list(dict.fromkeys(weak_seeds + empty_seeds))
        if retry_seed_cap > 0:
            seeds = seeds[:retry_seed_cap]
        log.info(
            "[OCR MASTER] Retry policy | weak=%d | empty=%d/%d sampled | empty_cap=%s",
            len(weak_seeds), len(empty_seeds), len(empty_frames),
            empty_retry_cap if empty_retry_cap > 0 else "không giới hạn",
        )
        retry = []
        original_times = [float(tm) for tm, _ in frames]
        weak_set = set(weak_seeds)
        # Positive text gets a full two-sided retry. Empty frames get one nearby
        # retry only: that preserves coverage of every candidate without paying
        # for two extra OCR inferences on every empty frame.
        try:
            empty_offset = float(os.getenv("OCR_RETRY_EMPTY_OFFSET", "0.12"))
        except (TypeError, ValueError):
            empty_offset = 0.12
        for tm in seeds:
            offsets = OCR_RETRY_OFFSETS if tm in weak_set else (empty_offset,)
            for off in offsets:
                q = tm + off
                if q < 0.0:
                    continue
                # Avoid re-reading a timestamp already OCR'd in this batch.
                if any(abs(q - base_tm) <= 0.035 for base_tm in original_times):
                    continue
                retry.append(q)
        retry = sorted(set(round(min(max(0.0, x), 999999.0), 4) for x in retry))
        if retry:
            log.info(
                "[OCR MASTER] Retry mở rộng | batch=%d khung | chữ yếu=%d | khung rỗng=%d | seed=%d | retry=%d | cap=%s",
                len(frames), len(weak_text), len(empty_frames), len(seeds), len(retry),
                retry_seed_cap if retry_seed_cap > 0 else "không giới hạn",
            )
            # Instrument the two potentially slow operations separately. The retry
            # seed list is finite for this batch; cap=0 means no seed cap, not an
            # infinite retry loop. Emit heartbeat logs so the UI/log cannot appear
            # frozen without indicating whether video seeking or OCR is taking time.
            retry_started = time.monotonic()
            log.info("[OCR MASTER] Retry: bắt đầu đọc %d khung từ video", len(retry))
            retry_frames = _read_roi_frames(path, retry, region)
            log.info(
                "[OCR MASTER] Retry: đọc xong %d/%d khung sau %.2fs",
                len(retry_frames), len(retry), time.monotonic() - retry_started,
            )
            for retry_index, (rtm, rroi) in enumerate(retry_frames, 1):
                frame_started = time.monotonic()
                log.debug(
                    "[OCR MASTER] Retry OCR bắt đầu %d/%d tại %.3fs",
                    retry_index, len(retry_frames), rtm,
                )
                rdet = _ocr_image(rroi)
                _cpu_yield()
                rlines = _line_group(rdet, rroi.shape[0])
                observations.append({"time": rtm, "lines": rlines, "detections": rdet, "roi_shape": tuple(rroi.shape[:2])})
                log.info(
                    "[OCR MASTER] Retry OCR %d/%d xong | detections=%d | lines=%d | %.2fs",
                    retry_index, len(retry_frames), len(rdet), len(rlines),
                    time.monotonic() - frame_started,
                )
                if progress_event_cb:
                    # Keep the main recognition percentage monotonic; identify the
                    # subphase separately so the frontend can show activity.
                    total_progress = max(1, int(progress_total or len(frames)))
                    done_progress = min(total_progress, int(progress_offset) + len(frames))
                    progress_event_cb({
                        "phase": "retry",
                        "phase_done": retry_index,
                        "phase_total": max(1, len(retry_frames)),
                        "overall_percent": 25 + 45 * done_progress / total_progress,
                        "segments": 0,
                        "candidates": int(candidate_count if candidate_count is not None else len(times)),
                        "probe_frames": total_progress,
                    })
            log.info(
                "[OCR MASTER] Retry hoàn tất | đã OCR %d/%d khung | tổng %.2fs",
                len(retry_frames), len(retry), time.monotonic() - retry_started,
            )
    observations.sort(key=lambda x: x["time"])
    return observations


def _frame_roi(path: Path, region: Dict[str, float], frame_no: int) -> Optional[np.ndarray]:
    cap=cv2.VideoCapture(str(path))
    if not cap.isOpened(): return None
    fps=float(cap.get(cv2.CAP_PROP_FPS) or 25.0)
    cap.set(cv2.CAP_PROP_POS_FRAMES,max(0,int(frame_no)))
    ok,frame=cap.read(); cap.release()
    if not ok: return None
    h,w=frame.shape[:2]; x0,y0,x1,y1=_roi_pixels(region,w,h)
    return frame[y0:y1,x0:x1].copy()


def _presence_score(roi: np.ndarray, boxes: Sequence[Dict[str, Any]]) -> float:
    if roi is None or roi.size==0 or not boxes:
        return 0.0
    gray=cv2.cvtColor(roi,cv2.COLOR_BGR2GRAY) if roi.ndim==3 else roi
    vals=[]
    for d in boxes:
        x0,y0,x1,y1=d["bbox"]
        x0=max(0,int(round(x0))); y0=max(0,int(round(y0))); x1=min(gray.shape[1],int(round(x1))); y1=min(gray.shape[0],int(round(y1)))
        if x1<=x0 or y1<=y0: continue
        crop=gray[y0:y1,x0:x1]
        edges=cv2.Canny(cv2.GaussianBlur(crop,(3,3),0),40,150)
        vals.append(float(np.mean(edges>0)))
    return float(np.mean(vals)) if vals else 0.0


def _refine_boundary(path: Path, region: Dict[str, float], approx: float, fps: float,
                     before_boxes: Sequence[Dict[str, Any]], after_boxes: Sequence[Dict[str, Any]],
                     entering: bool, duration: float, boundary_radius: Optional[float] = None,
                     boundary_fps: Optional[float] = None, quick: bool = False) -> float:
    """Find the first/last visible frame of the detected subtitle, not the frame
    with the strongest edges. The old implementation chose max edge density for
    both directions, which often moved start/end into the middle of a subtitle.
    """
    boxes = list(after_boxes if entering else before_boxes)
    if not boxes:
        return max(0.0, min(duration, approx))
    radius = OCR_BOUNDARY_RADIUS if boundary_radius is None else max(0.10, float(boundary_radius))
    sample_fps = OCR_BOUNDARY_FPS if boundary_fps is None else max(1.0, float(boundary_fps))
    lo = max(0.0, approx - radius)
    hi = min(duration, approx + radius)
    shared_cap = getattr(_BOUNDARY_READER, "cap", None)
    shared_path = getattr(_BOUNDARY_READER, "path", None)
    cap = shared_cap if shared_cap is not None and shared_path == str(path) and shared_cap.isOpened() else cv2.VideoCapture(str(path))
    owns_cap = cap is not shared_cap
    if not cap.isOpened():
        if owns_cap:
            cap.release()
        return max(0.0, min(duration, approx))
    src_fps = float(cap.get(cv2.CAP_PROP_FPS) or fps or 25.0)
    w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 0)
    h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 0)
    rx0, ry0, rx1, ry1 = _roi_pixels(region, w, h)
    frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    f0 = max(0, int(math.floor(lo * src_fps)))
    f1 = min(int(math.ceil(hi * src_fps)), frame_count - 1 if frame_count else int(math.ceil(hi * src_fps)))
    step = max(1, int(round(src_fps / max(sample_fps, 1.0))))
    sample_frames = list(range(f0, f1 + 1, step))
    if sample_frames and sample_frames[-1] != f1:
        sample_frames.append(f1)
    scores = []
    try:
        for fn in sample_frames:
            cap.set(cv2.CAP_PROP_POS_FRAMES, fn)
            ok, frame = cap.read()
            if not ok:
                continue
            roi = frame[ry0:ry1, rx0:rx1]
            if roi.size == 0:
                continue
            score = _presence_score(roi, boxes)
            scores.append((fn, score))
    finally:
        if owns_cap:
            cap.release()
    if len(scores) < 2:
        return max(0.0, min(duration, approx))
    vals = np.asarray([v for _, v in scores], dtype=np.float32)
    peak = float(np.max(vals))
    baseline = float(np.percentile(vals, 20))
    # If there is no clear visual change in the OCR text box, do not invent a
    # precise boundary from noise; retain the coarse detected timestamp.
    if peak - baseline < 0.012:
        return max(0.0, min(duration, approx))
    threshold = max(0.015, baseline + 0.22 * (peak - baseline))
    active = [(fn, score) for fn, score in scores if score >= threshold]
    if not active:
        return max(0.0, min(duration, approx))
    if quick:
        # Long-video mode avoids repeated frame-by-frame random seeks. Boundaries
        # are estimated from the coarse visual samples (typically ~0.25 s apart).
        frame_no = active[0][0] if entering else active[-1][0]
        result = frame_no / max(src_fps, 1.0) if entering else (frame_no + step) / max(src_fps, 1.0)
        return max(0.0, min(duration, result))

    # The coarse sample is ~12-15 FPS. Check only the small interval around the
    # crossing frame-by-frame so end times do not drift by one coarse sample.
    shared_cap = getattr(_BOUNDARY_READER, "cap", None)
    shared_path = getattr(_BOUNDARY_READER, "path", None)
    cap = shared_cap if shared_cap is not None and shared_path == str(path) and shared_cap.isOpened() else cv2.VideoCapture(str(path))
    owns_cap = cap is not shared_cap
    if not cap.isOpened():
        if owns_cap:
            cap.release()
        return max(0.0, min(duration, approx))
    try:
        if entering:
            coarse = active[0][0]
            scan = range(max(f0, coarse - step), min(f1, coarse + step) + 1)
            chosen = None
            for fn in scan:
                cap.set(cv2.CAP_PROP_POS_FRAMES, fn)
                ok, frame = cap.read()
                if not ok:
                    continue
                roi = frame[ry0:ry1, rx0:rx1]
                if roi.size and _presence_score(roi, boxes) >= threshold:
                    chosen = fn
                    break
            frame_no = coarse if chosen is None else chosen
            result = frame_no / max(src_fps, 1.0)
        else:
            coarse = active[-1][0]
            scan = range(max(f0, coarse - step), min(f1, coarse + step) + 1)
            chosen = None
            for fn in scan:
                cap.set(cv2.CAP_PROP_POS_FRAMES, fn)
                ok, frame = cap.read()
                if not ok:
                    continue
                roi = frame[ry0:ry1, rx0:rx1]
                if roi.size and _presence_score(roi, boxes) >= threshold:
                    chosen = fn
            frame_no = coarse if chosen is None else chosen
            result = (frame_no + 1) / max(src_fps, 1.0)
    finally:
        if owns_cap:
            cap.release()
    return max(0.0, min(duration, result))

def _build_master_timeline(
    path: Path,
    region: Dict[str, float],
    candidates: Sequence[float],
    duration: float,
    src_fps: float,
    progress_event_cb=None,
    dense_timeline: Optional[bool] = None,
    boundary_fps: Optional[float] = None,
    boundary_radius: Optional[float] = None,
    quick_boundaries: bool = False,
    fast_long_video: bool = False,
) -> List[Dict[str, Any]]:
    """Build a timeline where every text value is provenance-locked to its OCR frame.

    The old state machine could keep an old OCR result alive for a very long
    interval when the visual detector missed a transition.  This version uses
    the ordered OCR observations themselves and never assigns text from one
    observation to another timestamp.
    """
    use_dense_timeline = OCR_DENSE_TIMELINE if dense_timeline is None else bool(dense_timeline)
    probe_times = []
    if use_dense_timeline:
        # `candidates` includes a regular dense grid plus scene/text-change peaks.
        # Probe every timestamp directly; expanding +/- offsets around every grid
        # point would triple work and create artificial timestamp clustering.
        probe_times = [float(t) for t in candidates if 0.0 <= float(t) <= max(0.0, duration - 0.01)]
    else:
        # Each transition candidate needs nearby temporal evidence. The old
        # FAST-LONG path used only the exact candidate frame, but the state
        # builder rejects isolated detections unless they have a confirming
        # neighbor. That mismatch caused long videos to collapse to very few cues.
        # Keep the local probes tightly clustered to avoid dense OCR over the
        # entire video while giving each candidate enough evidence to survive.
        probe_offsets = OCR_FAST_LONG_PROBE_OFFSETS if fast_long_video else OCR_PROBE_OFFSETS
        for t in candidates:
            for off in probe_offsets:
                q = float(t) + float(off)
                if 0.0 <= q <= max(0.0, duration - 0.01):
                    probe_times.append(q)
        if fast_long_video:
            log.info(
                "[OCR MASTER] FAST-LONG probe strategy | candidates=%d | offsets=%s | local probes before dedupe",
                len(candidates), probe_offsets,
            )
    probe_times = [round(x, 4) for x in sorted(set(probe_times))]
    if not probe_times:
        probe_times = [0.05]

    # Report a stable total for the expanded probe timeline. The scan-candidate
    # count remains separate and does not jump from e.g. 62 to 186.
    if progress_event_cb:
        progress_event_cb({
            "phase": "recognition", "phase_done": 0,
            "phase_total": max(1, len(probe_times)),
            "overall_percent": 25, "candidates": len(candidates),
            "probe_frames": len(probe_times),
        })

    # One worker is the safe CPU default. Keep strict source-time ordering after
    # any threaded recognition.
    # Bound both temporary ROI images and queued work. The old implementation
    # could decode every probe ROI for a long video into one batch and retain
    # all full-resolution ROI arrays in observations, causing multi-GB RAM use.
    try:
        batch_size = max(8, min(100, int(os.getenv("OCR_BATCH_SIZE", "80"))))
    except (TypeError, ValueError):
        batch_size = 80
    batches = [
        probe_times[i:i + batch_size]
        for i in range(0, len(probe_times), batch_size)
    ]

    observations = []
    # Process batches incrementally so temporary decoded ROI arrays are released
    # after each batch. OCR_WORKERS remains respected, but only a small number of
    # batches can be active at once.
    worker_count = min(OCR_WORKERS, len(batches) or 1)
    if worker_count <= 1:
        for batch_index, batch in enumerate(batches):
            observations.extend(_recognize_times(
                path, region, batch, progress_event_cb,
                progress_offset=batch_index * batch_size,
                progress_total=len(probe_times),
                candidate_count=len(candidates),
            ))
    else:
        with concurrent.futures.ThreadPoolExecutor(
            max_workers=worker_count,
            thread_name_prefix="ocr-rec",
        ) as pool:
            for start in range(0, len(batches), worker_count):
                active = [
                    pool.submit(
                        _recognize_times, path, region, batch, progress_event_cb,
                        start_index * batch_size, len(probe_times), len(candidates)
                    )
                    for start_index, batch in enumerate(
                        batches[start:start + worker_count], start=start
                    )
                ]
                for fut in concurrent.futures.as_completed(active):
                    observations.extend(fut.result())

    observations.sort(key=lambda x: float(x["time"]))
    if not observations:
        return []

    first_shape = observations[0].get("roi_shape")
    if first_shape and len(first_shape) >= 2:
        roi_h, roi_w = int(first_shape[0]), int(first_shape[1])
    else:
        roi_h, roi_w = observations[0]["roi"].shape[:2]
    _, static_ids = _annotate_tracks(observations, roi_w, roi_h)
    static_count = len(static_ids)

    y_modes = _learn_subtitle_y_modes(observations, static_ids, roi_h)

    state_samples = []
    audit_candidates = 0
    for obs in observations:
        text, boxes, meta = _choose_subtitle_from_observation(
            obs, static_ids, roi_w, roi_h, y_modes
        )
        audit_candidates += sum(
            1 for d in obs.get("lines", [])
            if d.get("_track_id") not in static_ids
        )
        state_samples.append({
            "time": float(obs["time"]),
            "text": _normalize(text),
            "boxes": list(boxes or []),
            "confidence": float(meta.get("confidence", 0.0)),
        })

    # De-duplicate observations that resolve to the same frame/time.
    dedup_samples = []
    seen_times = set()
    for s in state_samples:
        key = round(float(s["time"]), 4)
        if key in seen_times:
            continue
        seen_times.add(key)
        dedup_samples.append(s)
    state_samples = dedup_samples

    # Temporal evidence gate: scene text and OCR hallucinations caused by moving
    # faces/objects often appear for one isolated frame. Keep text supported by a
    # nearby observation at a similar vertical location. Preserve a high-confidence,
    # clearly subtitle-shaped single observation as a fallback for very short cues.
    support_window = max(0.25, float(os.getenv("OCR_TEMPORAL_SUPPORT_WINDOW", "0.45")))
    supported = []
    for center_idx, sample in enumerate(state_samples):
        text = _normalize(sample.get("text", ""))
        if not text:
            supported.append(sample)
            continue
        boxes = sample.get("boxes") or []
        conf = float(sample.get("confidence", 0.0))
        box = boxes[0].get("bbox") if boxes else None
        if box and len(box) >= 4:
            x0, y0, x1, y1 = map(float, box[:4])
            bw = max(1.0, x1-x0)
            bh = max(1.0, y1-y0)
            cx = ((x0+x1)/2.0) / max(1, roi_w)
            cy = ((y0+y1)/2.0) / max(1, roi_h)
            aspect = bw / bh
        else:
            bw = 0.0; cx = 0.5; cy = OCR_EXPECTED_SUBTITLE_Y; aspect = 0.0
        has_neighbor = False
        # Search only the temporal neighborhood. The old implementation compared
        # every observation with every other observation (O(n^2)), which becomes
        # expensive when FAST-RECALL adds recovery checkpoints on long videos.
        def _supported_neighbor(other: Dict[str, Any]) -> bool:
            if not _normalize(other.get("text", "")):
                return False
            if _text_similarity(text, _normalize(other.get("text", ""))) < max(0.62, OCR_SIMILARITY - 0.20):
                return False
            oboxes = other.get("boxes") or []
            obox = oboxes[0].get("bbox") if oboxes else None
            if obox and len(obox) >= 4:
                ocy = ((float(obox[1]) + float(obox[3])) / 2.0) / max(1, roi_h)
                if abs(cy - ocy) > 0.16:
                    return False
            return True

        left = center_idx - 1
        while left >= 0 and float(sample["time"]) - float(state_samples[left]["time"]) <= support_window:
            if _supported_neighbor(state_samples[left]):
                has_neighbor = True
                break
            left -= 1
        if not has_neighbor:
            right = center_idx + 1
            while right < len(state_samples) and float(state_samples[right]["time"]) - float(sample["time"]) <= support_window:
                if _supported_neighbor(state_samples[right]):
                    has_neighbor = True
                    break
                right += 1
        # Single-frame exception is deliberately strict: long enough, centered,
        # wide and highly confident, which is typical of a real brief subtitle.
        # The user has explicitly selected the OCR subtitle region, so a clear
        # line-shaped detection inside that region should not require a second
        # frame to survive. This matters for short cues and rapidly changing text.
        strong_single = (
            conf >= 0.58 and sum(ch.isalnum() for ch in text) >= 2
            and bw >= max(12.0, roi_w * 0.06) and aspect >= 0.55
            and 0.05 <= cx <= 0.95
            and 0.02 <= cy <= 0.98
        )
        if has_neighbor or strong_single:
            supported.append(sample)
        else:
            sample = dict(sample)
            sample["text"] = ""
            sample["boxes"] = []
            sample["confidence"] = 0.0
            supported.append(sample)
    state_samples = supported

    if not state_samples:
        return []

    def similar(a: str, b: str) -> bool:
        # OCR may change punctuation/one glyph between adjacent frames; use a
        # recall-friendly threshold while spatial checks still guard against HUD text.
        threshold = max(0.76, min(OCR_SIMILARITY, OCR_SIMILARITY - 0.06))
        return bool(a and b and _text_similarity(a, b) >= threshold)

    def union_box(sample: Dict[str, Any]) -> Optional[Tuple[float, float, float, float]]:
        boxes = sample.get("boxes") or []
        valid = []
        for box in boxes:
            try:
                x0, y0, x1, y1 = map(float, box.get("bbox", ()))
                if x1 > x0 and y1 > y0:
                    valid.append((x0, y0, x1, y1))
            except Exception:
                continue
        if not valid:
            return None
        return (min(b[0] for b in valid), min(b[1] for b in valid),
                max(b[2] for b in valid), max(b[3] for b in valid))

    def spatially_same_subtitle(a: Dict[str, Any], b: Dict[str, Any]) -> bool:
        """Same words must also stay in the same subtitle band, not jump around the scene."""
        ba, bb = union_box(a), union_box(b)
        if ba is None or bb is None:
            return False
        ax0, ay0, ax1, ay1 = ba
        bx0, by0, bx1, by1 = bb
        acx, acy = (ax0 + ax1) / 2.0, (ay0 + ay1) / 2.0
        bcx, bcy = (bx0 + bx1) / 2.0, (by0 + by1) / 2.0
        ah, bh = max(1.0, ay1 - ay0), max(1.0, by1 - by0)
        return (
            abs(acx - bcx) / max(1, roi_w) <= 0.10
            and abs(acy - bcy) / max(1, roi_h) <= 0.06
            and 0.50 <= (bh / ah) <= 2.0
        )

    def single_frame_plausible(sample: Dict[str, Any]) -> bool:
        """Only allow an unconfirmed one-frame cue when it looks strongly like a subtitle."""
        if float(sample.get("confidence", 0.0)) < 0.60:
            return False
        box = union_box(sample)
        if box is None:
            return False
        x0, y0, x1, y1 = box
        bw, bh = max(1.0, x1 - x0), max(1.0, y1 - y0)
        cx, cy = ((x0 + x1) / 2.0) / max(1, roi_w), ((y0 + y1) / 2.0) / max(1, roi_h)
        ydist = min((abs(cy - mode) for mode in y_modes), default=0.0)
        # Short subtitles still pass by temporal confirmation; this fast path is
        # intentionally limited to broad, centered, line-shaped text.
        return bw / max(1, roi_w) >= 0.08 and bh / max(1, roi_h) <= 0.35 and abs(cx - 0.5) <= 0.45 and ydist <= 0.16

    def confirm_text(index: int, candidate: str) -> bool:
        """Confirm a cue against any nearby matching observation in the same band.

        A single conflicting OCR fragment is not decisive: mobile OCR can read one
        of two subtitle lines on one probe and both lines on the next. Continue
        searching the local window for corroboration rather than dropping the cue.
        """
        if not candidate:
            return False
        t0 = float(state_samples[index]["time"])
        checked = 0
        for j in range(index + 1, min(len(state_samples), index + 10)):
            dt = float(state_samples[j]["time"]) - t0
            if dt > max(0.45, OCR_STATE_CONFIRM_WINDOW, 0.90):
                break
            checked += 1
            next_text = _normalize(state_samples[j].get("text", ""))
            if not next_text or not similar(candidate, next_text):
                continue
            if spatially_same_subtitle(state_samples[index], state_samples[j]):
                return True
        # At the tail of the timeline there may be no later probe to confirm it.
        # Permit only a clear subtitle-shaped observation in that case.
        return checked == 0 and single_frame_plausible(state_samples[index])

    # Build events from actual observation transitions. A blank sample does NOT
    # immediately delete the current cue; it must be corroborated.
    events = []
    current_text = ""
    current_boxes = []
    current_conf = 0.0
    current_start = None

    i = 0
    while i < len(state_samples):
        s = state_samples[i]
        txt = _normalize(s["text"])
        t = float(s["time"])
        conf = float(s.get("confidence", 0.0))

        if not current_text:
            if txt and (single_frame_plausible(s) or confirm_text(i, txt)):
                start = _refine_boundary(
                    path, region, t, src_fps, [], s.get("boxes") or [], True, duration,
                    boundary_radius=boundary_radius, boundary_fps=boundary_fps, quick=quick_boundaries,
                )
                current_text = txt
                current_boxes = list(s.get("boxes") or [])
                current_conf = conf
                current_start = start
            i += 1
            continue

        if txt and similar(current_text, txt) and spatially_same_subtitle({"boxes": current_boxes}, s):
            # Same cue must remain in the same subtitle band. Repeated words
            # moving around the scene are not treated as one subtitle track.
            if conf > current_conf:
                current_conf = conf
                current_boxes = list(s.get("boxes") or [])
                current_text = txt
            i += 1
            continue

        if txt:
            # New non-similar text: require confirmation unless the OCR result is
            # very strong. This prevents a single hallucinated frame from cutting
            # a valid cue in half.
            confirmed = single_frame_plausible(s) or confirm_text(i, txt)
            if not confirmed:
                i += 1
                continue

            end = _refine_boundary(
                path, region, t, src_fps, current_boxes, s.get("boxes") or [], False, duration,
                boundary_radius=boundary_radius, boundary_fps=boundary_fps, quick=quick_boundaries,
            )
            if current_start is not None and end > current_start + 1.0 / max(src_fps, 1.0):
                events.append({
                    "start": current_start,
                    "end": end,
                    "text": _normalize(current_text),
                    "confidence": current_conf,
                })

            current_text = txt
            current_boxes = list(s.get("boxes") or [])
            current_conf = conf
            current_start = _refine_boundary(
                path, region, t, src_fps, [], current_boxes, True, duration,
                boundary_radius=boundary_radius, boundary_fps=boundary_fps, quick=quick_boundaries,
            )
            i += 1
            continue

        # Blank OCR observation: keep current cue alive. Close it only if the
        # next corroborating observation is also blank or is a confirmed new cue.
        blank_confirmed = False
        consecutive_blanks = 0
        for j in range(i + 1, min(len(state_samples), i + 5)):
            dt = float(state_samples[j]["time"]) - t
            if dt > max(1.2, OCR_STATE_CONFIRM_WINDOW * 3.0):
                break
            next_text = _normalize(state_samples[j]["text"])
            if next_text and similar(current_text, next_text) and spatially_same_subtitle({"boxes": current_boxes}, state_samples[j]):
                # The current cue reappeared at the same subtitle position: this
                # was a detector miss, not an end.
                consecutive_blanks = 0
                break
            if not next_text:
                consecutive_blanks += 1
                if consecutive_blanks >= 2:
                    blank_confirmed = True
                    break
            else:
                if single_frame_plausible(state_samples[j]) or confirm_text(j, next_text):
                    blank_confirmed = True
                    break

        if blank_confirmed:
            end = _refine_boundary(
                path, region, t, src_fps, current_boxes, [], False, duration,
                boundary_radius=boundary_radius, boundary_fps=boundary_fps, quick=quick_boundaries,
            )
            if current_start is not None and end > current_start + 1.0 / max(src_fps, 1.0):
                events.append({
                    "start": current_start,
                    "end": end,
                    "text": _normalize(current_text),
                    "confidence": current_conf,
                })
            current_text = ""
            current_boxes = []
            current_conf = 0.0
            current_start = None

        i += 1

    if current_text and current_start is not None:
        # Do not stretch the last subtitle to the full video duration when OCR
        # stopped seeing it earlier. Use the last frame that actually showed the
        # current cue, then refine the disappearance against that cue's bbox.
        matching = [
            float(sample["time"]) for sample in state_samples
            if _normalize(sample.get("text", "")) and similar(current_text, sample.get("text", ""))
        ]
        last_visible = max(matching) if matching else float(current_start)
        grid_step = (1.0 / OCR_TIMELINE_FPS) if use_dense_timeline else (1.0 / max(SCAN_FPS, 1.0))
        near_video_end = duration - last_visible <= max(0.20, grid_step * 1.75)
        approx_end = duration if near_video_end else min(duration, last_visible + grid_step)
        end = _refine_boundary(
            path, region, approx_end, src_fps, current_boxes, [], False, duration,
            boundary_radius=boundary_radius, boundary_fps=boundary_fps, quick=quick_boundaries,
        ) if not near_video_end else duration
        end = max(current_start, min(duration, end))
        if end > current_start + 1.0 / max(src_fps, 1.0):
            events.append({
                "start": current_start,
                "end": end,
                "text": _normalize(current_text),
                "confidence": current_conf,
            })

    # Final cleanup: preserve chronological order and never overlap segments.
    clean = []
    for ev in events:
        text = _normalize(ev.get("text", ""))
        st = max(0.0, min(duration, float(ev.get("start", 0.0))))
        en = max(st, min(duration, float(ev.get("end", st))))
        if not text or en <= st:
            continue

        if clean and st < clean[-1]["end"]:
            st = clean[-1]["end"]
        if en <= st:
            continue

        seg = {
            "start": round(st, 4),
            "end": round(en, 4),
            "source_start": round(st, 4),
            "source_end": round(en, 4),
            "text": text,
            "confidence": round(float(ev.get("confidence", 0.0)), 4),
            "timing_source": "ocr_master_frame",
            "ocr_locked": True,
            "timing_locked": True,
            "ocr_engine": _ENGINE_NAME,
            "ocr_source": "roi",
        }

        # Merge only exact/near-exact duplicates that truly touch.
        if (
            clean
            and _text_similarity(clean[-1]["text"], text) >= 0.985
            and st <= clean[-1]["end"] + 0.04
        ):
            clean[-1]["end"] = seg["end"]
            clean[-1]["source_end"] = seg["source_end"]
        else:
            clean.append(seg)

    for idx, seg in enumerate(clean):
        seg["index"] = idx
        seg["segment_id"] = idx

    _set_audit(
        engine=_ENGINE_NAME,
        frames_scanned=int(math.ceil(duration * SCAN_FPS)),
        candidates=len(candidates),
        accepted_cues=len(clean),
        static_tracks_filtered=static_count,
        recognition_candidates=audit_candidates,
        needs_review=sum(
            1 for s in clean if float(s.get("confidence", 0.0)) < 0.45
        ),
        cpu_target_percent=OCR_CPU_TARGET,
        cpu_threads=OCR_CPU_THREADS,
        scan_fps=SCAN_FPS,
        scan_width=SCAN_WIDTH,
        timeline_fps=OCR_TIMELINE_FPS if use_dense_timeline else 0.0,
        dense_timeline=use_dense_timeline,
        fast_long_video=fast_long_video,
        gpu_mode=OCR_USE_GPU,
        fast_recall=True,
        recovery_seconds=OCR_FAST_LONG_RECOVERY_SECONDS if fast_long_video else 0.0,
    )
    return clean


def _refine_xkira_frame_boundary(
    path: Path,
    region: Dict[str, float],
    approx: float,
    duration: float,
    src_fps: float,
    entering: bool,
    radius: float = 0.55,
) -> float:
    """Refine an xKiro cue boundary to the actual source frame.

    xKiro returns subtitle text but no bounding boxes. Its old timeline therefore
    used the first/next *OCR response timestamp*, which can be late/early by the
    checkpoint interval when a request misses once. This helper never re-recognizes
    text and never changes OCR text: it only looks at the selected ROI's
    text-stroke transition and returns the source frame where that transition
    occurs.
    """
    approx = max(0.0, min(duration, float(approx)))
    radius = max(0.12, min(1.20, float(radius)))
    lo_t = max(0.0, approx - radius)
    hi_t = min(duration, approx + radius)
    if hi_t <= lo_t or src_fps <= 0:
        return approx

    cap = cv2.VideoCapture(str(path))
    if not cap.isOpened():
        return approx
    try:
        fps = float(cap.get(cv2.CAP_PROP_FPS) or src_fps or 25.0)
        w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 0)
        h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 0)
        x0, y0, x1, y1 = _roi_pixels(region, w, h)
        f0 = max(0, int(math.floor(lo_t * fps)))
        f1 = max(f0, int(math.ceil(hi_t * fps)))
        cap.set(cv2.CAP_PROP_POS_FRAMES, f0)
        prev_mask = None
        scores: List[Tuple[int, float]] = []
        frame_no = f0
        while frame_no <= f1:
            ok, frame = cap.read()
            if not ok:
                break
            roi = frame[y0:y1, x0:x1]
            if roi.size:
                # Keep boundary analysis cheap: same small stroke map as the fast scan.
                mask = _textlike_mask(roi)
                if prev_mask is not None:
                    score = _scan_score(prev_mask, mask, None, None)
                    scores.append((frame_no, score))
                prev_mask = mask
            frame_no += 1
    finally:
        cap.release()

    if not scores:
        return approx

    center_frame = int(round(approx * fps))
    # A transition should be both visually meaningful and close to the OCR-derived
    # boundary. Use a local peak rather than raw scene luminance, so background motion
    # is much less likely to move the subtitle timing.
    vals = np.asarray([score for _, score in scores], dtype=np.float32)
    med = float(np.median(vals))
    mad = float(np.median(np.abs(vals - med))) + 1e-6
    threshold = max(0.006, med + 1.10 * mad)
    candidates = [(fn, score) for fn, score in scores if score >= threshold]
    if not candidates:
        # Even when the adaptive threshold is quiet, use the strongest nearby stroke change.
        candidates = scores
    if not candidates:
        return approx

    # Prefer the nearest meaningful transition to the OCR-derived change time.
    # This prevents a stronger but unrelated scene transition inside the search
    # window from hijacking the subtitle boundary.
    near_radius = max(1, int(round(min(radius, 0.18) * fps)))
    near = [item for item in candidates if abs(item[0] - center_frame) <= near_radius]
    if near:
        best_frame = max(near, key=lambda item: float(item[1]))[0]
    else:
        best_frame = min(candidates, key=lambda item: abs(item[0] - center_frame))[0]
    # Reject an implausibly distant peak; a weak OCR checkpoint should not cause a
    # boundary jump to a totally different scene transition.
    max_distance = max(1, int(round(radius * fps)))
    if abs(best_frame - center_frame) > max_distance:
        best_frame = center_frame

    # Score peak represents the change between frame-1 and frame, so the source-frame
    # boundary is exactly frame/fps for both entering and leaving states.
    boundary = best_frame / max(fps, 1.0)
    return max(0.0, min(duration, boundary))


def _xkira_ocr_keys() -> List[str]:
    """Return the first eight unique xKiro keys dedicated to OCR."""
    getter = getattr(config, "get_xkira_api_keys", None)
    if not callable(getter):
        return []
    keys = []
    seen = set()
    for key in getter()[:8]:
        key = str(key or "").strip()
        if key and key not in seen:
            keys.append(key)
            seen.add(key)
    return keys


def _xkira_catalog_model() -> str:
    """Resolve a vision-capable xKiro model from the live public catalog."""
    configured = str(getattr(config, "XKIRA_OCR_MODEL", "") or "").strip()
    if configured:
        return configured
    try:
        r = requests.get("https://api.xkiro.com/v1/models", params={"modality": "chat"}, timeout=15)
        r.raise_for_status()
        data = r.json().get("data", [])
        vision = [m for m in data if isinstance(m, dict) and bool((m.get("capabilities") or {}).get("vision"))]
        # Prefer a fast, non-reasoning vision model when the catalog exposes it.
        vision.sort(key=lambda m: (bool((m.get("capabilities") or {}).get("reasoning")),
                                   float(((m.get("pricing") or {}).get("input")) or 9999)))
        if vision and vision[0].get("id"):
            return str(vision[0]["id"])
    except Exception as exc:
        log.warning("[XKIRO OCR] Không lấy được live vision catalog: %s", exc)
    return "openai/gpt-5.6-luna"



XKIRA_BATCH_FRAMES = max(1, min(6, int(os.getenv("XKIRA_OCR_BATCH_FRAMES", "4"))))


def _xkira_ocr_batch(frames: Sequence[Tuple[float, np.ndarray]], key: str, model: str) -> List[str]:
    """OCR several ROI frames in one xKiro vision request.

    One response contains one JSON item per input frame, preserving input order.
    On a provider that rejects multi-image requests, fall back to single-frame OCR
    so correctness/compatibility is preserved at the cost of speed for that call.
    """
    if not frames:
        return []
    if len(frames) == 1:
        return [_xkira_ocr_frame(frames[0][1], key, model)]

    content: List[Dict[str, Any]] = []
    for i, (_, frame) in enumerate(frames):
        if frame is None or frame.size == 0:
            content.append({"type": "text", "text": f"FRAME {i}: EMPTY"})
            continue
        ok, enc = cv2.imencode(".jpg", frame, [int(cv2.IMWRITE_JPEG_QUALITY), 78])
        if not ok:
            content.append({"type": "text", "text": f"FRAME {i}: EMPTY"})
            continue
        data_url = "data:image/jpeg;base64," + base64.b64encode(enc.tobytes()).decode("ascii")
        content.append({"type": "image_url", "image_url": {"url": data_url}})
        content.append({"type": "text", "text": f"FRAME {i}"})

    prompt = (
        "OCR every input video frame independently. The images contain ONLY a cropped subtitle ROI. "
        "For each FRAME index, read ONLY hardcoded subtitle text visible inside that frame. "
        "Do not describe scene, people, objects, HUD, logos, signs, or ambient/environment text. "
        "If a frame has no subtitle, return an empty string. Preserve every visible subtitle character, "
        "punctuation and line breaks. Return JSON only in this exact shape: "
        "{\\\"items\\\":[{\\\"index\\\":0,\\\"text\\\":\\\"...\\\"}]} . "
        "Include exactly one item for every FRAME index, in the same order."
    )
    payload = {
        "model": model,
        "messages": [{"role": "user", "content": [*content, {"type": "text", "text": prompt}]}],
        "max_tokens": max(180, 160 * len(frames)),
        "temperature": 0,
        "response_format": {"type": "json_object"},
    }
    r = requests.post(
        "https://api.xkiro.com/v1/chat/completions",
        headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
        json=payload,
        timeout=(10, 100),
    )
    if r.status_code in (400, 413):
        # Provider/model may reject multi-image payloads. Keep behavior correct by
        # falling back to the existing single-frame path.
        return [_xkira_ocr_frame(frame, key, model) for _, frame in frames]
    if r.status_code in (429, 500, 502, 503):
        raise RuntimeError(f"xKiro transient HTTP {r.status_code}")
    r.raise_for_status()
    body = r.json()
    raw = (((body.get("choices") or [{}])[0].get("message") or {}).get("content")) or ""
    raw = str(raw).strip()
    try:
        obj = json.loads(raw)
    except Exception:
        raw = re.sub(r"^```(?:json)?|```$", "", raw, flags=re.I).strip()
        obj = json.loads(raw)

    items = obj.get("items") if isinstance(obj, dict) else None
    by_index: Dict[int, str] = {}
    if isinstance(items, list):
        for item in items:
            if not isinstance(item, dict):
                continue
            try:
                idx = int(item.get("index"))
            except Exception:
                continue
            by_index[idx] = _normalize(str(item.get("text") or ""))
    if len(by_index) != len(frames) or any(i not in by_index for i in range(len(frames))):
        # Malformed batch response: retry safely as single-frame OCR.
        return [_xkira_ocr_frame(frame, key, model) for _, frame in frames]
    return [by_index[i] for i in range(len(frames))]


def _xkira_ocr_frame(frame: np.ndarray, key: str, model: str) -> str:
    """OCR one ROI frame through xKiro vision; returns subtitle text only."""
    if frame is None or frame.size == 0:
        return ""
    ok, enc = cv2.imencode(".jpg", frame, [int(cv2.IMWRITE_JPEG_QUALITY), 78])
    if not ok:
        return ""
    data_url = "data:image/jpeg;base64," + base64.b64encode(enc.tobytes()).decode("ascii")
    prompt = (
        "Read ONLY the hardcoded subtitle text visible inside this cropped video frame. "
        "Do not describe the scene, objects, people, HUD, logos, signs or ambient/environment text. "
        "If there is no subtitle, return an empty string. Preserve every visible subtitle character, "
        "including punctuation and line breaks. Return JSON only: {\\\"text\\\":\\\"...\\\"}."
    )
    payload = {
        "model": model,
        "messages": [{"role": "user", "content": [
            {"type": "image_url", "image_url": {"url": data_url}},
            {"type": "text", "text": prompt},
        ]}],
        "max_tokens": 180,
        "temperature": 0,
        "response_format": {"type": "json_object"},
    }
    r = requests.post(
        "https://api.xkiro.com/v1/chat/completions",
        headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
        json=payload,
        timeout=(10, 80),
    )
    if r.status_code in (429, 500, 502, 503):
        raise RuntimeError(f"xKiro transient HTTP {r.status_code}")
    r.raise_for_status()
    body = r.json()
    content = (((body.get("choices") or [{}])[0].get("message") or {}).get("content")) or ""
    content = str(content).strip()
    try:
        obj = json.loads(content)
        return _normalize(str(obj.get("text") or ""))
    except Exception:
        # Tolerate a provider that ignored response_format but still returned JSON/fenced JSON.
        content = re.sub(r"^```(?:json)?|```$", "", content, flags=re.I).strip()
        try:
            obj = json.loads(content)
            return _normalize(str(obj.get("text") or ""))
        except Exception:
            return _normalize(content)


def _read_xkira_frames(path: Path, times: Sequence[float], region: Dict[str, float]) -> List[Tuple[float, np.ndarray]]:
    """Read requested source frames in chronological order; no audio is opened."""
    return _read_roi_frames(path, times, region)


def extract_subtitle_segments_xkira(
    video_path: Path,
    region: Dict[str, float],
    progress_cb: Optional[Callable[[int, int, Any], None]] = None,
    progress_event_cb=None,
    model: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """xKiro OCR: image-only, eight-key parallel recognition with frame timeline.

    The local visual scan decides *when* an OCR request is useful. xKiro only sees
    the selected subtitle ROI. Recognition is distributed over up to eight keys;
    one request is in flight per key. Source times are quantized to the real
    video frame, so the exported cue boundary is never coarser than one source
    frame (normally well below 0.1 s at common video frame rates).
    """
    started = time.monotonic()
    path = Path(video_path)
    duration, src_fps, _, _ = _video_meta(path)
    keys = _xkira_ocr_keys()
    if not keys:
        raise RuntimeError("xKiro OCR cần tối đa 8 XKIRA_API_KEY_1...XKIRA_API_KEY_8.")
    model = str(model or getattr(config, "XKIRA_OCR_MODEL", "") or _xkira_catalog_model()).strip()
    scan_fps = float(getattr(config, "XKIRA_OCR_SCAN_FPS", 10.0))
    recovery = max(0.75, float(os.getenv("XKIRA_OCR_RECOVERY_SECONDS", "1.0")))

    # Cheap local scan. It reads only ROI pixels and never decodes/uses audio.
    transition = _candidate_times(path, region, duration, progress_event_cb, progress_cb, candidate_gap=1.0 / scan_fps)
    times = set(round(max(0.0, min(duration - 1.0 / max(src_fps, 1.0), t)), 4) for t in transition)
    # Recovery checkpoints protect against low-contrast subtitle transitions that
    # the visual-change detector cannot see.
    cursor = 0.05
    while cursor < duration:
        times.add(round(cursor, 4))
        cursor += recovery
    if not times:
        times.add(0.05)
    ordered = sorted(times)
    frames = _read_xkira_frames(path, ordered, region)
    if not frames:
        raise RuntimeError("Không đọc được frame ROI cho xKiro OCR.")

    workers = max(1, min(8, len(keys), int(getattr(config, "XKIRA_OCR_WORKERS", 8))))
    batch_size = XKIRA_BATCH_FRAMES
    indexed_frames = list(enumerate(frames))
    batches = [indexed_frames[i:i + batch_size] for i in range(0, len(indexed_frames), batch_size)]
    log.info("[XKIRO OCR] START | %.1fs | frames=%d | batches=%d | batch=%d | workers=%d | keys=%d | model=%s | scan_fps=%.1f",
             duration, len(frames), len(batches), batch_size, workers, len(keys), model, scan_fps)
    if progress_event_cb:
        progress_event_cb({"phase": "recognition", "phase_done": 0, "phase_total": len(frames),
                           "overall_percent": 20, "ocr_engine": "xKiro-vision", "model": model,
                           "workers": workers, "keys": len(keys)})

    results: List[Tuple[float, str]] = [None] * len(frames)  # type: ignore
    key_index = 0
    key_lock = threading.Lock()
    completed = 0
    completed_lock = threading.Lock()
    def one(batch):
        nonlocal completed, key_index
        last: Optional[Exception] = None
        texts: List[str] = []
        for attempt in range(3):
            with key_lock:
                key = keys[key_index % len(keys)]
                key_index += 1
            try:
                batch_frames = [(tm, frame) for _, (tm, frame) in batch]
                texts = _xkira_ocr_batch(batch_frames, key, model)
                if len(texts) != len(batch):
                    raise RuntimeError("xKiro trả thiếu kết quả batch")
                last = None
                break
            except Exception as exc:
                last = exc
                if attempt < 2:
                    time.sleep(min(2.0, 0.25 * (2 ** attempt)))
        if last:
            texts = [""] * len(batch)
        with completed_lock:
            completed += len(batch)
            done = completed
        for (idx, (tm, _)), text in zip(batch, texts):
            results[idx] = (tm, _normalize(text))
        if progress_cb and (done == len(frames) or done % max(1, batch_size * 2) == 0):
            progress_cb(done, len(frames), {"model": model, "workers": workers, "batch_frames": batch_size})
        if progress_event_cb and (done == len(frames) or done % max(1, batch_size * 2) == 0):
            progress_event_cb({"phase": "recognition", "phase_done": done, "phase_total": len(frames),
                               "overall_percent": 20 + 70 * done / max(1, len(frames)),
                               "ocr_engine": "xKiro-vision", "model": model, "workers": workers,
                               "batch_frames": batch_size})
        return batch[0][0]

    with concurrent.futures.ThreadPoolExecutor(max_workers=workers, thread_name_prefix="xkira-ocr") as pool:
        list(pool.map(one, batches))

    # Keep BOTH positive and empty OCR observations. Dropping empty observations
    # made the old timeline close a cue at the next successful OCR request, which
    # could be seconds late when a checkpoint was missed. Empty frames are evidence
    # for disappearance and are retained only for timeline construction.
    observations = [(float(tm), _normalize(text)) for tm, text in results]
    observations.sort(key=lambda x: x[0])

    if not any(text for _, text in observations):
        raise RuntimeError("xKiro OCR không tìm thấy phụ đề trong ROI.")

    # Fill isolated xKiro misses between matching subtitle observations. This does
    # NOT invent/alter text: it only prevents a single empty API result from cutting
    # one visible subtitle into multiple timing fragments.
    smoothed = list(observations)
    for i in range(1, len(smoothed) - 1):
        if smoothed[i][1]:
            continue
        left = smoothed[i - 1][1]
        right = smoothed[i + 1][1]
        if left and right and _text_similarity(left, right) >= 0.90:
            smoothed[i] = (smoothed[i][0], left)
    observations = smoothed

    # Transition candidates came from the full ROI visual scan. Use them as the
    # approximate change point, then refine to the exact source frame locally.
    transition_sorted = sorted(float(t) for t in transition)
    if not transition_sorted:
        transition_sorted = [tm for tm, text in observations if text]

    def nearest_transition(target: float) -> float:
        if not transition_sorted:
            return target
        pos = int(np.searchsorted(np.asarray(transition_sorted, dtype=np.float64), target))
        candidates = []
        for idx in (pos - 1, pos, pos + 1):
            if 0 <= idx < len(transition_sorted):
                candidates.append(transition_sorted[idx])
        if not candidates:
            return target
        best = min(candidates, key=lambda t: abs(t - target))
        # Never snap across a large unrelated video interval.
        return best if abs(best - target) <= 1.20 else target

    def merge_event(start: float, end: float, text: str) -> None:
        text = _normalize(text)
        if not text or end <= start:
            return
        if events and _text_similarity(events[-1]["text"], text) >= 0.985 and start <= events[-1]["end"] + 0.04:
            events[-1]["end"] = max(events[-1]["end"], end)
            return
        events.append({"start": start, "end": end, "text": text, "confidence": 1.0})

    events: List[Dict[str, Any]] = []
    active_text = ""
    active_raw_start: Optional[float] = None
    active_start: Optional[float] = None

    # Source-frame time gap used only for fallback when the video ends while a cue
    # is still visible. It is based on the actual sampled timestamps, not a fixed
    # two-second recovery extension.
    positive_times = [tm for tm, text in observations if text]
    sample_gap = 1.0 / max(scan_fps, 1.0)
    if len(observations) > 1:
        gaps = [b[0] - a[0] for a, b in zip(observations, observations[1:]) if b[0] > a[0]]
        if gaps:
            sample_gap = max(1.0 / max(src_fps, 1.0), min(1.0, float(np.median(gaps))))

    for i, (tm, text) in enumerate(observations):
        text = _normalize(text)
        if not active_text:
            if not text:
                continue
            approx_start = nearest_transition(tm)
            active_raw_start = tm
            active_start = _refine_xkira_frame_boundary(
                path, region, approx_start, duration, src_fps, True,
                radius=max(0.35, min(0.85, sample_gap * 2.5)),
            )
            active_text = text
            continue

        if text and _text_similarity(active_text, text) >= 0.90:
            # Same subtitle is still visible. Preserve the OCR text with the best/latest
            # response but do not move the start boundary.
            if len(text) > len(active_text):
                active_text = text
            continue

        # Blank or different text closes the current cue at the visual transition
        # near this observation. This is the key timeline fix: end is not "last OCR +
        # recovery"; it is the actual ROI change frame.
        approx_end = nearest_transition(tm)
        end = _refine_xkira_frame_boundary(
            path, region, approx_end, duration, src_fps, False,
            radius=max(0.35, min(0.85, sample_gap * 2.5)),
        )
        if active_start is not None:
            merge_event(active_start, max(active_start, end), active_text)

        active_text = ""
        active_raw_start = None
        active_start = None

        # The different-text observation is itself the next cue's positive frame.
        if text:
            approx_start = nearest_transition(tm)
            active_raw_start = tm
            active_start = _refine_xkira_frame_boundary(
                path, region, approx_start, duration, src_fps, True,
                radius=max(0.35, min(0.85, sample_gap * 2.5)),
            )
            active_text = text

    if active_text and active_start is not None:
        last_positive = positive_times[-1] if positive_times else active_raw_start
        # Normally a final blank sample closes the cue. Only use video end when the
        # last positive response reaches the end of the sampled timeline.
        last_observation_time = observations[-1][0] if observations else last_positive
        if last_positive is not None and (duration - last_observation_time) <= max(sample_gap * 1.25, 1.0 / max(src_fps, 1.0)):
            end = duration
        else:
            approx_end = min(duration, float(last_positive) + sample_gap)
            end = _refine_xkira_frame_boundary(
                path, region, approx_end, duration, src_fps, False,
                radius=max(0.35, min(0.85, sample_gap * 2.5)),
            )
        merge_event(active_start, max(active_start, end), active_text)

    clean = []
    for ev in events:
        text = _normalize(ev["text"])
        st = max(0.0, min(duration, float(ev["start"])))
        en = max(st, min(duration, float(ev["end"])))
        if not text or en <= st:
            continue
        if _looks_like_environment_glyph_noise(text):
            continue
        if clean and st < clean[-1]["end"]:
            st = clean[-1]["end"]
        if en <= st:
            continue
        clean.append({
            "start": round(st, 4), "end": round(en, 4),
            "source_start": round(st, 4), "source_end": round(en, 4),
            "text": text, "confidence": 1.0,
            "timing_source": "xkira_frame_locked", "ocr_locked": True,
            "timing_locked": True, "ocr_engine": "xKiro-vision",
            "ocr_model": model, "ocr_source": "roi", "ocr_keys": len(keys),
        })
    for i, seg in enumerate(clean):
        seg["index"] = i; seg["segment_id"] = i

    _set_audit(engine="xKiro-vision", model=model, requests=len(frames),
               accepted_cues=len(clean), workers=workers, keys=len(keys),
               scan_fps=scan_fps, timeline_quantization_seconds=round(1.0 / max(src_fps, 1.0), 4),
               roi_only=True, stt_used=False, audio_used=False,
               elapsed_seconds=round(time.monotonic() - started, 2))
    if progress_event_cb:
        progress_event_cb({"phase": "audit", "phase_done": 1, "phase_total": 1,
                           "overall_percent": 100, "segments": len(clean),
                           "ocr_engine": "xKiro-vision", "model": model})
    return clean


def extract_subtitle_segments(video_path: Path, region: Dict[str, float], progress_cb: Optional[Callable[[int,int,Any],None]]=None, partial_cb=None, progress_event_cb=None) -> List[Dict[str,Any]]:
    """Extract hardcoded subtitles using only ROI pixels and frame-locked timing."""
    started=time.monotonic(); path=Path(video_path)
    duration,src_fps,w,h=_video_meta(path)
    if duration<=0: raise RuntimeError("Không đọc được thời lượng video")
    fast_long_mode = bool(OCR_FAST_LONG_VIDEO and duration >= OCR_FAST_LONG_SECONDS)
    use_dense_timeline = bool(OCR_DENSE_TIMELINE and not fast_long_mode)
    # Boundary refinement must inspect the real source-frame cadence. The old
    # fixed 12 FPS boundary scan could land several frames away on a 30 FPS
    # source. Use every source frame in the local boundary window (capped at 30).
    boundary_fps = min(30.0, max(12.0, float(src_fps)))
    boundary_radius = OCR_FAST_LONG_BOUNDARY_RADIUS if fast_long_mode else OCR_BOUNDARY_RADIUS
    # Normalize region once; no pixels outside this rectangle ever reach OCR.
    def _region_value(key, alias, default):
        value = region.get(key, region.get(alias, default))
        try:
            return float(default if value is None else value)
        except (TypeError, ValueError):
            return float(default)
    rx = max(0.0, min(100.0, _region_value("x", "x", 0)))
    ry = max(0.0, min(100.0, _region_value("y", "y", 72)))
    rw = max(0.1, min(100.0-rx, _region_value("w", "width", 100)))
    rh = max(0.1, min(100.0-ry, _region_value("h", "height", 25)))

    region={"x":rx,"y":ry,"w":rw,"h":rh}
    roi_pixels = _roi_pixels(region, w, h)
    log.info("[OCR MASTER] START | %.1fs | %.2f FPS | frame=%dx%d | ROI%%=%s | ROIpx=%s | scan=%.2f FPS | workers=%d | fast_long=%s | ROI=KHÓA",duration,src_fps,w,h,region,roi_pixels,SCAN_FPS,OCR_WORKERS,fast_long_mode)
    if progress_event_cb:
        progress_event_cb({"phase":"scan","phase_done":0,"phase_total":max(1,int(math.ceil(duration*SCAN_FPS))),"overall_percent":0,"ocr_engine":"initializing"})
    # Force model initialization now so failure is immediate and explicit.
    _,engine_name=_make_engine()
    # Diagnostic mode inspects one real frame only; it never scans the whole video.
    # Enable with OCR_DIAGNOSTIC_ONLY=1 and OCR_DIAGNOSTIC_TIME=1.0 in .env.
    if os.getenv("OCR_DIAGNOSTIC_ONLY", "0").strip().lower() in {"1", "true", "yes", "on"}:
        _run_roi_diagnostic(path, region, duration, src_fps, (w, h), roi_pixels)
        _set_audit(
            diagnostic_only=True, engine=engine_name, roi=region,
            roi_pixels=list(roi_pixels), frame_size={"width": w, "height": h},
        )
        return []
    scan_started = time.monotonic()
    transition_candidates=_candidate_times(
        path, region, duration, progress_event_cb, progress_cb,
        candidate_gap=OCR_FAST_LONG_CANDIDATE_GAP if fast_long_mode else None,
    )
    scan_elapsed = time.monotonic() - scan_started
    # Short videos retain dense sampling for maximum recall. For long videos,
    # fast mode OCRs only visual transition candidates to avoid 108k+ redundant
    # OCR inferences on a two-hour source; each candidate is checked around its
    # timestamp and boundaries are estimated with a coarse visual pass.
    if use_dense_timeline:
        step = 1.0 / OCR_TIMELINE_FPS
        dense_times = [round(i * step, 4) for i in range(max(1, int(math.ceil(duration * OCR_TIMELINE_FPS))))]
        candidates = dense_times + transition_candidates
    else:
        candidates = list(transition_candidates)
    if not candidates or candidates[0]>0.7: candidates=[0.05]+candidates
    candidates=sorted(set(round(max(0.02,min(duration-0.02,x)),4) for x in candidates))
    log.info("[OCR MASTER] Lưới timeline | mode=%s | fps=%.2f | khung định kỳ=%d | đỉnh chuyển cảnh=%d | tổng probe=%d",
             "FAST-LONG" if fast_long_mode else ("DENSE" if use_dense_timeline else "TRANSITION"),
             OCR_TIMELINE_FPS if use_dense_timeline else 0.0,
             int(math.ceil(duration*OCR_TIMELINE_FPS)) if use_dense_timeline else 0,
             len(transition_candidates), len(candidates))
    recognition_started = time.monotonic()
    boundary_cap = cv2.VideoCapture(str(path))
    if boundary_cap.isOpened():
        _BOUNDARY_READER.cap = boundary_cap
        _BOUNDARY_READER.path = str(path)
    else:
        boundary_cap.release()
        boundary_cap = None
    try:
        segments=_build_master_timeline(
            path, region, candidates, duration, src_fps, progress_event_cb,
            dense_timeline=use_dense_timeline,
            boundary_fps=boundary_fps,
            boundary_radius=boundary_radius,
            quick_boundaries=fast_long_mode,
            fast_long_video=fast_long_mode,
        )
    finally:
        if boundary_cap is not None:
            boundary_cap.release()
        for attr in ("cap", "path"):
            if hasattr(_BOUNDARY_READER, attr):
                delattr(_BOUNDARY_READER, attr)
    recognition_elapsed = time.monotonic() - recognition_started
    if not segments:
        raise RuntimeError("OCR không tạo được phụ đề từ ROI. Hãy chọn ROI bao trọn đúng vùng phụ đề và chạy lại.")
    elapsed=time.monotonic()-started
    audit=get_last_audit(); audit.update({
        "duration_seconds": duration,
        "elapsed_seconds": round(elapsed, 2),
        "roi": region,
        "roi_pixels": list(roi_pixels),
        "frame_size": {"width": w, "height": h},
        "engine": engine_name,
        "scan_elapsed_seconds": round(scan_elapsed, 2),
        "recognition_and_timeline_seconds": round(recognition_elapsed, 2),
        "scan_frames_estimated": int(math.ceil(duration * SCAN_FPS)),
        "scan_frames_per_second": round(math.ceil(duration * SCAN_FPS) / max(scan_elapsed, 0.001), 2),
        "realtime_factor": round(duration / max(elapsed, 0.001), 2),
        "roi_only": True,
        "roi_crop_pixels": list(roi_pixels),
        "onnxruntime_providers": _available_ort_providers(),
    })
    _set_audit(**audit)
    if progress_event_cb:
        progress_event_cb({"phase":"audit","phase_done":1,"phase_total":1,"overall_percent":100,"segments":len(segments),"candidates":len(candidates),"needs_review":audit.get("needs_review",0),"ocr_engine":engine_name})
    log.info("[OCR MASTER] DONE | %d cues | %d candidates | review=%d | %.1fs | engine=%s",len(segments),len(candidates),audit.get("needs_review",0),elapsed,engine_name)
    if partial_cb:
        partial_cb(segments,len(segments),len(segments))
    return segments
