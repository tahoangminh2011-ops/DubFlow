(() => {
'use strict';
/* =========================================================
   1) CẤU HÌNH, NGÔN NGỮ, HẰNG SỐ
   ========================================================= */
const CFG = Object.assign({ apiBase:'', projectId:'', token:'', backUrl:'#', pollMs:1500, plan:'MAX' }, window.LINGVO_CONFIG || {});
const qs = new URLSearchParams(location.search);
[['api','apiBase'],['project','projectId'],['token','token'],['plan','plan']].forEach(([q,k]) => { const v = qs.get(q); if (v) CFG[k] = v; });
const store = { get:k=>{try{return localStorage.getItem(k)}catch(e){return null}}, set:(k,v)=>{try{localStorage.setItem(k,v)}catch(e){}} };
if (CFG.token) store.set('lingvo_token', CFG.token);
const getToken = () => store.get('lingvo_token') || '';
let lang = store.get('atv_lang') || 'vi';
const t = (vi, en) => lang === 'vi' ? vi : en;
const PLAN = String(CFG.plan || 'FREE').toUpperCase(); const isMax = () => PLAN === 'MAX'; const isPaid = () => PLAN !== 'FREE';

const LANGS = { auto:['Tự động','Auto','🌐','en-US'], vi:['Tiếng Việt','Vietnamese','🇻🇳','vi-VN'], en:['Tiếng Anh','English','🇬🇧','en-US'], ja:['Tiếng Nhật','Japanese','🇯🇵','ja-JP'], ko:['Tiếng Hàn','Korean','🇰🇷','ko-KR'], zh:['Tiếng Trung','Chinese','🇨🇳','zh-CN'], es:['Tiếng Tây Ban Nha','Spanish','🇪🇸','es-ES'], fr:['Tiếng Pháp','French','🇫🇷','fr-FR'], de:['Tiếng Đức','German','🇩🇪','de-DE'], pt:['Tiếng Bồ Đào Nha','Portuguese','🇵🇹','pt-BR'], ru:['Tiếng Nga','Russian','🇷🇺','ru-RU'], th:['Tiếng Thái','Thai','🇹🇭','th-TH'] };
const L = c => LANGS[c] || LANGS.auto;
const FONTS = ['Inter','Be Vietnam Pro','Roboto','Open Sans','Noto Sans','Lexend','Barlow'];
const EDGE_VOICES = { vi:[['vi-VN-HoaiMyNeural','Hoài My','F'],['vi-VN-NamMinhNeural','Nam Minh','M']], en:[['en-US-AvaNeural','Ava','F'],['en-US-AndrewNeural','Andrew','M']], ja:[['ja-JP-NanamiNeural','Nanami','F']], ko:[['ko-KR-SunHiNeural','Sun-Hi','F']], zh:[['zh-CN-XiaoxiaoNeural','Xiaoxiao','F']], es:[['es-ES-ElviraNeural','Elvira','F']], fr:[['fr-FR-DeniseNeural','Denise','F']], de:[['de-DE-KatjaNeural','Katja','F']], pt:[['pt-PT-RaquelNeural','Raquel','F']], ru:[['ru-RU-SvetlanaNeural','Svetlana','F']], th:[['th-TH-PremwadeeNeural','Premwadee','F']] };
let XKIRA_VOICES = [];
const voicesFor = c => EDGE_VOICES[c] || EDGE_VOICES.en;
const xkiraVoiceOptions = () => XKIRA_VOICES.map(v=>[v.id, `${v.name}${v.gender?' · '+(v.gender==='female'?'Nữ':'Nam'):''}`]);
const xkiraVoiceCards = (selected,onSelect,onPreview) => h('div',{style:{display:'grid',gridTemplateColumns:'repeat(4,minmax(0,1fr))',gap:'8px'}}, XKIRA_VOICES.slice(0,4).map(v=>h('button',{type:'button',class:'opt-card','data-on':selected===v.id,onClick:()=>onSelect(v.id),style:{minHeight:'90px',textAlign:'left',padding:'10px'}},h('div',{style:{display:'flex',justifyContent:'space-between',alignItems:'center',gap:'6px'}},h('b',{class:'trunc'},v.name||v.id),btn({icon:'volume',title:t('Nghe thử','Preview'),onClick:e=>{e.stopPropagation();onPreview(v.id);}})),h('small',{class:'muted'},v.gender==='female'?t('Nữ','Female'):v.gender==='male'?t('Nam','Male'):''),v.locale?h('small',{class:'muted'},v.locale):null)));
const edgeVoiceCards = (voices, selected, onSelect, onPreview) => h('div',{style:{display:'grid',gridTemplateColumns:'repeat(2,minmax(0,1fr))',gap:'8px'}},(voices||[]).map(v=>{const [id,name,g]=v;return h('button',{type:'button',class:'opt-card','data-on':selected===id,onClick:()=>onSelect(id),style:{minHeight:'82px',textAlign:'left',padding:'10px'}},h('div',{style:{display:'flex',justifyContent:'space-between',alignItems:'center',gap:'6px'}},h('b',{class:'trunc'},name),btn({icon:'volume',title:t('Nghe thử','Preview'),onClick:e=>{e.stopPropagation();onPreview(id);}})),h('small',{class:'muted'},g==='F'?t('Nữ · Microsoft Edge','Female · Microsoft Edge'):t('Nam · Microsoft Edge','Male · Microsoft Edge')),h('small',{class:'muted mono'},id));}));
function selectedVoiceForProject(pv){ return pv.xkiraVoice || pv.voice || pv.edgeVoice || ''; }
const DEFAULT_STYLE = { font:'Inter', size:22, color:'#ffffff', posY:88, posX:50, boxWidth:80, background:'box', bgOpacity:55, shadow:true, outline:false, bold:true, italic:false, uppercase:false, animation:'none', radius:8, shadowStrength:5, outlineWidth:2, popHighlightColor:'#FFD700', paddingY:6 };
const DEFAULT_BLUR = { enabled:false, x:10, y:70, width:80, height:20, strength:15 };
const DEFAULT_RENDER = { withSub:true, withDub:true, quality:'1080p', origVolume:20, dubVolume:100 };
const DEFAULT_PROV = { stt:'groq', translate:'groq', tts:'xkira_tts', refine:false, model:'', edgeVoice:'vi-VN-HoaiMyNeural', xkiraVoice:'', elevenVoice:'', speed:1.3 };
const STT_PROVIDERS = [ { id:'groq', name:'Groq Whisper', vi:'Whisper large-v3, độ chính xác cao, đa ngôn ngữ', en:'Whisper large-v3, high accuracy, multilingual', tags:['free'], key:'groq' }, { id:'gemini', name:'Gemini STT', vi:'Nhận dạng giọng nói bằng mô hình Gemini của Google', en:'Speech recognition powered by Google Gemini', tags:['free','trial'], key:'gemini' } ];
const TX_PROVIDERS = [ { id:'groq', name:'Groq LLM', vi:'Dịch nhanh, giữ ngữ cảnh tốt', en:'Fast translation with strong context', tags:['free'], key:'groq' }, { id:'xkira', name:'xKiro Qwen', vi:'Dùng catalog Qwen live từ xKiro', en:'Use the live Qwen catalog from xKiro', tags:['free'], key:'xkira' }, { id:'gemini', name:'Gemini LLM', vi:'Đa ngôn ngữ, ngữ cảnh dài', en:'Multilingual with long context', tags:['free','trial'], key:'gemini' } ];
const TTS_PROVIDERS = [ { id:'xkira_tts', name:'xKiro TTS', vi:'Giọng AI xKiro, danh sách giọng thật từ API', en:'xKiro AI voices, live catalog from the API', tags:['free'], key:'xkira' }, { id:'edge_tts', name:'Microsoft Edge TTS', vi:'Miễn phí, giọng tự nhiên, nhiều ngôn ngữ', en:'Free, natural voices in many languages', tags:['free'] } ];
const DEFAULT_MODELS = { deepinfra_llm:'deepseek-v3', groq_llm:'llama-3.3-70b', openai_llm:'gpt-4o-mini', gemini_llm:'gemini-2.5-flash', xkira:'qwen/qwen3.8-omni-flash:free' };

/* =========================================================
   2) API — HTTP thật (dưới apiBase) hoặc demo
   GET  /projects/:id                 PATCH /projects/:id/settings
   GET  /projects/:id/segments        PATCH/DELETE /projects/:id/segments/:idx   POST /projects/:id/segments
   POST /projects/:id/segments/:idx/translate | /dub
   POST /projects/:id/translate | /dub | /render | /transcribe | /cancel
   DELETE /projects/:id/translations | /dubbings     POST /projects/:id/segments/reset
   POST /projects/:id/voice-analysis | /visual-analysis   GET /projects/:id/voice-analysis | /visual-analysis
   PATCH /projects/:id/speakers/:sid
   GET  /settings   PATCH /settings/providers   GET /settings/:provider/models   GET /settings/elevenlabs/voices
   GET  /projects/:id/links   GET /projects/:id/download/zip
   GET  /videos/:vid/stream   GET /projects/:id/segments/:idx/audio/stream   GET /projects/:id/artifacts/:key/stream
   GET  /settings/edge-tts/voice-samples/:voice
   ========================================================= */
const num=(v,d=0)=>typeof v==='number'?v:d, str=(v,d='')=>typeof v==='string'?v:d;
const normalizeStatus=s=>({"Đang chờ xử lý":'QUEUED',"Đang xử lý":'PROCESSING',"Đang tách âm thanh":'PROCESSING',"Đang nhận diện giọng nói":'PROCESSING',"Đang dịch":'PROCESSING',"Đang tạo giọng đọc":'PROCESSING',"Đang render":'PROCESSING',"Sẵn sàng chỉnh sửa":'TRANSCRIBED',"Đã dịch":'TRANSLATED',"Đã lồng tiếng":'DUBBED',"Hoàn tất":'COMPLETED',"Lỗi":'FAILED',"Đã hủy":'CANCELLED'}[s]||s||'TRANSCRIBED');
const mapProject = r => { const ss=r.subtitle_style||{}; const pg=(r.progress&&typeof r.progress==='object')?r.progress:{}; return { id:str(r.project_id||r.id), name:str(r.video_name||r.name), videoId:str(r.video_id), src:str(r.source_lang,'en'), tgt:str(r.target_lang,'vi'), status:normalizeStatus(r.status), stage:r.stage||pg.step_name||null, progress:(typeof r.progress==='number'?r.progress:Number(pg.percentage||r.percentage||0)), queuePosition:r.queue_position??null, durationMin:num(r.video_duration_minutes), createdAt:str(r.created_at), wantDubbing:r.want_dubbing!==false, subtitleSource:r.subtitle_source==='ocr'?'ocr':(r.subtitle_source==='merged'?'merged':'stt'), ocrRegion:(()=>{const z=r.ocr_region||{};return {x:Number(z.x||0),y:Number(z.y??65),w:Number(z.w??z.width??100),h:Number(z.h??z.height??35)}})(), filterNoise:!!r.filter_transcript_noise, additionalPrompt:str(r.additional_prompt), glossary:Array.isArray(r.glossary)?r.glossary.map(g=>({source:str(g.source),target:str(g.target)})):[], latestOutputId:r.latest_output_id||null, error:r.error_message||r.error||null, translateRefine:!!r.translate_refine,
  style:Object.assign({}, DEFAULT_STYLE, cleanObj({ font:ss.font, size:ss.size, color:ss.color, posY:ss.pos_y, posX:ss.pos_x, boxWidth:ss.box_width, background:ss.background, bgOpacity:ss.bg_opacity!=null?Math.round(ss.bg_opacity*100):undefined, shadow:ss.shadow, outline:ss.outline, bold:ss.bold, italic:ss.italic, uppercase:ss.uppercase, animation:ss.animation, radius:ss.radius, shadowStrength:ss.shadow_strength, outlineWidth:ss.outline_width, popHighlightColor:ss.pop_highlight_color, paddingY:ss.padding_y })),
  blur:Object.assign({}, DEFAULT_BLUR, ss.blur_box||{}),
  ocrAdaptive:r.ocr_adaptive!==false,
  ocrAudit:(r.ocr_audit&&typeof r.ocr_audit==='object')?r.ocr_audit:null,
  ocrEngine:str(r.ocr_engine||''),
  render:Object.assign({}, DEFAULT_RENDER, r.render?cleanObj({ withSub:r.render.include_subtitle, withDub:r.render.include_dubbing, quality:r.render.quality, origVolume:r.render.orig_volume!=null?Math.round(r.render.orig_volume*100):undefined, dubVolume:r.render.dub_volume!=null?Math.round(r.render.dub_volume*100):undefined, reduceOriginalVoice:!!r.render.reduce_original_voice, originalVoiceReduction:r.render.original_voice_reduction!=null?Number(r.render.original_voice_reduction):0 }):{}) }; };
function cleanObj(o){ return Object.fromEntries(Object.entries(o).filter(([,v])=>v!==undefined)); }
const styleOut = (st, blur) => ({ font:st.font, color:st.color, size:st.size, pos_y:st.posY, pos_x:st.posX, box_width:st.boxWidth, bg_opacity:st.bgOpacity/100, background:st.background, shadow:st.shadow, outline:st.outline, bold:st.bold, italic:st.italic, uppercase:st.uppercase, animation:st.animation, radius:st.radius, shadow_strength:st.shadowStrength, outline_width:st.outlineWidth, pop_highlight_color:st.popHighlightColor, padding_y:st.paddingY, blur_box:blur });
const mapSeg = (r, fallbackTranslation='') => {
  const src = r?.source_text ?? r?.text ?? r?.source ?? r?.src ?? r?.original_text ?? '';
  const txt = r?.translated_text ?? r?.translation ?? r?.txt ?? fallbackTranslation ?? '';
  const words=Array.isArray(r?.words)?r.words:null;
  const start=num(r?.start_sec??r?.start);
  const end=num(r?.end_sec??r?.end, Math.max(start+0.05,start));
  const masterStart=Number.isFinite(Number(r?.master_start))?Number(r.master_start):null;
  const masterEnd=Number.isFinite(Number(r?.master_end))?Number(r.master_end):null;
  const sourceStart=masterStart!=null?masterStart:(Number.isFinite(Number(r?.source_start))?Number(r.source_start):start);
  const sourceEnd=masterEnd!=null?masterEnd:(Number.isFinite(Number(r?.source_end))?Number(r.source_end):end);
  const timingSource=String(r?.timing_source||'');
  const isOcr=timingSource.toLowerCase().includes('ocr') || r?.ocr_locked===true || r?.timing_locked===true;
  const ws=words?words.map(w=>Number(w?.start)).filter(Number.isFinite):[];
  const we=words?words.map(w=>Number(w?.end)).filter(Number.isFinite):[];
  const speechStart=Number.isFinite(Number(r?.speech_start))?Number(r.speech_start):(ws.length?Math.min(...ws):start);
  const speechEnd=Number.isFinite(Number(r?.speech_end))?Number(r.speech_end):(we.length?Math.max(...we):end);
  const lockedByMaster=masterStart!=null && masterEnd!=null;
  return { id:String(r?.index??r?.id), start:lockedByMaster?sourceStart:start, end:lockedByMaster?sourceEnd:end, master_start:masterStart, master_end:masterEnd, speechStart, speechEnd, source_start:sourceStart, source_end:sourceEnd, ocrLocked:!!r?.ocr_locked || isOcr || lockedByMaster, timingLocked:!!r?.timing_locked || isOcr || lockedByMaster, timingSource, src:str(src), txt:str(txt), txStatus:txt?'done':'pending', dubStatus:r?.has_dubbing?'done':(r?.dub_error?'failed':'none'), dubError:r?.dub_error||null, speed:num(r?.speed,1.3), dubStart:r?.dub_start_sec??null, dubDuration:r?.dub_duration!=null?num(r.dub_duration,0):null, parentId:r?.parent_index!=null?String(r.parent_index):null, speaker:r?.speaker_label||null, words };
};
const mapSettings = r => ({ providers:Object.assign({}, DEFAULT_PROV, cleanObj({ stt:(r.stt_provider==='xkira'?'groq':r.stt_provider), translate:r.translate_provider, tts:r.tts_provider, refine:r.translate_refine, model:r.provider_config&&r.provider_config[r.translate_provider]?r.provider_config[r.translate_provider].model:undefined, edgeVoice:r.edge_voice, xkiraVoice:r.xkira_voice, elevenVoice:r.elevenlabs_voice_id, speed:r.tts_speed })), keys:{ gemini:!!r.gemini_key_saved, groq:!!r.groq_key_saved, xkira:!!r.xkira_key_saved } });

function httpApi(base){
  base=base.replace(/\/$/,'');
  const req=async(path,init={})=>{
    const hd=new Headers(init.headers||{});
    if(init.body&&typeof init.body==='string') hd.set('Content-Type','application/json');
    const tk=getToken(); if(tk) hd.set('Authorization','Bearer '+tk);
    const r=await fetch(base+'/api'+path,Object.assign({},init,{headers:hd}));
    if(!r.ok){let m='HTTP '+r.status;try{const j=await r.json();m=j.message||j.detail||m;}catch(e){}throw new Error(m);}
    return r.status===204?null:r.json();
  };
  const J=o=>JSON.stringify(o);
  const tok=u=>{const k=getToken();return k?u+(u.includes('?')?'&':'?')+'token='+encodeURIComponent(k):u;};
  const list=d=>(Array.isArray(d)?d:(d&&d.segments)||[]).map(mapSeg);
  return {
    getProject:id=>req(`/projects/${id}`).then(mapProject),
    getSegments:async id=>{
      const d=await req(`/projects/${id}/transcript`);
      let raw=Array.isArray(d)?d:(d?.segments||[]);
      let tx=Array.isArray(d?.translated_texts)?d.translated_texts:[];
      if(!raw.length){
        const p=await req(`/projects/${id}`);
        raw=Array.isArray(p?.segments)?p.segments:[];
        tx=Array.isArray(p?.translated_texts)?p.translated_texts:tx;
      }
      return raw.map((seg,i)=>mapSeg(seg,tx[i]||''));
    },
    updateSettings:(id,o)=>req(`/projects/${id}`,{method:'PATCH',body:J(o)}),
    updateSegment:async(id,idx,o)=>{
      const n=Number(idx);
      if(!Number.isInteger(n)||n<0) throw new Error('Segment index không hợp lệ');
      const hasTiming=['start_sec','start','end_sec','end','speed','dub_start_sec','has_dubbing'].some(k=>k in (o||{}));
      if(hasTiming) return req(`/projects/${id}/segments/${n}`,{method:'PATCH',body:J(o)});
      const p=await req(`/projects/${id}`);
      const texts=(p.translated_texts||[]).slice();
      while(texts.length < (p.segments||[]).length) texts.push('');
      texts[n]=o.translated_text??o.text??o.translation??texts[n]??'';
      return req(`/projects/${id}/transcript`,{method:'PUT',body:J({texts})});
    },
    addSegment:(id,o)=>req(`/projects/${id}/segments`,{method:'POST',body:J(o)}).then(r=>mapSeg(r)),
    deleteSegment:(id,idx)=>req(`/projects/${id}/segments/${Number(idx)}`,{method:'DELETE'}),
    translateSegment:async(id,idx)=>{
      const n=Number(idx);
      if(!Number.isInteger(n)||n<0) throw new Error('Segment index không hợp lệ');
      const ctrl=new AbortController();
      const timer=setTimeout(()=>ctrl.abort(),80000);
      try{
        const r=await req(`/projects/${id}/translate-segment`,{method:'POST',body:J({segment_index:n}),signal:ctrl.signal});
        return {id:String(r.index??r.segment_index??n),start:Number(r.start||0),end:Number(r.end||0),src:String(r.original||''),txt:String(r.translation??r.translated_text??''),txStatus:'done',dubStatus:'none'};
      }catch(e){ if(e&&e.name==='AbortError') throw new Error('Dịch lại quá thời gian 80 giây. Vui lòng thử lại.'); throw e; }
      finally{ clearTimeout(timer); }
    },
    dubSegment:(id,idx)=>{ const n=Number(idx); const pv=providers(); return req(`/projects/${id}/tts`,{method:'POST',body:J({segment_index:n,provider:pv.tts||'xkira_tts',voice:pv.tts==='xkira_tts'?(pv.xkiraVoice||''):((pv.edgeVoice||'vi-VN-HoaiMyNeural')),language:S.p?.tgt||'vi',sync_to_original_timing:true,rate:Number(pv.speed||1.3)})}); },
    startJob:(id,mode,body)=>{
      if(mode==='render') return req(`/projects/${id}/render`,{method:'POST',body:J(body||{})});
      if(mode==='dub') return req(`/projects/${id}/tts-all`,{method:'POST',body:J(body||{})});
      if(mode==='translate') return req(`/projects/${id}/translate`,{method:'POST',body:J(body||{})});
      if(mode==='transcribe'){ const payload=Object.assign({},body||{}, {subtitle_source:body?.subtitle_source||S.p?.subtitleSource||'stt',ocr_region:S.p?.ocrRegion||body?.ocr_region||null}); if(payload.action==='merge') return req(`/projects/${id}/merge-timeline`,{method:'POST',body:'{}'}); return req(`/projects/${id}/reprocess-analysis`,{method:'POST',body:J(payload)}); }
      return req(`/projects/${id}/process`,{method:'POST',body:'{}'});
    },
    reviewTranslations:(id,full=false)=>req(`/projects/${id}/review-translations`,{method:'POST',body:J({full:!!full})}),
    cancel:id=>req(`/projects/${id}/cancel`,{method:'POST',body:J({})}),
    clearTranslations:id=>req(`/projects/${id}/translations`,{method:'DELETE'}),
    deleteTranslation:(id,idx)=>req(`/projects/${id}/translation/${Number(idx)}`,{method:'DELETE'}),
    clearDubbings:id=>req(`/projects/${id}/dubbing`,{method:'DELETE'}),
    resetSegments:id=>req(`/projects/${id}/transcript`).then(list),
    getSettings:async()=>{ const keys=await req('/settings/keys').catch(()=>({})); const d=await req('/settings/providers').catch(()=>({})); return {providers:Object.assign({},DEFAULT_PROV,d),keys}; },
    saveProviders:o=>req('/settings/providers',{method:'POST',body:J(o)}),
    getXkiraVoices:(refresh=false)=>req(`/tts/voices?language=vi&limit=4&refresh=${refresh?'1':'0'}`).catch(()=>[]),
    previewVoice:async(voice,provider='xkira_tts',language='vi')=>{ const r=await fetch(base+'/api/tts/preview',{method:'POST',headers:{'Content-Type':'application/json',...(getToken()?{Authorization:'Bearer '+getToken()}: {})},body:J({text:'Xin chào, đây là giọng đọc thử của Lingvo.',voice,provider,language,rate:1.3,pitch:0})}); if(!r.ok){let m='Không tạo được audio thử';try{const j=await r.json();m=j.detail||j.message||m;}catch(e){} throw new Error(m);} const blob=await r.blob(); if(!blob.size) throw new Error('Audio thử rỗng'); return URL.createObjectURL(blob); },
    getModels:async(provider)=>{ const p=String(provider||''); return req(`/settings/${encodeURIComponent(p)}/models`).catch(()=>[]); },
    getElevenVoices:async()=>[],
    getAnalysis:(id,kind)=>req(`/projects/${id}/${kind==='voice'?'voice-analysis':'visual-analysis'}`),
    startAnalysis:(id,kind,force)=>req(`/projects/${id}/${kind==='voice'?'voice-analysis':'visual-analysis'}`,{method:'POST',body:J({force:!!force})}),
    saveSpeaker:(id,sid,o)=>req(`/projects/${id}/speakers/${encodeURIComponent(sid)}`,{method:'PATCH',body:J(o)}),
    getLinks:id=>req(`/projects/${id}/links`).then(x=>Object.fromEntries(Object.entries(x||{}).map(([k,v])=>[k,tok(base+v)+'&download=1']))),
    getZip:id=>Promise.resolve(tok(`${base}/api/projects/${id}/download?type=zip`)),
    videoUrl:id=>tok(`${base}/api/projects/${id}/stream?cb=${Date.now()}`),
    dubUrl:(id,idx)=>tok(`${base}/api/projects/${id}/download?type=audio&segment=${idx}`),
    artUrl:()=>null,
    sampleUrl:()=>null,
  };
}
function demoApi(){
  const VIDEO='https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4';
  const lines=[[0,4.2,'Good morning everyone, and welcome back to the channel.','Chào buổi sáng mọi người, chào mừng quay lại với kênh.'],[4.2,9.1,'Today we are watching a short film about a very big rabbit.','Hôm nay chúng ta sẽ xem một phim ngắn về một chú thỏ rất to.'],[9.1,14.6,'He lives in a quiet meadow full of flowers and butterflies.','Chú sống trong một đồng cỏ yên tĩnh đầy hoa và bướm.'],[14.6,19.8,'Every morning he wakes up slowly and stretches in the sun.','Mỗi sáng chú thức dậy thật chậm rãi và vươn vai dưới nắng.'],[19.8,25.4,'But three small rodents in the forest have other plans.','Nhưng ba con gặm nhấm nhỏ trong rừng lại có kế hoạch khác.'],[25.4,30.9,'They love to tease him and steal the fruit he collects.',''],[30.9,36.3,'At first, the rabbit tries to ignore them and stay calm.',''],[36.3,41.7,'Then one afternoon they go too far and break his favorite flower.',''],[41.7,47.5,'That is the moment our gentle hero decides to fight back.',''],[47.5,53.2,'He builds clever traps using only sticks, vines and stones.',''],[53.2,58.8,'The whole plan is silly, sweet and surprisingly satisfying.',''],[58.8,64.4,'Stay with me until the end, because the finale is worth it.',''],[64.4,70.1,'If you enjoy this, remember to like and subscribe.',''],[70.1,75.6,"Let's get started.",'']];
  const VI={5:'Chúng thích trêu chọc chú và cướp những trái cây chú nhặt được.',6:'Ban đầu, chú thỏ cố gắng lờ đi và giữ bình tĩnh.',7:'Rồi một buổi chiều, chúng đi quá xa và bẻ gãy bông hoa chú yêu thích.',8:'Đó là khoảnh khắc người hùng hiền lành quyết định đáp trả.',9:'Chú dựng những cái bẫy khéo léo chỉ bằng que, dây leo và đá.',10:'Toàn bộ kế hoạch vừa ngớ ngẩn, dễ thương lại bất ngờ thỏa mãn.',11:'Hãy ở lại đến cuối, vì màn kết rất đáng xem.',12:'Nếu bạn thích, hãy nhớ bấm thích và đăng ký kênh nhé.',13:'Chúng ta bắt đầu thôi.'};
  const st={ project:mapProject({project_id:'prj_demo',video_name:'Big Buck Bunny · review ngắn.mp4',video_id:'vid_demo',source_lang:'en',target_lang:'vi',status:'TRANSCRIBED',video_duration_minutes:9.9,created_at:new Date().toISOString()}), segs:lines.map(([s,e,src,txt],i)=>mapSeg({index:i,start_sec:s,end_sec:e,source_text:src,translated_text:txt,has_dubbing:i<3})), job:null,
    settings:{ providers:Object.assign({},DEFAULT_PROV,{edgeVoice:'vi-VN-HoaiMyNeural',xkiraVoice:''}), keys:{openai:false,gemini:true,groq:false,elevenlabs:false} }, voice:{status:'NONE',speakers:[]}, visual:{status:'NONE',summary:'',scenes:[]} };
  const wait=ms=>new Promise(r=>setTimeout(r,ms)); const clone=v=>JSON.parse(JSON.stringify(v)); const seg=idx=>st.segs.find(s=>s.id===String(idx));
  function tick(){ const j=st.job; if(!j) return; j.i++; const p=st.project;
    if(j.mode==='translate'){ const s=st.segs.find(x=>x.txStatus!=='done'); if(s){ s.txt=VI[+s.id]||s.src; s.txStatus='done'; } p.progress=Math.round(100*st.segs.filter(x=>x.txStatus==='done').length/st.segs.length); if(!st.segs.some(x=>x.txStatus!=='done')){ st.job=null; p.status='TRANSLATED'; p.stage=null; } }
    else if(j.mode==='dub'){ const s=st.segs.find(x=>x.txStatus==='done'&&x.dubStatus!=='done'); if(s) s.dubStatus='done'; p.progress=Math.round(100*st.segs.filter(x=>x.dubStatus==='done').length/st.segs.length); if(!st.segs.some(x=>x.txStatus==='done'&&x.dubStatus!=='done')){ st.job=null; p.status='DUBBED'; p.stage=null; } }
    else if(j.mode==='transcribe'){ p.progress=Math.min(100,p.progress+12); if(j.i===2) p.stage='EXTRACT_AUDIO'; if(j.i===4) p.stage='STT'; if(p.progress>=100){ st.job=null; p.status='TRANSCRIBED'; p.stage=null; st.segs=lines.map(([s,e,src],i)=>mapSeg({index:i,start_sec:s,end_sec:e,source_text:src})); } }
    else { p.progress=Math.min(100,p.progress+7); if(j.i===2){ p.stage='RENDER'; p.queuePosition=null; } if(p.progress>=100){ st.job=null; p.status='COMPLETED'; p.stage=null; p.latestOutputId='out_demo'; } }
    if(st.job) setTimeout(tick, j.mode==='render'?350:600); }
  const runAnalysis=(kind,force)=>{ const a=st[kind]; if(a.status==='RUNNING'||a.status==='QUEUED') return; a.status='QUEUED'; setTimeout(()=>{a.status='RUNNING';},1200); setTimeout(()=>{ a.status='DONE'; if(kind==='voice'){ a.speakers=[{id:'spk1',label:t('Người nói 1','Speaker 1'),gender:'male',segments:9,voice:''},{id:'spk2',label:t('Người nói 2','Speaker 2'),gender:'female',segments:5,voice:''}]; st.segs.forEach((s,i)=>{ s.speaker=i%3===2?t('Người nói 2','Speaker 2'):t('Người nói 1','Speaker 1'); }); } else { a.summary=t('Phim hoạt hình 3D về một chú thỏ lớn sống trong đồng cỏ; bối cảnh thiên nhiên tươi sáng, ba loài gặm nhấm gây rối, tông hài hước nhẹ nhàng.','A 3D animated short about a big rabbit living in a meadow; bright natural scenery, three mischievous rodents, light-hearted comedic tone.'); a.scenes=[{start:0,end:20,text:t('Đồng cỏ buổi sáng, thỏ thức dậy và vươn vai.','Morning meadow, the rabbit wakes up and stretches.')},{start:20,end:42,text:t('Ba con gặm nhấm xuất hiện, trêu chọc và ném quả.','Three rodents appear, teasing and throwing fruit.')},{start:42,end:76,text:t('Thỏ lên kế hoạch và dựng bẫy trong rừng.','The rabbit plans and builds traps in the forest.')}]; } },4200); if(force&&kind==='voice') a.speakers=[]; };
  return {
    async getProject(){ await wait(80); return clone(st.project); }, async getSegments(){ await wait(120); return clone(st.segs); },
    async updateSettings(_i,o){ await wait(120); if(o.source_lang) st.project.src=o.source_lang; if(o.target_lang) st.project.tgt=o.target_lang; return o; },
    async updateSegment(_i,idx,o){ await wait(100); const s=seg(idx); if(!s) return; if(o.translated_text!==undefined){ s.txt=o.translated_text; s.txStatus=s.txt?'done':'pending'; s.dubStatus='none'; } if(o.source_text!==undefined) s.src=o.source_text; if(o.start_sec!==undefined) s.start=o.start_sec; if(o.end_sec!==undefined) s.end=o.end_sec; if(o.speed!==undefined) s.speed=o.speed; if(o.dub_start_sec!==undefined) s.dubStart=o.dub_start_sec; if(o.has_dubbing===false) s.dubStatus='none'; },
    async addSegment(_i,o){ await wait(100); const id=String(Math.max(-1,...st.segs.map(s=>+s.id))+1); const s=mapSeg({index:id,start_sec:o.start_sec,end_sec:o.end_sec,source_text:o.source_text||'',translated_text:o.translated_text||'',parent_index:o.parent_index}); st.segs.push(s); st.segs.sort((a,b)=>a.start-b.start); return clone(s); },
    async deleteSegment(_i,idx){ await wait(80); st.segs=st.segs.filter(s=>s.id!==String(idx)); },
    async translateSegment(_i,idx){ await wait(1100); const s=seg(idx); s.txt=VI[+s.id]||s.txt||s.src; s.txStatus='done'; return clone(s); },
    async dubSegment(_i,idx){ await wait(1300); const s=seg(idx); s.dubStatus='done'; return clone(s); },
    async startJob(_i,mode){ await wait(150); st.job={mode,i:0}; const p=st.project; p.status='PROCESSING'; p.progress=0; p.stage=mode==='render'||mode==='transcribe'?'QUEUING':mode==='dub'?'TTS':'TRANSLATE'; if(mode==='render') p.queuePosition=1; setTimeout(tick,700); },
    async cancel(){ await wait(80); st.job=null; st.project.status='CANCELLED'; st.project.stage=null; },
    async clearTranslations(){ await wait(80); st.segs.forEach(s=>{s.txt='';s.txStatus='pending';s.dubStatus='none';}); }, async clearDubbings(){ await wait(80); st.segs.forEach(s=>{s.dubStatus='none';}); },
    async resetSegments(){ await wait(200); st.segs=lines.map(([s,e,src],i)=>mapSeg({index:i,start_sec:s,end_sec:e,source_text:src})); return clone(st.segs); },
    async getSettings(){ await wait(80); return clone(st.settings); }, async saveProviders(o){ await wait(120); Object.assign(st.settings.providers,o); }, async getModels(p){ await wait(120); if(p==='xkira') return ['qwen/qwen-plus-2025-07-28:free','qwen/qwen3-coder-plus:free','qwen/qwen3-max:free','qwen/qwen3-omni-flash:free','qwen/qwen3-vl-plus:free','qwen/qwen3.5-397b-a17b:free','qwen/qwen3.5-flash:free','qwen/qwen3.5-omni-flash:free','qwen/qwen3.5-omni-plus:free','qwen/qwen3.5-plus:free','qwen/qwen3.6-27b:free','qwen/qwen3.6-35b-a3b:free','qwen/qwen3.6-max-preview:free','qwen/qwen3.6-plus:free','qwen/qwen3.7-flash:free','qwen/qwen3.7-max:free','qwen/qwen3.7-plus:free','qwen/qwen3.8-max:free','qwen/qwen3.8-omni-flash:free','qwen/qwen3.5-plus','qwen/qwen3.7-max','qwen/qwen3.7-plus','qwen/qwen3.8-max']; return {deepinfra_llm:['deepseek-v3','deepseek-r1'],groq_llm:['llama-3.3-70b-versatile','llama-3.1-8b-instant'],openai_llm:['gpt-4o-mini','gpt-4o','gpt-4.1'],gemini_llm:['gemini-2.5-flash','gemini-2.5-pro']}[p]||[]; }, async getElevenVoices(){ await wait(400); return [{id:'ev1',name:'Rachel'},{id:'ev2',name:'Adam'},{id:'ev3',name:'Bella'}]; },
    async getAnalysis(_i,kind){ await wait(60); return clone(st[kind]); }, async startAnalysis(_i,kind,force){ await wait(150); runAnalysis(kind,force); }, async saveSpeaker(_i,sid,o){ await wait(100); const s=st.voice.speakers.find(x=>x.id===sid); if(s) Object.assign(s,o); },
    async getLinks(){ await wait(150); const l={transcript_srt:'#',video_original:VIDEO,audio_original:'#',project_config:'#'}; if(st.segs.some(s=>s.txStatus==='done')) l.translated_srt='#'; if(st.segs.some(s=>s.dubStatus==='done')) l.audio_dubbing='#'; if(st.project.status==='COMPLETED') l.video_final=VIDEO; return l; },
    async getZip(){ return '#'; }, videoUrl:()=>VIDEO, dubUrl:()=>'', artUrl:(_i,k)=>k.startsWith('video')?VIDEO:'', sampleUrl:()=>'',
  };
}
const demoApiInstance = demoApi();
const httpApiInstance = CFG.apiBase ? httpApi(CFG.apiBase) : null;
let api = null;

/* =========================================================
   3) TRẠNG THÁI & DOM HELPERS
   ========================================================= */
const S = { p:null, segs:[], sel:null, showLang:false, query:'', side:false, sideKey:'style', mtab:'segment', tlOpen:false, pps:40, time:0, dur:0, playing:false, vol:{orig:20,dub:100}, editing:null, busyJob:null, jobLabel:'', ctxMenu:null, stageW:0, stageH:0, natW:16, natH:9, settings:null, models:{}, elevenVoices:[], voice:{status:'NONE',speakers:[]}, visual:{status:'NONE',summary:'',scenes:[]}, collapsed:{}, audioPlaying:null, fitAll:store.get('atv_fit_duration')!=='0', conn:'offline', connError:'', connBarClosed:false };
const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>Array.from(r.querySelectorAll(s)), clamp=(v,a,b)=>Math.min(Math.max(v,a),b);
const isMobile=()=>window.innerWidth<=900;
function h(tag,attrs,...kids){ const el=document.createElement(tag); if(attrs) for(const [k,v] of Object.entries(attrs)){ if(v==null||v===false) continue; if(k==='class') el.className=v; else if(k==='style'&&typeof v==='object') Object.assign(el.style,v); else if(k.startsWith('on')&&typeof v==='function') el.addEventListener(k.slice(2).toLowerCase(),v); else if(v===true) el.setAttribute(k,''); else el.setAttribute(k,v);} for(const c of kids.flat(Infinity)){ if(c==null||c===false) continue; el.append(c instanceof Node?c:document.createTextNode(String(c))); } return el; }
const IC={arrowLeft:'<path d="m12 19-7-7 7-7"/><path d="M19 12H5"/>',arrowRight:'<path d="M5 12h14"/><path d="m12 5 7 7-7 7"/>',captions:'<rect width="18" height="14" x="3" y="5" rx="2"/><path d="M7 15h4M15 15h2M7 11h2M13 11h4"/>',audio:'<path d="M2 10v3"/><path d="M6 6v11"/><path d="M10 3v18"/><path d="M14 8v7"/><path d="M18 5v13"/><path d="M22 10v3"/>',user:'<path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',eye:'<path d="M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0"/><circle cx="12" cy="12" r="3"/>',settings:'<path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/>',help:'<circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><path d="M12 17h.01"/>',film:'<rect width="18" height="18" x="3" y="3" rx="2"/><path d="M7 3v18"/><path d="M3 7.5h4"/><path d="M3 12h18"/><path d="M3 16.5h4"/><path d="M17 3v18"/><path d="M17 7.5h4"/><path d="M17 16.5h4"/>',globe:'<circle cx="12" cy="12" r="10"/><path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"/><path d="M2 12h20"/>',plus:'<path d="M5 12h14"/><path d="M12 5v14"/>',more:'<circle cx="12" cy="12" r="1"/><circle cx="12" cy="5" r="1"/><circle cx="12" cy="19" r="1"/>',search:'<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',x:'<path d="M18 6 6 18"/><path d="m6 6 12 12"/>',volume:'<polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14"/>',languages:'<path d="m5 8 6 6"/><path d="m4 14 6-6 2-3"/><path d="M2 5h12"/><path d="M7 2h1"/><path d="m22 22-5-10-5 10"/><path d="M14 18h6"/>',refresh:'<path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"/><path d="M8 16H3v5"/>',loader:'<path d="M21 12a9 9 0 1 1-6.219-8.56"/>',play:'<path d="M6 3 20 12 6 21z"/>',pause:'<rect x="14" y="4" width="4" height="16" rx="1"/><rect x="6" y="4" width="4" height="16" rx="1"/>',skipBack:'<polygon points="19 20 9 12 19 4 19 20"/><line x1="5" x2="5" y1="19" y2="5"/>',chevUp:'<path d="m18 15-6-6-6 6"/>',chevDown:'<path d="m6 9 6 6 6-6"/>',chevLeft:'<path d="m15 18-6-6 6-6"/>',mic:'<path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" x2="12" y1="19" y2="22"/>',menu:'<line x1="4" x2="20" y1="12" y2="12"/><line x1="4" x2="20" y1="6" y2="6"/><line x1="4" x2="20" y1="18" y2="18"/>',alert:'<path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3"/><path d="M12 9v4"/><path d="M12 17h.01"/>',check:'<path d="M20 6 9 17l-5-5"/>',trash:'<path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/>',scissors:'<circle cx="6" cy="6" r="3"/><path d="M8.12 8.12 12 12"/><path d="M20 4 8.12 15.88"/><circle cx="6" cy="18" r="3"/><path d="M14.8 14.8 20 20"/>',sparkles:'<path d="M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z"/>',download:'<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" x2="12" y1="15" y2="3"/>',clock:'<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',lock:'<rect width="18" height="11" x="3" y="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',sun:'<circle cx="12" cy="12" r="4"/><path d="M12 2v2"/><path d="M12 20v2"/><path d="m4.93 4.93 1.41 1.41"/><path d="m17.66 17.66 1.41 1.41"/><path d="M2 12h2"/><path d="M20 12h2"/><path d="m6.34 17.66-1.41 1.41"/><path d="m19.07 4.93-1.41 1.41"/>',moon:'<path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/>',zoomIn:'<circle cx="11" cy="11" r="8"/><line x1="21" x2="16.65" y1="21" y2="16.65"/><line x1="11" x2="11" y1="8" y2="14"/><line x1="8" x2="14" y1="11" y2="11"/>',zoomOut:'<circle cx="11" cy="11" r="8"/><line x1="21" x2="16.65" y1="21" y2="16.65"/><line x1="8" x2="14" y1="11" y2="11"/>',info:'<circle cx="12" cy="12" r="10"/><path d="M12 16v-4"/><path d="M12 8h.01"/>',ok:'<circle cx="12" cy="12" r="10"/><path d="m9 12 2 2 4-4"/>',err:'<circle cx="12" cy="12" r="10"/><path d="m15 9-6 6"/><path d="m9 9 6 6"/>',image:'<rect width="18" height="18" x="3" y="3" rx="2" ry="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"/>'};
function ic(n,s=16,c=''){ const e=document.createElementNS('http://www.w3.org/2000/svg','svg'); e.setAttribute('viewBox','0 0 24 24'); e.setAttribute('width',s); e.setAttribute('height',s); e.setAttribute('fill','none'); e.setAttribute('stroke','currentColor'); e.setAttribute('stroke-width','2'); e.setAttribute('stroke-linecap','round'); e.setAttribute('stroke-linejoin','round'); e.innerHTML=IC[n]||''; if(c) e.setAttribute('class',c); return e; }
function btn({v='ghost',sm=true,icon,label,title,onClick,disabled,cls='',busy,attrs}){ const b=h('button',Object.assign({type:'button',class:`btn btn-${v} ${sm?'btn-sm':''} ${label?'':'btn-icon'} ${cls}`,title,disabled:!!disabled,onClick},attrs||{})); if(busy) b.append(ic('loader',sm?14:16,'spin')); else if(icon) b.append(ic(icon,sm?14:16)); if(label) b.append(h('span',null,label)); return b; }
const sw=(on,fn)=>h('button',{type:'button',class:'switch',role:'switch','data-on':on,onClick:e=>{e.stopPropagation();fn(!e.currentTarget.hasAttribute('data-on'));}},h('i'));
const cb=(on,fn)=>h('button',{type:'button',class:'checkbox','data-on':on,onClick:e=>{e.stopPropagation();fn(!e.currentTarget.hasAttribute('data-on'));}},ic('check',11));
const sel=(opts,val,fn,attrs)=>{ const s=h('select',Object.assign({class:'input',onChange:e=>fn(e.target.value)},attrs||{})); opts.forEach(([v,l])=>s.append(h('option',{value:v},l))); s.value=val; return s; };
const fmt=(s,dec=1)=>{ s=Math.max(0,s||0); const m=Math.floor(s/60), r=s-m*60; return String(m).padStart(2,'0')+':'+(dec?String(Math.floor(r)).padStart(2,'0')+'.'+Math.floor(r%1*10):String(Math.floor(r)).padStart(2,'0')); };
function toast(msg,variant='info'){ const col={success:'var(--success)',error:'var(--destructive)',warning:'var(--warning)',info:'var(--primary)'}[variant]; const icn=ic({success:'ok',error:'err',warning:'alert',info:'info'}[variant],17); icn.style.color=col; icn.style.flexShrink='0'; const el=h('div',{class:'toast',style:{borderLeftColor:col}},icn,h('div',{class:'grow'},msg),btn({icon:'x',onClick:()=>el.remove()})); $('#toasts').append(el); setTimeout(()=>{el.classList.add('out');setTimeout(()=>el.remove(),220);},4200); }
function dialog({title,desc,body,footer,onClose,width,lock}){ const root=$('#layers'); const wrap=h('div',{class:'overlay',onMousedown:e=>{ if(e.target===e.currentTarget&&!lock) close(); }}); const close=()=>{ wrap.remove(); document.removeEventListener('keydown',esc); onClose&&onClose(); }; const esc=e=>{ if(e.key==='Escape'&&!lock) close(); }; document.addEventListener('keydown',esc); const dlg=h('div',{class:'dialog',role:'dialog',style:width?{maxWidth:width+'px'}:null},h('div',{style:{display:'flex',justifyContent:'space-between',alignItems:'flex-start',gap:'10px'}},h('div',null,h('div',{class:'dlg-title'},title),desc?h('div',{class:'dlg-desc'},desc):null),lock?null:btn({icon:'x',onClick:close}))); if(body) dlg.append(h('div',{style:{marginTop:'16px'}},body)); if(footer) dlg.append(h('div',{class:'dlg-foot'},...footer(close))); wrap.append(dlg); root.append(wrap); return close; }
const confirmDlg=({title,desc,confirmLabel,variant='destructive'})=>new Promise(res=>{ dialog({title,desc,footer:close=>[btn({v:'ghost',sm:false,label:t('Hủy','Cancel'),onClick:()=>{close();res(false);}}),btn({v:variant,sm:false,label:confirmLabel,onClick:()=>{close();res(true);}})],onClose:()=>res(false)}); });
function emptyState(icon,title,desc,showDemoBtn){ return h('div',{class:'empty-state'}, h('div',{class:'es-ic'},ic(icon,20)), h('div',{class:'es-t'},title), desc?h('div',{class:'es-d'},desc):null, showDemoBtn?btn({v:'outline',icon:'sparkles',label:t('Xem dữ liệu minh hoạ','Preview sample data'),onClick:()=>loadDemoPreview()}):null); }
const P=()=>S.p; const segById=id=>S.segs.find(s=>s.id===id); const segAt=tm=>S.segs.find((s,i)=>tm>=s.start&&(tm<s.end||(i===S.segs.length-1&&tm<=s.end)))||null;
const busy=()=>S.p&&(S.p.status==='PROCESSING'||S.p.status==='QUEUED');
const saveSettings=o=>api.updateSettings(S.p.id,o).catch(()=>toast(t('Lưu cài đặt thất bại','Failed to save settings'),'error'));
const saveStyle=()=>saveSettings({subtitle_style:styleOut(S.p.style,S.p.blur)});
const providers=()=>S.settings?S.settings.providers:DEFAULT_PROV;

/* =========================================================
   4) HÀNH ĐỘNG PHÂN ĐOẠN / TÁC VỤ / POLL
   ========================================================= */
function normalizeTimelineForUi(list){
  // V20: UI is a read-only projection of the MASTER TIMELINE.
  // Never clamp, trim, sort, or otherwise alter source start/end here.
  return Array.isArray(list) ? list.map(x=>Object.assign({},x)) : [];
}
function selectSeg(id,{seek=true,scroll=false}={}){ S.sel=id; $$('.seg-card').forEach(c=>c.toggleAttribute('data-sel',c.dataset.id===id)); const s=segById(id); if(s&&seek) seekTo(S.p?.subtitleSource==='ocr'?subtitleSpan(s)[0]:s.start); if(scroll){ const c=$(`.seg-card[data-id="${id}"]`); c&&c.scrollIntoView({block:'nearest'}); } drawTimeline(); }
async function translateSeg(id){
  id=String(id); const s=segById(id); if(!s||s.txStatus==='running') return;
  s.txStatus='running'; renderSegList();
  try{ const r=await api.translateSegment(S.p.id,Number(id));
    Object.assign(s,{id:String(r.id??id),start:Number(r.start??s.start),end:Number(r.end??s.end),src:String(r.src??s.src),txt:String(r.txt??''),txStatus:'done',dubStatus:'none',dubError:null});
    toast(t('Đã dịch lại phân đoạn','Segment re-translated'),'success');
  }catch(e){ s.txStatus=s.txt?'done':'pending'; toast(e.message||t('Dịch lại thất bại','Re-translate failed'),'error'); }
  renderSegList(); drawTimeline(); updateSub();
}

async function dubSeg(id){ id=Number(id); const s=segById(String(id)); if(!s||s.txStatus!=='done'||s.dubStatus==='running') return; s.dubStatus='running'; renderSegList(); try{ const r=await api.dubSegment(S.p.id,id); if(r){ Object.assign(s,r); const st=Number(r.dub_start_sec??r.start_sec??s.speechStart??s.start??0); const du=Number(r.dub_duration??r.duration??0); s.dubStart=st; s.dubDuration=du; s.dub_end_sec=st+Math.max(0,du); s.dubStatus='done'; } else s.dubStatus='done'; s.dubError=null; }catch(e){ s.dubStatus='failed'; s.dubError=e.message; toast(e.message||t('Lồng tiếng thất bại','Dubbing failed'),'error'); } renderSegList(); drawTimeline(); }
function saveText(id,txt){ const s=segById(id); if(!s) return; const changed=txt!==s.txt; s.txt=txt; s.txStatus=txt?'done':'pending'; if(changed&&s.dubStatus==='done') s.dubStatus='none'; renderSegList(); drawTimeline(); updateSub(); if(changed) api.updateSegment(S.p.id,id,{translated_text:txt}).catch(()=>toast(t('Lưu bản dịch thất bại','Failed to save translation'),'error')); }
async function deleteSeg(id){ const ok=await confirmDlg({title:t('Xóa phân đoạn','Delete segment'),desc:t('Phân đoạn này (kèm bản dịch và lồng tiếng) sẽ bị xóa khỏi dự án và không thể khôi phục.','This segment, with its translation and dubbing, will be removed from the project and cannot be restored.'),confirmLabel:t('Xóa','Delete')}); if(!ok) return; try{await api.deleteSegment(S.p.id,id);S.segs=S.segs.filter(s=>s.id!==id);if(S.sel===id)S.sel=null;renderSegs();drawTimeline();}catch(e){toast(e.message||t('Xóa phân đoạn thất bại','Delete segment failed'),'error');} }
async function addSeg(after){ const prev=after?segById(after):null; const start=prev?prev.end:0; const next=S.segs.find(s=>s.start>=start+0.05); const end=Math.max(start+0.5,Math.min(start+3,next?next.start:start+3)); try{ const s=await api.addSegment(S.p.id,{start_sec:+start.toFixed(2),end_sec:+end.toFixed(2),source_text:''}); S.segs.push(s); S.segs.sort((a,b)=>a.start-b.start); renderSegs(); drawTimeline(); selectSeg(s.id,{scroll:true}); }catch(e){ toast(e.message,'error'); } }
function updateTiming(id,start,end){ const s=segById(id); if(!s) return; s.start=Number(start); s.end=Number(end); const payload={start_sec:s.start,end_sec:s.end}; if(S.p.subtitleSource==='ocr'||s.ocrLocked){ s.source_start=s.start; s.source_end=s.end; payload.source_start=s.start; payload.source_end=s.end; } renderSegList(); drawTimeline(); api.updateSegment(S.p.id,id,payload).catch(()=>toast(t('Lưu thời gian thất bại','Failed to save timing'),'error')); }
async function runJob(mode,body,label){ if(busy()) return; try{ if(mode==='dub'){ const pv=providers(); body=Object.assign({provider:pv.tts||'xkira_tts',voice:pv.tts==='xkira_tts'?(pv.xkiraVoice||''): (pv.edgeVoice||'vi-VN-HoaiMyNeural'),rate:Number(pv.speed||1.3)},body||{}); } await api.startJob(S.p.id,mode,body); S.busyJob=mode; S.jobLabel=label; Object.assign(S.p,{status:'PROCESSING',stage:mode==='render'||mode==='transcribe'?'QUEUING':mode==='dub'?'TTS':'TRANSLATE',progress:0}); startPolling(); renderTop(); renderSegs(); renderStageInfo(); if(mode==='render'||mode==='transcribe') showProcessing(); }catch(e){ toast(e.message||t('Không thể bắt đầu tác vụ','Could not start the job'),'error'); } }
async function cancelJob(){ try{ await api.cancel(S.p.id); S.p.status='CANCELLED'; S.p.stage=null; S.busyJob=null; toast(t('Đã hủy tác vụ','Job cancelled'),'warning'); closeProcessing(); renderAll(); }catch(e){ toast(e.message,'error'); } }
let pollTimer=null, polling=false;
function startPolling(){ if(!pollTimer) pollTimer=setInterval(poll,CFG.pollMs); }
async function poll(){ if(polling||!S.p) return; polling=true; try{ const p=await api.getProject(S.p.id); const wasBusy=busy(); Object.assign(S.p,{status:p.status,stage:p.stage,progress:p.progress,queuePosition:p.queuePosition,latestOutputId:p.latestOutputId,error:p.error,translationMissingSegments:Array.isArray(p.translation_missing_segments)?p.translation_missing_segments:(S.p.translationMissingSegments||[])}); const segs=await api.getSegments(S.p.id); const map=new Map(segs.map(s=>[s.id,s])); S.segs=S.segs.map(s=>{ const n=map.get(s.id); if(!n) return s; return Object.assign({},n,{txStatus:s.txStatus==='running'?'running':n.txStatus,dubStatus:s.dubStatus==='running'?'running':n.dubStatus}); }); segs.forEach(n=>{ if(!segById(n.id)) S.segs.push(n); }); if(S.busyJob==='transcribe'&&!busy()) S.segs=segs; renderSegList(); drawTimeline(); renderProcessing(); renderStageInfo(); if(wasBusy&&!busy()){ clearInterval(pollTimer); pollTimer=null; const mode=S.busyJob; S.busyJob=null; await onJobDone(mode); renderAll(); } else { renderTop(); renderSegHead(); } }catch(e){} finally{ polling=false; } }
async function onJobDone(mode){ const p=S.p; if(p.status==='FAILED'){ toast(p.error||t('Xử lý thất bại','Processing failed'),'error'); closeProcessing(); return; } if(p.status==='CANCELLED'){ closeProcessing(); return; } if(mode==='translate') toast(t('Đã dịch xong toàn bộ phân đoạn','All segments translated'),'success'); if(mode==='dub') toast(t('Đã lồng tiếng xong','Dubbing complete'),'success'); if(mode==='transcribe'){ toast(t('Đã phân tích lại phụ đề','Transcript re-run complete'),'success'); closeProcessing(); } if(mode==='render'){ toast(t('Kết xuất video thành công','Video rendered successfully'),'success'); closeProcessing(); showResults(); } }

/* =========================================================
   5) THANH TRÊN
   ========================================================= */
function renderTop(){ const top=$('#top'); top.innerHTML=''; const p=S.p; const m=isMobile();
  top.append(btn({icon:'arrowLeft',title:t('Quay lại','Back'),onClick:()=>{ try{ const p=new URLSearchParams(location.search); p.set('page','app'); p.delete('project'); location.href=location.pathname+'?'+p.toString(); }catch(e){ location.href=CFG.backUrl; } }}));
  if(!m) top.append(h('div',{class:'logo'},h('img',{class:'lm-light',src:'https://translatevideo.flowai.website/logo-mark-light.png',alt:''}),h('img',{class:'lm-dark',src:'https://translatevideo.flowai.website/logo-mark-dark.png',alt:''}),h('b',null,'Lingvo')));
  top.append(h('div',{class:'proj-name',title:p?p.name:''},p?p.name:t('Chưa có dự án','No project loaded')));
  if(!m) top.append(h('div',{class:'grow'}));
  if(!m && p){ const pb=(key,icon,label,title,max)=>{ const on=S.side&&S.sideKey===key; const b=btn({v:on?'secondary':'ghost',icon,label,title,onClick:()=>toggleSide(key)}); if(max&&!isMax()) b.append(h('span',{class:'max-tag'},'MAX')); return b; };
    top.append(pb('style','captions',t('Kiểu phụ đề','Subtitle style'),t('Kiểu phụ đề','Subtitle style')), pb('transcript','audio',t('Phụ đề gốc','Transcript'),t('Phân tích lại phụ đề','Re-run transcript')), pb('speakers','user',t('Người nói','Speakers'),t('Phân tích giọng nói','Voice analysis'),true), pb('visual','eye',t('Bối cảnh','Visual'),t('Bối cảnh hình ảnh','Visual context'),true), pb('settings','settings',t('Cài đặt','Settings'),t('Cài đặt','Settings')), h('div',{class:'vsep'})); }
  if(S.connBarClosed){ const dotState={offline:'off',checking:'checking',connected:'on',error:'off',demo:'demo'}[S.conn]||'off'; top.append(h('button',{type:'button',class:'conn-dot-btn',title:t('Xem trạng thái kết nối backend','View backend connection status'),onClick:()=>{S.connBarClosed=false;renderConnBar();renderTop();}},h('span',{class:'conn-dot','data-s':dotState}))); }
  top.append(btn({icon:'help',title:t('Xem lại hướng dẫn','Replay tutorial'),onClick:()=>{ if(p) startTour(); else toast(t('Kết nối backend hoặc xem dữ liệu minh hoạ trước khi xem hướng dẫn.','Connect a backend or preview sample data before viewing the tutorial.'),'info'); }}));
  top.append(btn({icon:'globe',label:lang.toUpperCase(),onClick:()=>{lang=lang==='vi'?'en':'vi';store.set('atv_lang',lang);renderAll();}}));
  top.append(btn({icon:document.documentElement.classList.contains('dark')?'sun':'moon',onClick:()=>{const d=document.documentElement.classList.toggle('dark');store.set('atv_dark',String(d));renderTop();drawTimeline();}}));
  top.append(btn({v:'primary',icon:'film',label:m?null:t('Kết xuất','Render'),title:t('Kết xuất video','Render video'),disabled:!p||!S.segs.length||busy(),busy:busy()&&S.busyJob==='render',onClick:openRenderDialog}));
}
function toggleSide(key){ if(S.side&&S.sideKey===key) S.side=false; else { S.side=true; S.sideKey=key; } renderTop(); renderSide(); }
function openSide(key){ S.side=true; S.sideKey=key; if(isMobile()) S.mtab=key; renderTop(); renderSide(); applyMobile(); }

/* =========================================================
   6) PANEL PHÂN ĐOẠN
   ========================================================= */
function renderSegs(){ const root=$('#segs'); root.innerHTML='';
  if(!S.p){ root.append(emptyState('captions',t('Chưa có phân đoạn','No segments yet'),t('Phân đoạn sẽ xuất hiện ở đây sau khi kết nối backend và dịch video.','Segments will appear here once a backend is connected and the video is translated.'),S.conn==='offline')); return; }
  root.append(h('div',{class:'segs-head',id:'segsHead','data-tour':'segment-panel-header'}), h('div',{id:'segsExtra'}), h('div',{class:'seg-list',id:'segList'})); renderSegHead(); renderSegList(); }
function renderSegHead(){ const head=$('#segsHead'); if(!head) return; head.innerHTML=''; const p=S.p; if(!p) return;
  head.append(h('span',{class:'ttl'},t('Phân đoạn','Segments'),' ',h('span',null,`(${S.segs.length})`)));
  head.append(h('button',{type:'button',class:'lang-pill','data-tour':'segment-lang-toggle','data-on':S.showLang||S.query,title:t('Tìm kiếm & ngôn ngữ','Search & language'),onClick:()=>{S.showLang=!S.showLang;renderSegs();}},ic('globe',12),`${p.src.toUpperCase()} → ${p.tgt.toUpperCase()}`));
  const ocrMode=p.subtitleSource==='ocr';
  head.append(ocrMode?h('span',{class:'ocr-lock-badge'},ic('lock',11),t('OCR · TIMELINE KHÓA','OCR · TIMELINE LOCKED')):null);
  head.append(btn({v:'outline',icon:'plus',label:t('Thêm','Add'),title:ocrMode?t('OCR 1:1: không thể thêm phân đoạn thủ công','OCR 1:1: manual segments are disabled'):t('Thêm phân đoạn vào đầu video','Add a segment at the start'),disabled:ocrMode,attrs:{'data-tour':'segment-add-btn'},onClick:()=>{if(!ocrMode)addSeg(null);}}));
  head.append(btn({icon:'more',title:t('Thao tác khác','More actions'),attrs:{'data-tour':'segment-more-actions'},onClick:e=>openMoreMenu(e.currentTarget)}));
  const missing=Array.isArray(p.translationMissingSegments)?p.translationMissingSegments:[];
  if(missing.length){
    const m=missing[0];
    const jump=()=>{
      const target=S.segs.find(s=>String(s.id)===String(m.index)) || S.segs[m.index];
      if(target){ selectSeg(target.id,{seek:true,scroll:true}); return; }
      const source=String(m.source_text||'').trim();
      if(source){ S.query=source.slice(0,60).toLowerCase(); renderSegList(); }
    };
    head.append(h('button',{type:'button',class:'btn btn-sm btn-destructive',title:t(`Chưa dịch ${missing.length} đoạn — nhấn để tới segment #${m.segment_number}`,`${missing.length} segments missing translation — click to jump to #${m.segment_number}`),onClick:jump},ic('alert',13),t(`Thiếu ${missing.length} · #${m.segment_number}`,`Missing ${missing.length} · #${m.segment_number}`)));
  }
  const extra=$('#segsExtra'); extra.innerHTML='';
  if(S.showLang){ const opts=Object.keys(LANGS).map(c=>[c,`${L(c)[2]} ${L(c)[lang==='vi'?0:1]}`]); const arrow=ic('arrowRight',14); extra.append(h('div',{class:'lang-row','data-tour':'segment-lang-row'},sel(opts,p.src,v=>{p.src=v;renderSegHead();saveSettings({source_lang:v});}),arrow,sel(opts.filter(o=>o[0]!=='auto'),p.tgt,v=>{p.tgt=v;renderSegHead();renderSide();saveSettings({target_lang:v});})));
    extra.append(h('div',{class:'search-row'},h('div',{class:'input-wrap'},ic('search',14),h('input',{class:'input',placeholder:t('Tìm kiếm…','Search…'),value:S.query,onInput:e=>{S.query=e.target.value;renderSegList();}})))); }
}
let moreMenuKeepOpen=false;
function openMoreMenu(anchor){ closeMenus(); const p=S.p; const allTx=S.segs.length&&S.segs.every(s=>s.txStatus==='done'); const pendTx=S.segs.filter(s=>s.txStatus!=='done').length; const pendDub=S.segs.filter(s=>s.txStatus==='done'&&s.dubStatus!=='done').length; const running=busy()&&(S.busyJob==='translate'||S.busyJob==='dub');
  const item=(icon,label,on,fn,opts={})=>h('div',{class:'menu-item','data-off':!on,'data-tour':opts.tour,style:opts.color?{color:opts.color}:null,onClick:on?()=>{closeMenus();fn();}:null},ic(icon,15),h('span',{class:'grow'},label),opts.right||null);
  const menu=h('div',{class:'menu',style:{position:'fixed',zIndex:90,minWidth:'260px'}},
    running ? item(S.busyJob==='dub'?'volume':'languages',(S.busyJob==='dub'?t('Đang lồng tiếng','Dubbing'):t('Đang dịch','Translating'))+` ${p.progress}% · `+t('nhấn để hủy','tap to cancel'),true,cancelJob,{color:'var(--destructive)'})
      : [ item('languages',(allTx?t('Dịch lại tất cả','Re-translate all'):t('Dịch tất cả','Translate all'))+(pendTx?` (${pendTx})`:''),S.segs.length>0&&!busy(),()=>runJob('translate',{},t('Đang dịch','Translating')),{tour:'menu-translate-all'}), item('volume',t('Lồng tiếng tất cả','Dub all')+(pendDub?` (${pendDub})`:''),pendDub>0&&!busy(),()=>runJob('dub',{},t('Đang lồng tiếng','Dubbing')),{tour:'menu-dub-all'}) ],
    item('sparkles',t('Soát & sửa bản dịch','Review & repair translations'),S.segs.length>0&&!busy(),async()=>{ try{ const r=await api.reviewTranslations(S.p.id,false); toast(t(`Đang soát ${r.total||0} đoạn nghi ngờ…`,`Reviewing ${r.total||0} suspicious segments…`),'info'); setTimeout(()=>loadProjectData(),800); }catch(e){ toast(e.message||t('Không thể soát bản dịch','Could not review translations'),'error'); } }),
    h('div',{class:'menu-sep'}),
    item('clock',t('Khớp lồng tiếng theo thời lượng','Fit dubbing to duration'),true,()=>{S.fitAll=!S.fitAll;store.set('atv_fit_duration',S.fitAll?'1':'0');drawTimeline();},{tour:'menu-fit-dubbing',right:sw(S.fitAll,()=>{})}),
    item('scissors',t('Tách các phân đoạn dài','Split all long segments'),S.p?.subtitleSource!=='ocr'&&S.segs.some(s=>s.txt&&isLong(s)),splitLong,{tour:'menu-split-all'}),
    h('div',{class:'menu-sep'}),
    item('trash',t('Xóa toàn bộ bản dịch','Clear all translations'),S.segs.some(s=>s.txStatus==='done'),clearTx,{color:'var(--destructive)',tour:'menu-clear-tx'}),
    item('trash',t('Xóa toàn bộ lồng tiếng','Clear all dubbing'),S.segs.some(s=>s.dubStatus==='done'),clearDub,{color:'var(--neon-magenta)',tour:'menu-clear-dub'}),
    item('refresh',t('Khôi phục transcript gốc','Reset to original transcript'),S.segs.length>0,resetAll,{color:'var(--destructive)',tour:'menu-reset-all'}));
  const r=anchor.getBoundingClientRect(); menu.style.top=(r.bottom+6)+'px'; menu.style.right=Math.max(8,window.innerWidth-r.right)+'px'; $('#layers').append(menu); S.ctxMenu=menu; setTimeout(()=>document.addEventListener('mousedown',outsideMenu),0); }
function outsideMenu(e){ if(moreMenuKeepOpen) return; if(S.ctxMenu&&!S.ctxMenu.contains(e.target)) closeMenus(); }
function closeMenus(){ if(moreMenuKeepOpen) return; if(S.ctxMenu){ S.ctxMenu.remove(); S.ctxMenu=null; } document.removeEventListener('mousedown',outsideMenu); }
const isLong=s=>(s.txt||'').length>Math.round(S.p.style.boxWidth*0.9);
async function clearTx(){ const n=S.segs.filter(s=>s.txStatus==='done').length; if(!await confirmDlg({title:t('Xóa toàn bộ bản dịch','Clear all translations'),desc:t(`Bản dịch và lồng tiếng của ${n} phân đoạn sẽ bị xóa vĩnh viễn.`,`Translations and dubbing for ${n} segments will be permanently deleted.`),confirmLabel:t('Xóa tất cả','Delete all')})) return; try{ await api.clearTranslations(S.p.id); S.segs.forEach(s=>{s.txt='';s.txStatus='pending';s.dubStatus='none';}); renderSegs(); drawTimeline(); updateSub(); }catch(e){ toast(e.message||t('Xóa bản dịch thất bại','Failed to clear translations'),'error'); } }
async function clearDub(){ const n=S.segs.filter(s=>s.dubStatus==='done').length; if(!await confirmDlg({title:t('Xóa toàn bộ lồng tiếng','Clear all dubbing'),desc:t(`Audio lồng tiếng của ${n} phân đoạn sẽ bị xóa vĩnh viễn.`,`Dubbing audio for ${n} segments will be permanently deleted.`),confirmLabel:t('Xóa tất cả','Delete all'),variant:'magenta'})) return; try{ await api.clearDubbings(S.p.id); S.segs.forEach(s=>{s.dubStatus='none';}); renderSegs(); drawTimeline(); }catch(e){ toast(e.message||t('Xóa lồng tiếng thất bại','Failed to clear dubbing'),'error'); } }
async function resetAll(){ if(!await confirmDlg({title:t('Khôi phục transcript gốc','Reset to original transcript'),desc:t('Mọi phân đoạn sẽ quay về đúng kết quả nhận dạng ban đầu; bản dịch, lồng tiếng và chỉnh sửa hiện tại sẽ mất.','All segments return to the original recognition result; current translations, dubbing and edits will be lost.'),confirmLabel:t('Khôi phục','Reset')})) return; try{ S.segs=await api.resetSegments(S.p.id); S.sel=null; renderSegs(); drawTimeline(); updateSub(); }catch(e){ toast(t('Không thể khôi phục transcript gốc.','Failed to reset the transcript.'),'error'); } }
async function splitLong(){ if(S.p.subtitleSource==='ocr') return; const targets=S.segs.filter(s=>s.txt&&isLong(s)); if(!targets.length){ toast(t('Không có phân đoạn nào dài quá 1 dòng.','No segment wraps past one line.'),'info'); return; } if(!await confirmDlg({title:t('Tách các phân đoạn dài','Split all long segments'),desc:t(`${targets.length} phân đoạn nhiều dòng sẽ được tách thành các phân đoạn 1 dòng; lồng tiếng của chúng cần tạo lại.`,`${targets.length} multi-line segments will be split into one-line segments; their dubbing must be regenerated.`),confirmLabel:t('Tách tất cả','Split all'),variant:'magenta'})) return; for(const s of targets) await splitSeg(s.id,false); toast(t(`Đã tách ${targets.length} phân đoạn.`,`Split ${targets.length} segments.`),'success'); }
async function splitSeg(id,notify=true){ const s=segById(id); if(!s) return; const mid=(s.start+s.end)/2; const half=txt=>{ const w=txt.split(' '); const n=Math.ceil(w.length/2); return [w.slice(0,n).join(' '),w.slice(n).join(' ')]; }; const [sa,sb]=half(s.src),[ta,tb]=half(s.txt); const parent=s.parentId||id; const second=await api.addSegment(S.p.id,{start_sec:+mid.toFixed(2),end_sec:s.end,source_text:sb,translated_text:tb,parent_index:+parent}).catch(()=>null); Object.assign(s,{end:+mid.toFixed(2),src:sa,txt:ta,dubStatus:'none',parentId:parent}); api.updateSegment(S.p.id,id,{end_sec:s.end,translated_text:ta,source_text:sa}).catch(()=>{}); if(second){ Object.assign(second,{txt:tb,txStatus:tb?'done':'pending',src:sb,parentId:parent}); S.segs.push(second); S.segs.sort((a,b)=>a.start-b.start); } renderSegs(); drawTimeline(); if(notify) toast(t('Đã tách thành 2 phân đoạn','Split into 2 segments'),'success'); }
function renderSegList(){ const list=$('#segList'); if(!list) return; const top=list.scrollTop; list.innerHTML=''; const q=S.query.trim().toLowerCase(); const segs=q?S.segs.filter(s=>s.src.toLowerCase().includes(q)||s.txt.toLowerCase().includes(q)):S.segs;
  if(!segs.length){ list.append(h('div',{style:{padding:'24px',textAlign:'center',color:'var(--muted-foreground)',fontSize:'13px'}},S.segs.length?t('Không có kết quả.','No results.'):t('Chưa có phân đoạn nào.','No segments yet.'))); return; }
  const groups=[]; segs.forEach(s=>{ const g=groups[groups.length-1]; if(g&&g.parentId!==null&&g.parentId===s.parentId) g.segs.push(s); else groups.push({parentId:s.parentId,segs:[s]}); });
  groups.forEach(g=>{ if(g.parentId===null){ g.segs.forEach(s=>list.append(segCard(s))); return; } const from=Math.min(...g.segs.map(s=>s.start)), to=Math.max(...g.segs.map(s=>s.end)); list.append(h('div',{style:{borderBottom:'1px solid var(--border)'}},h('div',{class:'grp-head'},h('span',{style:{display:'flex',alignItems:'center',gap:'6px'}},ic('captions',12),t('Phân đoạn cha','Parent segment'),' ',h('span',{class:'mono',style:{fontWeight:400}},`${fmt(from)} – ${fmt(to)}`)),h('button',{type:'button',class:'xbtn',title:t('Xóa phân đoạn cha','Delete parent segment'),onClick:async()=>{ if(!await confirmDlg({title:t('Xóa phân đoạn cha','Delete parent segment'),desc:t(`Cả nhóm ${g.segs.length} phân đoạn con (kèm bản dịch, lồng tiếng) sẽ bị xóa.`,`The whole group of ${g.segs.length} child segments (with translations and dubbing) will be deleted.`),confirmLabel:t('Xóa nhóm','Delete group')})) return; const ids=g.segs.map(s=>s.id); S.segs=S.segs.filter(s=>!ids.includes(s.id)); renderSegs(); drawTimeline(); ids.forEach(i=>api.deleteSegment(S.p.id,i).catch(()=>{})); }},ic('trash',13))),h('div',{style:{borderLeft:'3px solid color-mix(in oklch, var(--primary) 45%, transparent)'}},g.segs.map(segCard)))); });
  list.scrollTop=top; }
function segCard(s){ const tx=s.txStatus==='done', dub=s.dubStatus==='done', fail=s.dubStatus==='failed'; const card=h('div',{class:'seg-card','data-id':s.id,'data-tour':'segment-card','data-sel':S.sel===s.id,onClick:()=>selectSeg(s.id)});
  const left=h('div',{style:{display:'flex',alignItems:'center',gap:'6px',minWidth:0}},h('button',{type:'button',class:'seg-time-btn',title:S.p?.subtitleSource==='ocr'?t('Timeline OCR khóa theo frame — nhấn để xem đoạn','OCR timeline is frame-locked — click to seek'):t('Sửa thời gian bắt đầu / kết thúc','Edit start / end time'),onClick:e=>{e.stopPropagation();selectSeg(s.id,{seek:true});if(S.p?.subtitleSource!=='ocr')editTiming(s,'sub');}},`${fmt(subtitleSpan(s)[0])} – ${fmt(subtitleSpan(s)[1])}`)); if(s.speaker) left.append(h('span',{class:'spk',title:t('Người nói (từ phân tích giọng nói)','Speaker (from voice analysis)')},s.speaker));
  const col=(i,c)=>{ i.style.color=c; return i; };
  const flags=h('div',{class:'seg-flags'},h('span',{class:'dot '+(tx?'on-tx':s.txStatus==='running'?'run':''),title:t('Dịch thuật','Translation')}),h('span',{class:'dot '+(dub?'on-dub':fail?'err':s.dubStatus==='running'?'run':''),title:t('Lồng tiếng','Dubbing')}),col(ic('captions',13),tx?'var(--neon-cyan)':'var(--border)'),col(ic('volume',13),dub?'var(--neon-magenta)':fail?'var(--destructive)':'var(--border)'));
  if(fail){ const a=col(ic('alert',13),'var(--destructive)'); a.setAttribute('title',s.dubError||t('Lồng tiếng thất bại','Dubbing failed')); flags.append(a); }
  if(dub&&s.speed>1.9){ const a=col(ic('alert',13),'#f59e0b'); a.setAttribute('title',t('Bản dịch quá dài — audio phải tua nhanh hết mức. Hãy rút ngắn câu.','Translation too long — audio is sped up to the limit. Try shortening the text.')); flags.append(a); }
  if(S.p?.subtitleSource!=='ocr') flags.append(h('button',{type:'button',class:'xbtn','data-tour':'segment-delete-btn',title:t('Xóa phân đoạn','Delete segment'),onClick:e=>{e.stopPropagation();e.preventDefault();deleteSeg(s.id);}},ic('trash',13)));
  card.append(h('div',{class:'seg-row1'},left,flags), h('div',{class:'seg-src'},s.src||t('(Không có văn bản gốc)','(No source text)')));
  if(S.editing===s.id){ const ta=h('textarea',{class:'seg-edit',rows:2,onClick:e=>e.stopPropagation(),onKeydown:e=>{ if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();e.target.blur();} if(e.key==='Escape'){ta.value=s.txt;e.target.blur();} }}); ta.value=s.txt; ta.addEventListener('blur',()=>{ S.editing=null; saveText(s.id,ta.value.trim()); }); card.append(ta); setTimeout(()=>{ta.focus();ta.setSelectionRange(ta.value.length,ta.value.length);},0); }
  else card.append(h('div',{class:'seg-txt'+(tx?'':' empty'),onClick:e=>{ if(!tx) return; e.stopPropagation(); S.sel=s.id; S.editing=s.id; renderSegList(); }},s.txt||t('(Chưa dịch. Nhấn Dịch để bắt đầu)','(Not translated. Click Translate to start)')));
  const acts=h('div',{class:'seg-acts'},
    btn({v:tx?'outline':'secondary',icon:tx?'refresh':'languages',busy:s.txStatus==='running',label:tx?t('Dịch lại','Re-translate'):t('Dịch','Translate'),disabled:s.txStatus==='running',attrs:{'data-tour':'segment-translate-btn'},onClick:e=>{e.stopPropagation();translateSeg(s.id);}}),tx?btn({v:'ghost',icon:'trash',title:t('Xóa bản dịch','Delete translation'),onClick:async e=>{e.stopPropagation();try{await api.deleteTranslation(S.p.id,Number(s.id));s.txt='';s.txStatus='pending';s.dubStatus='none';renderSegList();drawTimeline();updateSub();}catch(err){toast(err.message,'error');}}}):null,
    btn({v:dub?'outline':'ghost',icon:dub||fail?'refresh':'volume',busy:s.dubStatus==='running',label:dub?t('Lồng lại','Re-dub'):fail?t('Thử lại','Retry'):t('Lồng tiếng','Dub'),disabled:!tx||s.dubStatus==='running',attrs:{'data-tour':'segment-dub-btn'},onClick:e=>{e.stopPropagation();dubSeg(s.id);}}),dub?btn({v:'ghost',icon:'trash',title:t('Xóa lồng tiếng','Delete dubbing'),onClick:async e=>{e.stopPropagation();try{const rr=await fetch(CFG.apiBase+'/api/projects/'+S.p.id+'/tts/'+Number(s.id),{method:'DELETE'});if(!rr.ok)throw new Error('Không xóa được audio lồng tiếng');s.dubStatus='none';renderSegList();drawTimeline();}catch(err){toast(err.message,'error');}}}):null);
  if(dub) acts.append(btn({v:S.audioPlaying===s.id?'secondary':'ghost',icon:S.audioPlaying===s.id?'pause':'play',title:t('Nghe audio dubbing','Play dubbing audio'),onClick:e=>{e.stopPropagation();playDub(s);}}));
  card.append(acts); return card; }
let dubAudio=null;
function stopDubAudio(){ if(dubAudio){ dubAudio.pause(); dubAudio=null; } if('speechSynthesis' in window) speechSynthesis.cancel(); S.audioPlaying=null; }
function playDub(s){ if(S.audioPlaying===s.id){ stopDubAudio(); renderSegList(); return; } stopDubAudio(); const url=api.dubUrl(S.p.id,s.id); const done=()=>{S.audioPlaying=null;renderSegList();}; if(url){ dubAudio=new Audio(url); dubAudio.volume=S.vol.dub/100; dubAudio.onended=dubAudio.onerror=done; dubAudio.play().catch(done); } else if('speechSynthesis' in window){ const u=new SpeechSynthesisUtterance(s.txt||s.src); u.lang=L(S.p.tgt)[3]; u.rate=s.speed||1; u.volume=S.vol.dub/100; u.onend=u.onerror=done; speechSynthesis.speak(u); } else { toast(t('Trình duyệt không hỗ trợ nghe thử.','Preview not supported in this browser.'),'warning'); return; } S.audioPlaying=s.id; renderSegList(); }

/* =========================================================
   7) VIDEO, PHỤ ĐỀ XEM TRƯỚC, KHUNG KÉO THẢ
   ========================================================= */
let video=null, stage=null, subBox=null, dragBox=null, blurLayer=null, blurDrag=null, ocrEditorBox=null, playLayer=null, infoBar=null;
function renderCenter(){ const c=$('#center'); c.innerHTML=''; const p=S.p;
  if(!p){ video=null; stage=null; subBox=null; dragBox=null; blurLayer=null; blurDrag=null; ocrEditorBox=null; playLayer=null; infoBar=null;
    c.append(h('div',{class:'stage-wrap'},h('div',{class:'stage placeholder'},emptyState('film',t('Chưa có video','No video yet'),t('Video xem trước sẽ hiển thị ở đây sau khi kết nối backend và tải dự án.','The preview video will appear here once a backend is connected and a project is loaded.'),S.conn==='offline')))); return; }
  stage=h('div',{class:'stage'});
  video=h('video',{preload:'metadata',playsinline:true,crossorigin:'anonymous'}); if(p) video.src=api.videoUrl(CFG.projectId||p.id);
  video.addEventListener('loadedmetadata',()=>{ S.dur=video.duration||0; if(video.videoWidth){S.natW=video.videoWidth;S.natH=video.videoHeight;} video.volume=S.vol.orig/100; fitStageToContainer(); renderTlHead(); drawTimeline(); layoutOverlays(); });
function fitStageToContainer(){
  if(!stage||!S.natW||!S.natH) return;
  const ratio=S.natW/S.natH;
  stage.style.setProperty('--stage-ratio',String(ratio));
  if(isMobile()){stage.style.width='100%';stage.style.height='auto';stage.style.maxHeight='none';return;}
  const center=document.querySelector('.ed-center'); const r=center&&center.getBoundingClientRect();
  if(!r)return;
  const aw=Math.max(160,r.width-48), ah=Math.max(120,r.height-48);
  let w=aw,h=w/ratio; if(h>ah){h=ah;w=h*ratio;}
  stage.style.width=Math.floor(w)+'px'; stage.style.height=Math.floor(h)+'px';
}

  video.addEventListener('play',()=>{S.playing=true;renderPlayLayer();renderTlHead();loop();}); video.addEventListener('pause',()=>{S.playing=false;stopSchedDub();renderPlayLayer();renderTlHead();updateSub();}); video.addEventListener('ended',()=>{S.playing=false;stopSchedDub();renderPlayLayer();renderTlHead();});
  video.addEventListener('timeupdate',()=>{ if(!S.playing){ S.time=video.currentTime; onTime(); } });
  blurLayer=h('div',{class:'blur-layer',hidden:true}); subBox=h('div',{class:'sub-box',hidden:true});
  playLayer=h('div',{class:'play-layer',onClick:()=>togglePlay()});
  dragBox=h('div',{class:'drag-box','data-tour':'style-box',hidden:true,onPointerdown:e=>startSubDrag(e,'move')}); ['tl','tr','bl','br','l','r','t','b'].forEach(k=>dragBox.append(h('span',{class:'hdl','data-h':k,style:handleStyle(k),onPointerdown:e=>startSubDrag(e,k)})));
  blurDrag=h('div',{class:'drag-box blur',hidden:true,onPointerdown:e=>startBlurDrag(e,'move')}); ['tl','tr','bl','br'].forEach(k=>blurDrag.append(h('span',{class:'hdl','data-h':k,style:handleStyle(k),onPointerdown:e=>startBlurDrag(e,k)})));
  ocrEditorBox=h('div',{class:'ocr-box','data-ocr-editor':'1',hidden:true},h('b',{class:'ocr-box-label'},'OCR'));
  [['n','top'],['s','bottom'],['l','left'],['r','right'],['nw','nw'],['ne','ne'],['sw','sw'],['se','se']].forEach(([mode,side])=>ocrEditorBox.append(h('i',{ 'data-side':side, onPointerdown:e=>startOcrStageDrag(e,mode)})));
  ocrEditorBox.addEventListener('pointerdown',e=>{ if(e.target===ocrEditorBox) startOcrStageDrag(e,'move'); });
  infoBar=h('div',{class:'stage-info'});
  stage.append(video,blurLayer,playLayer,blurDrag,dragBox,subBox,ocrEditorBox,infoBar); c.append(h('div',{class:'stage-wrap'},stage)); renderPlayLayer(); renderStageInfo(); new ResizeObserver(()=>layoutOverlays()).observe(stage); }
function handleStyle(k){ const s={}; if(k.includes('t')&&k!=='tl'&&k!=='tr'||k==='t') {} const pos={tl:{top:-7,left:-7,cursor:'nwse-resize'},tr:{top:-7,right:-7,cursor:'nesw-resize'},bl:{bottom:-7,left:-7,cursor:'nesw-resize'},br:{bottom:-7,right:-7,cursor:'nwse-resize'},l:{left:-7,top:'50%',transform:'translateY(-50%)',cursor:'ew-resize'},r:{right:-7,top:'50%',transform:'translateY(-50%)',cursor:'ew-resize'},t:{top:-7,left:'50%',transform:'translateX(-50%)',cursor:'ns-resize'},b:{bottom:-7,left:'50%',transform:'translateX(-50%)',cursor:'ns-resize'}}[k]; Object.entries(pos).forEach(([a,b])=>{ s[a]=typeof b==='number'?b+'px':b; }); return s; }
function renderPlayLayer(){ if(!playLayer) return; playLayer.innerHTML=''; if(!S.playing) playLayer.append(h('div',{class:'play-btn'},(()=>{const i=ic('play',26);i.style.marginLeft='3px';return i;})())); }
function renderStageInfo(){ if(!infoBar) return; infoBar.innerHTML=''; const p=S.p; if(p&&busy()) infoBar.append(h('span',{class:'badge badge-cyan'},ic('loader',11,'spin'),S.jobLabel||t('Đang xử lý','Processing'),` ${p.progress}%`)); }
function togglePlay(){ if(!video) return; if(video.paused) video.play().catch(()=>{}); else video.pause(); }
function seekTo(tm){ S.time=clamp(tm,0,S.dur||tm); if(video) video.currentTime=S.time; onTime(); }
function contentBox(){ const w=S.stageW,hh=S.stageH; if(!w||!hh) return null; const sc=Math.min(w/S.natW,hh/S.natH); const cw=S.natW*sc,ch=S.natH*sc; return {left:(w-cw)/2,top:(hh-ch)/2,width:cw,height:ch,z:cw/S.natW}; }
function layoutOverlays(){ if(!stage) return; const r=stage.getBoundingClientRect(); S.stageW=r.width; S.stageH=r.height; updateOcrEditorBox(); updateSub(); updateBlur(); refreshDragBoxes(); }
/* Phụ đề: kích thước quy đổi theo chiều rộng gốc (size ứng với khung 640px) */
function subMetrics(b){ const st=S.p.style; const scale=b.width/640; return { font:Math.max(9,st.size*scale), padY:Math.max(1,st.paddingY*scale), padX:Math.max(2,2*st.paddingY*scale), maxW:Math.max(20,st.boxWidth/100*b.width), radius:st.radius*scale, outline:Math.max(.5,st.outlineWidth*scale), shadow:st.shadowStrength/5, scale }; }
function wordTimes(seg){ if(seg.words&&seg.words.length) { const sp=seg.speed||1; return seg.words.map(w=>({text:w.text,start:seg.start+w.start/sp,end:seg.start+w.end/sp})); } const ws=(seg.txt||seg.src).split(/\s+/).filter(Boolean); const total=ws.reduce((a,w)=>a+Math.max(1,w.length),0); let cur=seg.start; return ws.map(w=>{ const d=(seg.end-seg.start)*Math.max(1,w.length)/Math.max(1,total); const o={text:w,start:cur,end:cur+d}; cur+=d; return o; }); }
function normalizedOcrRegion(r){ r=r||{}; const x=clamp(Number(r.x??0)||0,0,100); let y=clamp(Number(r.y??65)||65,0,100); const w=clamp(Number(r.w??r.width??100)||100,1,100-x); let h=clamp(Number(r.h??r.height??35)||35,1,100-y); y=clamp(y,0,100-h); return {x,y,w,h}; }
function updateOcrEditorBox(){
  if(!ocrEditorBox||!S.p) return;
  const show=S.p.subtitleSource==='ocr' && !!contentBox();
  ocrEditorBox.hidden=!show;
  if(!show) return;
  const b=contentBox(); const r=normalizedOcrRegion(S.p.ocrRegion); S.p.ocrRegion=r;
  Object.assign(ocrEditorBox.style,{left:(b.left+r.x/100*b.width)+'px',top:(b.top+r.y/100*b.height)+'px',width:(r.w/100*b.width)+'px',height:(r.h/100*b.height)+'px'});
}
function startOcrStageDrag(e,mode){
  e.preventDefault(); e.stopPropagation(); mode=mode==='l'?'w':mode==='r'?'e':mode; if(!S.p||S.p.subtitleSource!=='ocr') return;
  const b=contentBox(); if(!b) return;
  const x0=e.clientX,y0=e.clientY,init=normalizedOcrRegion(S.p.ocrRegion); let moved=false;
  const mv=ev=>{ moved=true; const dx=(ev.clientX-x0)/b.width*100, dy=(ev.clientY-y0)/b.height*100; let {x,y,w,h}=init;
    if(mode==='move'){x=clamp(x+dx,0,100-w);y=clamp(y+dy,0,100-h);}
    else {
      if(mode.includes('e')) w=clamp(w+dx,1,100-x);
      if(mode.includes('w')){const nx=clamp(x+dx,0,x+w-1);w+=x-nx;x=nx;}
      if(mode.includes('s')) h=clamp(h+dy,1,100-y);
      if(mode.includes('n')){const ny=clamp(y+dy,0,y+h-1);h+=y-ny;y=ny;}
    }
    S.p.ocrRegion={x,y,w,h}; updateOcrEditorBox();
  };
  const up=()=>{window.removeEventListener('pointermove',mv);window.removeEventListener('pointerup',up);if(moved) saveSettings({ocr_region:normalizedOcrRegion(S.p.ocrRegion)});};
  window.addEventListener('pointermove',mv); window.addEventListener('pointerup',up);
}
function updateSub(){ if(!subBox||!S.p) return; const b=contentBox(); const seg=segAt(S.time)||(!S.playing?segById(S.sel):null); const st=S.p.style; if(!b||!seg||!(seg.txt||seg.src)){ subBox.hidden=true; if(dragBox) dragBox.hidden=true; return; } subBox.hidden=false; const m=subMetrics(b); const box=st.background==='box'; const up=s=>st.uppercase?s.toUpperCase():s; const text=seg.txt||seg.src;
  const shadows=[]; if(st.outline){ const o=m.outline; [[-o,-o],[o,-o],[-o,o],[o,o],[0,-o],[0,o]].forEach(([x,y])=>shadows.push(`${x}px ${y}px 0 rgba(0,0,0,.95)`)); } if(st.shadow){ const g=m.shadow; shadows.push(`${2*m.scale*g}px ${2*m.scale*g}px ${Math.max(1,6*m.scale*g)}px rgba(0,0,0,1)`,`0 0 ${Math.max(2,10*m.scale*g)}px rgba(0,0,0,.9)`); }
  let opacity=1, lift=0; if(st.animation==='bounce'&&S.playing){ const e=clamp((S.time-seg.start)/.25,0,1); lift=(1-e)*40*m.scale; opacity=Math.min(clamp((S.time-seg.start)/.2,0,1),clamp((seg.end-S.time)/.2,0,1)); }
  Object.assign(subBox.style,{left:(b.left+st.posX/100*b.width)+'px',top:(b.top+st.posY/100*b.height)+'px',transform:`translate(-50%, calc(-100% + ${(box?m.padY:0)+lift}px))`,opacity,maxWidth:m.maxW+'px',width:'max-content',padding:box?`${m.padY}px ${m.padX}px`:'0',fontSize:m.font+'px',fontWeight:st.bold?700:400,fontStyle:st.italic?'italic':'normal',color:st.color,fontFamily:`"${st.font}", sans-serif`,background:box?`rgba(10,10,20,${st.bgOpacity/100})`:'transparent',borderRadius:box?m.radius+'px':'0',textShadow:shadows.join(', ')||'none',opacity:String(opacity*(seg.txt?1:.7))});
  subBox.innerHTML='';
  if((st.animation==='karaoke'||st.animation==='pop')&&S.playing){ const words=wordTimes(seg); if(st.animation==='karaoke'){ words.forEach((w,i)=>{ const pct=100*clamp((S.time-w.start)/Math.max(.001,w.end-w.start),0,1); const sp=h('span',{class:'kw',style:{backgroundImage:`linear-gradient(90deg, ${st.color} ${pct}%, #808080 ${pct}%)`}},up(w.text)); subBox.append(sp); if(i<words.length-1) subBox.append(' '); }); } else { let cur=0; words.forEach((w,i)=>{ if(w.start<=S.time) cur=i; }); words.forEach((w,i)=>{ subBox.append(h('span',{style:{display:'inline-block',transform:i===cur?'scale(1.12)':'scale(1)',fontWeight:i===cur||st.bold?700:400,color:i===cur?st.popHighlightColor:'',transformOrigin:'center bottom',transition:'transform 90ms ease-out, color 60ms ease-out'}},up(w.text))); if(i<words.length-1) subBox.append(' '); }); } }
  else subBox.textContent=up(text);
  refreshDragBoxes(); }
function updateBlur(){ if(!blurLayer||!S.p) return; const bb=S.p.blur; const b=contentBox(); blurLayer.hidden=!bb.enabled||!b; if(blurLayer.hidden) return; Object.assign(blurLayer.style,{left:(b.left+bb.x/100*b.width)+'px',top:(b.top+bb.y/100*b.height)+'px',width:(bb.width/100*b.width)+'px',height:(bb.height/100*b.height)+'px'}); blurLayer.style.setProperty('--bs',Math.max(2,bb.strength*(b.width/640))+'px'); }
function refreshDragBoxes(){ if(!dragBox) return; const showSub=!subBox.hidden; dragBox.hidden=!showSub; if(showSub){ const r=subBox.getBoundingClientRect(), sr=stage.getBoundingClientRect(); Object.assign(dragBox.style,{left:(r.left-sr.left-4)+'px',top:(r.top-sr.top-4)+'px',width:(r.width+8)+'px',height:(r.height+8)+'px'}); } const showBlur=!!(S.p&&S.p.blur.enabled); blurDrag.hidden=!showBlur; if(showBlur){ Object.assign(blurDrag.style,{left:blurLayer.style.left,top:blurLayer.style.top,width:blurLayer.style.width,height:blurLayer.style.height}); } }
function startSubDrag(e,mode){ e.preventDefault(); e.stopPropagation(); const b=contentBox(); if(!b) return; const st=S.p.style; const x0=e.clientX,y0=e.clientY,init=Object.assign({},st); let moved=false;
  const mv=ev=>{ moved=true; const dx=ev.clientX-x0, dy=ev.clientY-y0; if(mode==='move'){ st.posX=clamp(init.posX+dx/b.width*100,0,100); st.posY=clamp(init.posY+dy/b.height*100,0,100); } else if(mode==='l'||mode==='r'){ const d=(mode==='r'?dx:-dx)*2/b.width*100; st.boxWidth=clamp(Math.round(init.boxWidth+d),5,100); } else if(mode==='t'||mode==='b'){ const d=(mode==='b'?dy:-dy); st.size=clamp(Math.round(init.size+d/6),6,120); } else { const sign=(mode==='br'||mode==='tr')?1:-1; st.size=clamp(Math.round(init.size+sign*dx/6),6,120); } updateSub(); refreshDragBoxes(); };
  const up=()=>{ window.removeEventListener('pointermove',mv); window.removeEventListener('pointerup',up); if(moved){ saveStyle(); if(S.side&&S.sideKey==='style') renderSide(); } }; window.addEventListener('pointermove',mv); window.addEventListener('pointerup',up); }
function startBlurDrag(e,mode){ e.preventDefault(); e.stopPropagation(); const b=contentBox(); if(!b) return; const bb=S.p.blur; const x0=e.clientX,y0=e.clientY,init=Object.assign({},bb);
  const mv=ev=>{ const dx=(ev.clientX-x0)/b.width*100, dy=(ev.clientY-y0)/b.height*100; if(mode==='move'){ bb.x=clamp(init.x+dx,0,100-bb.width); bb.y=clamp(init.y+dy,0,100-bb.height); } else { let x=init.x,y=init.y,w=init.width,hh=init.height; if(mode.includes('r')) w=clamp(init.width+dx,5,100-init.x); if(mode.includes('l')){ const nx=clamp(init.x+dx,0,init.x+init.width-5); w=init.width+(init.x-nx); x=nx; } if(mode.includes('b')) hh=clamp(init.height+dy,5,100-init.y); if(mode.includes('t')){ const ny=clamp(init.y+dy,0,init.y+init.height-5); hh=init.height+(init.y-ny); y=ny; } Object.assign(bb,{x,y,width:w,height:hh}); } updateBlur(); refreshDragBoxes(); };
  const up=()=>{ window.removeEventListener('pointermove',mv); window.removeEventListener('pointerup',up); saveStyle(); }; window.addEventListener('pointermove',mv); window.addEventListener('pointerup',up); }
let rafId=0, lastAuto=null, schedId=null;
function loop(){ cancelAnimationFrame(rafId); const step=()=>{ if(!S.playing) return; S.time=video.currentTime; onTime(); rafId=requestAnimationFrame(step); }; step(); }
function onTime(){ updateSub(); const tl=$('#tlTimeNow'); if(tl) tl.textContent=fmt(S.time); drawTimeline();
  // TTS playback uses the generated dubbing span, not the immutable OCR/source slot.
  if(dubAudio && schedId){ const ss=S.segs.find(x=>x.id===schedId); if(ss){ const [,slotEnd]=dubSpan(ss); if(S.time >= slotEnd-0.02){ dubAudio.pause(); dubAudio=null; schedId=null; } } }
  const cur=segAt(S.time); const dubCur=S.segs.find(s=>s.dubStatus==='done'&&(()=>{const [a,b]=dubSpan(s); return S.time>=a&&S.time<b;})()); if(S.playing&&cur&&cur.id!==lastAuto){ lastAuto=cur.id; selectSeg(cur.id,{seek:false,scroll:true}); } if(S.playing){ if(dubCur&&dubCur.id!==schedId) schedDub(dubCur); else if(!dubCur&&dubAudio&&!S.audioPlaying) stopSchedDub(); const sc=$('#tlScroll'); const x=S.time*S.pps; if(x<sc.scrollLeft||x>sc.scrollLeft+sc.clientWidth-40) sc.scrollLeft=Math.max(0,x-60); } }
function schedDub(seg){ if(seg.dubStatus!=='done') return; const [start,end]=dubSpan(seg); if(!(S.time>=start-0.03&&S.time<end)) return; if(schedId===seg.id&&dubAudio&&!dubAudio.ended) return; const url=api.dubUrl(S.p.id,seg.id); if(!url) return; stopDubAudio(); schedId=seg.id; dubAudio=new Audio(url); dubAudio.volume=S.vol.dub/100; dubAudio.playbackRate=1; const seekAfterLoad=()=>{ const delta=Math.max(0,S.time-start); try{ if(Number.isFinite(dubAudio.duration)&&dubAudio.duration>0) dubAudio.currentTime=Math.min(delta,Math.max(0,dubAudio.duration-0.02)); }catch(e){}; dubAudio.play().catch(()=>{}); }; if(dubAudio.readyState>=1) seekAfterLoad(); else dubAudio.addEventListener('loadedmetadata',seekAfterLoad,{once:true}); dubAudio.addEventListener('ended',()=>{ if(schedId===seg.id){ schedId=null; dubAudio=null; } },{once:true}); }
function stopSchedDub(){ schedId=null; if(dubAudio&&!S.audioPlaying){ dubAudio.pause(); dubAudio=null; } }
document.addEventListener('keydown',e=>{ const tg=e.target; const typing=tg&&['INPUT','TEXTAREA','SELECT'].includes(tg.tagName); if(e.code==='Space'&&!typing&&tg.tagName!=='BUTTON'){ e.preventDefault(); togglePlay(); } });

/* =========================================================
   8) PANEL PHẢI
   ========================================================= */
function renderSide(){ const side=$('#side'); const key=isMobile()?(['style','transcript','speakers','visual','settings'].includes(S.mtab)?S.mtab:null):(S.side?S.sideKey:null); side.hidden=!key; const sc=$('#sideScroll'); sc.scrollTop; sc.innerHTML=''; if(!key||!S.p) return; const p=S.p;
  if(key==='style') sc.append(stylePanel(p)); if(key==='transcript') sc.append(transcriptPanel(p)); if(key==='speakers') sc.append(speakersPanel(p)); if(key==='visual') sc.append(visualPanel(p)); if(key==='settings') sc.append(settingsPanel(p)); }
const secHead=(icon,label,cls='')=>h('div',{class:'sec-title '+cls},ic(icon,11),label);
function slider(label,val,min,max,onInput,onChange,step=1){ const v=h('span',{class:'mono'},String(val)); return h('div',null,h('div',{class:'mini-lbl',style:{display:'flex',justifyContent:'space-between'}},h('span',null,label),v),h('input',{type:'range',class:'rng',min,max,step,value:val,onInput:e=>{const n=Number(e.target.value);v.textContent=String(n);onInput(n);},onChange:onChange})); }
function swatches(value,presets,onChange){ const row=h('div',{class:'swatches'}); presets.forEach(c=>row.append(h('button',{type:'button',class:'sw','data-on':value.toLowerCase()===c.toLowerCase(),style:{background:c},onClick:()=>onChange(c)}))); const custom=h('label',{class:'sw custom','data-on':!presets.some(c=>c.toLowerCase()===value.toLowerCase()),title:t('Màu tùy chọn','Custom color')},h('input',{type:'color',value,onInput:e=>onChange(e.target.value,true)})); row.append(custom,h('span',{class:'mono muted',style:{fontSize:'11px'}},value)); return row; }
function tile(on,preview,label,onClick,extra){ const b=h('button',{type:'button',class:'tile','data-on':on,onClick},h('div',{class:'pv'},preview),h('span',{class:'cap'},on&&extra?ic('check',9):null,label)); return b; }
/* ---- Kiểu phụ đề ---- */
function stylePanel(p){ const st=p.style, bb=p.blur; const box=st.background==='box'; const rer=()=>{ updateSub(); refreshDragBoxes(); saveStyle(); renderSide(); }; const live=()=>{ updateSub(); refreshDragBoxes(); };
  const panel=h('div',{class:'panel tight'}); panel.append(h('div',{class:'panel-title'},t('Kiểu phụ đề','Subtitle style')));
  const section=(key,label,content)=>{ const closed=!!S.collapsed[key]; const wrap=h('div',{class:'sec-col','data-closed':closed}); wrap.append(h('button',{type:'button',class:'hd',onClick:()=>{S.collapsed[key]=!closed;renderSide();}},h('span',null,label),ic(closed?'chevDown':'chevUp',12))); if(!closed) wrap.append(content); return wrap; };
  const samp=(extra,txt='Aa')=>h('span',{style:Object.assign({fontSize:'14px',fontWeight:700,color:st.color,fontFamily:`"${st.font}"`},extra||{})},txt);
  panel.append(section('bg',t('Nền khung','Background'),h('div',{style:{display:'flex',gap:'6px'}},tile(box,samp({background:`rgba(10,10,20,${st.bgOpacity/100})`,borderRadius:Math.min(st.radius,8)+'px',padding:'2px 7px'}),t('Nền','Box'),()=>{st.background='box';rer();}),tile(!box,samp(),t('Trong suốt','None'),()=>{st.background='none';rer();}))));
  const fx=[['shadow',t('Bóng','Shadow'),{textShadow:'1.5px 1.5px 3px rgba(0,0,0,1), 0 0 5px rgba(0,0,0,.9)'},'Aa'],['outline',t('Viền','Outline'),{textShadow:'-1.2px -1.2px 0 rgba(0,0,0,.9), 1.2px -1.2px 0 rgba(0,0,0,.9), -1.2px 1.2px 0 rgba(0,0,0,.9), 1.2px 1.2px 0 rgba(0,0,0,.9)'},'Aa'],['bold',t('Đậm','Bold'),{fontWeight:900},'Aa'],['italic',t('Nghiêng','Italic'),{fontStyle:'italic'},'Ai'],['uppercase',t('In hoa','Uppercase'),{},'ABC']];
  const fxWrap=h('div',{class:'stack',style:{gap:'8px'}},h('div',{style:{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:'6px'}},fx.map(([k,l,sty,txt])=>tile(!!st[k],samp(Object.assign({fontSize:'13px'},sty),txt),l,()=>{st[k]=!st[k];rer();},true))));
  if(st.shadow) fxWrap.append(slider(t('Độ đậm bóng','Shadow strength'),st.shadowStrength,0,15,n=>{st.shadowStrength=n;live();},saveStyle));
  if(st.outline) fxWrap.append(slider(t('Độ dày viền','Outline width'),st.outlineWidth,1,8,n=>{st.outlineWidth=n;live();},saveStyle));
  panel.append(section('fx',t('Hiệu ứng chữ','Text effects'),fxWrap));
  const anims=[['none',t('Không','None')],['karaoke','Karaoke'],['pop','Pop'],['bounce',t('Nảy','Bounce')]];
  const anWrap=h('div',{class:'stack',style:{gap:'8px'}},h('div',{style:{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'6px'}},anims.map(([k,l])=>tile(st.animation===k,h('span',{class:k==='none'?'':'pv-'+k,style:{fontSize:'14px',fontWeight:700,color:st.color,fontFamily:`"${st.font}"`,'--sub-color':st.color}},'Abc'),l,()=>{st.animation=k;rer();}))));
  if(st.animation!=='none') anWrap.append(h('div',{class:'mini-hint'},t('Bấm phát để xem hiệu ứng. Có lồng tiếng thì nhịp từng từ sẽ chính xác hơn.','Press play to preview. Word timing is exact once dubbing exists.')));
  if(st.animation==='pop') anWrap.append(h('div',null,h('div',{class:'mini-lbl'},t('Màu từ nổi bật','Highlight color')),swatches(st.popHighlightColor,['#FFD700','#ffffff','#FF6B00','#00FF7F','#00FFFF'],(c,liveOnly)=>{st.popHighlightColor=c;if(liveOnly)live();else rer();})));
  panel.append(section('anim',t('Chuyển động','Animation'),anWrap));
  panel.append(section('font',t('Phông chữ','Font'),h('div',{style:{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'6px'}},FONTS.map(f=>h('button',{type:'button',class:'tile font','data-on':st.font===f,onClick:()=>{st.font=f;rer();}},h('span',{class:'aa',style:{fontFamily:`"${f}"`}},'Aa'),h('span',{class:'nm',style:{fontFamily:`"${f}"`}},f))))));
  panel.append(section('color',t('Màu chữ','Text color'),swatches(st.color,['#ffffff','#ffff00','#00ffff','#ff69b4','#ff4444'],(c,liveOnly)=>{st.color=c;if(liveOnly)live();else rer();})));
  const sz=h('div',{class:'stack',style:{gap:'10px'}},slider(t('Cỡ chữ','Font size'),st.size,6,120,n=>{st.size=n;live();},saveStyle),h('div',{class:'mini-hint'},t('Kéo khung phụ đề trên video để dời vị trí; kéo góc để phóng to/thu nhỏ; kéo cạnh trái/phải để đổi độ rộng.','Drag the subtitle box on the video to move it; drag a corner to resize; drag the left/right edges to change the width.')));
  if(box){ sz.append(slider(t('Độ mờ nền (%)','Background opacity (%)'),st.bgOpacity,0,100,n=>{st.bgOpacity=n;live();},saveStyle),slider(t('Bo góc khung','Corner radius'),st.radius,0,40,n=>{st.radius=n;live();},saveStyle),slider(t('Khoảng đệm','Padding'),st.paddingY,0,40,n=>{st.paddingY=n;live();},saveStyle)); }
  panel.append(section('size',t('Kích thước & vị trí','Size & position'),sz));
  const bl=h('div',{class:'stack',style:{gap:'10px'}},h('button',{type:'button',class:'toggle-card','data-on':bb.enabled,onClick:()=>{bb.enabled=!bb.enabled;updateBlur();refreshDragBoxes();saveStyle();renderSide();}},h('span',null,t('Bật vùng làm mờ','Enable blur box')),bb.enabled?ic('check',13):null));
  if(bb.enabled) bl.append(h('div',{class:'mini-hint'},t('Khung mờ hoạt động độc lập với phụ đề và áp dụng cho toàn bộ video. Chạm vào khung trên video để dời hoặc đổi kích thước.','The blur box is independent from the subtitle and applies to the whole video. Tap it on the video to move or resize it.')),slider(t('Độ mờ','Blur strength'),bb.strength,1,40,n=>{bb.strength=n;updateBlur();},saveStyle));
  panel.append(section('blur',t('Vùng làm mờ','Blur box'),bl));
  return panel; }
/* ---- Phụ đề gốc ---- */
function transcriptPanel(p){ const panel=h('div',{class:'panel','data-tour':'transcript-panel'}); panel.append(secHead('captions',t('Phân tích lại phụ đề','Re-run transcript')));
  panel.append(h('div',{class:'config-note',style:{marginBottom:'10px'}},t('STT và OCR chạy độc lập, lưu kết quả riêng. Hợp nhất timeline chỉ chạy khi bạn bấm nút riêng.','STT and OCR run independently and keep separate results. Timeline fusion runs only when you press its own button.')));
  panel.append(h('div',{style:{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'8px'}},
    btn({v:'outline',icon:'mic',label:t('Chạy STT riêng','Run STT only'),disabled:busy(),onClick:async()=>{
      if(!await confirmDlg({title:t('Chạy STT riêng?','Run STT only?'),desc:t('Chỉ nhận dạng giọng nói. Kết quả OCR đã lưu sẽ được giữ nguyên.','Only transcribe speech. Saved OCR results will be preserved.'),confirmLabel:t('Chạy STT','Run STT')})) return;
      p.subtitleSource='stt'; saveSettings({subtitle_source:'stt'});
      runJob('transcribe',{subtitle_source:'stt',filter_transcript_noise:p.filterNoise},t('Đang chạy STT','Running STT'));
    }}),
    btn({v:'outline',icon:'captions',label:t('Chạy OCR riêng','Run OCR only'),disabled:busy(),onClick:async()=>{
      if(!await confirmDlg({title:t('Chạy OCR riêng?','Run OCR only?'),desc:t('Dùng model OCR local hiện tại để đọc chữ và khớp thời gian xuất hiện trên frame; không chạy STT và không tự dịch.','Use the existing local OCR model to read text and align when it appears in frames; no STT or automatic translation.'),confirmLabel:t('Chạy OCR','Run OCR')})) return;
      p.subtitleSource='ocr'; saveSettings({subtitle_source:'ocr',ocr_region:normalizedOcrRegion(p.ocrRegion)});
      runJob('transcribe',{subtitle_source:'ocr',ocr_region:normalizedOcrRegion(p.ocrRegion)},t('Đang chạy OCR','Running OCR'));
    }})
  ));
  panel.append(h('div',{style:{marginTop:'8px'}},
    btn({v:'primary',icon:'git-merge',label:t('Hợp nhất timeline STT + OCR','Merge STT + OCR timeline'),cls:'btn-block',disabled:busy(),onClick:async()=>{
      if(!await confirmDlg({title:t('Hợp nhất timeline?','Merge timelines?'),desc:t('Lấy nội dung từ STT và đối chiếu thời điểm OCR đã lưu. Hai kết quả gốc vẫn được giữ riêng.','Use STT text and align against saved OCR timings. The two original results remain separate.'),confirmLabel:t('Hợp nhất','Merge')})) return;
      runJob('transcribe',{action:'merge'},t('Đang hợp nhất timeline','Merging timeline'));
    }})
  ));
  if(p.subtitleSource!=='ocr') panel.append(h('label',{style:{display:'flex',alignItems:'flex-start',gap:'8px',cursor:'pointer'}},cb(p.filterNoise,v=>{p.filterNoise=v;renderSide();}),h('div',null,h('div',{style:{fontSize:'12px',fontWeight:600}},t('Lọc đoạn transcript nhiễu','Filter noisy transcript segments')),h('div',{class:'hint',style:{marginTop:'2px'}},t('Thêm một bước AI để loại các câu rời rạc, thiếu mạch lạc — xử lý lâu và tốn hơn một chút.','Adds an AI pass that drops fragmented, incoherent lines — slightly slower and costlier.')))));
  { const mini=h('div',{class:'ocr-mini'}); const v=h('video',{muted:true,preload:'metadata',playsinline:true,src:api.videoUrl(p.videoId)}); v.addEventListener('loadedmetadata',()=>{ v.currentTime=S.time||1; }); const box=h('div',{class:'ocr-box'},h('i',{style:{top:'-6px'},onPointerdown:e=>ocrDrag(e,'n',box)}),h('i',{style:{bottom:'-6px'},onPointerdown:e=>ocrDrag(e,'s',box)}),h('i',{style:{left:'-6px',top:'50%',transform:'translateY(-50%)',cursor:'ew-resize'},onPointerdown:e=>ocrDrag(e,'w',box)}),h('i',{style:{right:'-6px',left:'auto',top:'50%',transform:'translateY(-50%)',cursor:'ew-resize'},onPointerdown:e=>ocrDrag(e,'e',box)})); box.addEventListener('pointerdown',e=>{ if(e.target===box) ocrDrag(e,'move',box); });
    const place=()=>{ const r=normalizedOcrRegion(p.ocrRegion); p.ocrRegion=r; Object.assign(box.style,{left:r.x+'%',top:r.y+'%',width:r.w+'%',height:r.h+'%'}); };
    place(); mini.append(v,box); panel.append(mini, h('div',{style:{display:'flex',justifyContent:'space-between',alignItems:'center'}},h('span',{class:'hint'},t('Kéo khung để chọn vùng phụ đề','Drag the box to select the subtitle region')),btn({v:'outline',label:t('Đặt lại','Reset'),onClick:()=>{p.ocrRegion={x:0,y:65,w:100,h:35};place();updateOcrEditorBox();saveSettings({ocr_region:p.ocrRegion});}})));
    function ocrDrag(e,mode){ e.preventDefault(); e.stopPropagation(); const rr=mini.getBoundingClientRect(); const x0=e.clientX,y0=e.clientY,init=normalizedOcrRegion(p.ocrRegion); let moved=false; const mv=ev=>{ moved=true; const dx=(ev.clientX-x0)/Math.max(1,rr.width)*100, dy=(ev.clientY-y0)/Math.max(1,rr.height)*100; let {x,y,w,h}=init; if(mode==='move'){x=clamp(x+dx,0,100-w);y=clamp(y+dy,0,100-h);} else { if(mode==='e') w=clamp(w+dx,1,100-x); if(mode==='w'){const nx=clamp(x+dx,0,x+w-1);w+=x-nx;x=nx;} if(mode==='s') h=clamp(h+dy,1,100-y); if(mode==='n'){const ny=clamp(y+dy,0,y+h-1);h+=y-ny;y=ny;} } p.ocrRegion={x,y,w,h}; place(); updateOcrEditorBox(); }; const up=()=>{window.removeEventListener('pointermove',mv);window.removeEventListener('pointerup',up);if(moved)saveSettings({ocr_region:normalizedOcrRegion(p.ocrRegion)});}; window.addEventListener('pointermove',mv); window.addEventListener('pointerup',up); } }
  if(busy()) panel.append(h('span',{class:'hint'},t('Dự án đang xử lý — vui lòng đợi hoàn tất.','The project is processing — please wait.')));
  return panel; }
/* ---- Người nói ---- */
function lockedPanel(icon,title,desc){ return h('div',{class:'panel'},secHead(icon,title),h('div',{class:'locked'},h('div',{class:'lk'},ic('lock',20)),desc,h('div',{style:{marginTop:'12px'}},btn({v:'primary',sm:false,icon:'sparkles',label:t('Nâng cấp lên Max','Upgrade to Max'),onClick:()=>toast(t('Mở trang Gói & Thanh toán để nâng cấp.','Open Plans & Billing to upgrade.'),'info')})))); }
let analysisTimer=null;
function watchAnalysis(kind){ if(analysisTimer) clearInterval(analysisTimer); analysisTimer=setInterval(async()=>{ try{ const a=await api.getAnalysis(S.p.id,kind); const was=S[kind].status; S[kind]=Object.assign({},S[kind],a); if(a.status!==was) { if(kind==='voice'&&a.status==='DONE'){ S.segs=await api.getSegments(S.p.id); renderSegList(); } renderSide(); } if(a.status==='DONE'||a.status==='FAILED'){ clearInterval(analysisTimer); analysisTimer=null; } }catch(e){} },1500); }
function speakersPanel(p){ if(!isMax()) return lockedPanel('user',t('Phân tích giọng nói','Voice analysis'),t('Nhận diện từng người nói, gán vào đúng phân đoạn và dùng giới tính/ngữ cảnh để dịch cách xưng hô chính xác hơn. Tính năng dành cho gói Max.','Detects each speaker, maps them to segments and uses gender/context to translate forms of address more accurately. Available on the Max plan.'));
  const a=S.voice; const panel=h('div',{class:'panel','data-tour':'speakers-panel'}); panel.append(secHead('user',t('Phân tích giọng nói','Voice analysis')));
  const start=async(force)=>{ try{ await api.startAnalysis(p.id,'voice',force); S.voice.status='QUEUED'; renderSide(); watchAnalysis('voice'); }catch(e){ toast(e.message||t('Không thể bắt đầu phân tích','Failed to start analysis'),'error'); } };
  if(a.status==='NONE'||a.status==='FAILED'){ panel.append(h('p',{class:'hint',style:{margin:0,fontSize:'12px'}},t('Tách từng người nói trong video, ghép với phân đoạn tương ứng và cung cấp giới tính, vai trò cho AI để dịch đại từ và cách xưng hô nhất quán — đặc biệt hữu ích với tiếng Trung, Nhật, Hàn.','Separates each speaker in the video, matches them to segments and gives the AI gender/role cues so pronouns and forms of address stay consistent — especially useful for Chinese, Japanese and Korean.'))); if(a.status==='FAILED'&&a.error) panel.append(h('div',{style:{fontSize:'12px',color:'var(--destructive)'}},a.error)); panel.append(btn({v:'primary',icon:'sparkles',label:a.status==='FAILED'?t('Thử lại','Retry'):t('Phân tích giọng nói','Analyze voices'),cls:'btn-block',onClick:()=>start(a.status==='FAILED')})); }
  if(a.status==='QUEUED'||a.status==='RUNNING') panel.append(h('div',{style:{display:'flex',alignItems:'center',gap:'8px',fontSize:'12px',color:'var(--muted-foreground)'}},ic('loader',14,'spin'),a.status==='QUEUED'?t('Đang chờ trong hàng đợi…','Waiting in queue…'):t('Đang phân tích…','Analyzing…')));
  if(a.status==='DONE'){ panel.append(btn({v:'outline',icon:'refresh',label:t('Phân tích lại','Re-analyze'),onClick:()=>start(true)})); if(!a.speakers.length) panel.append(h('div',{class:'hint',style:{fontSize:'12px'}},t('Không phát hiện người nói nào.','No speakers detected.'))); else { const voices=voicesFor(p.tgt); panel.append(h('div',{class:'stack',style:{gap:'10px'}},a.speakers.map(sp=>h('div',{class:'spk-card'},h('div',{class:'nm'},h('span',{class:'spk-av','data-g':sp.gender},sp.label.replace(/\D/g,'')||'?'),h('span',{class:'grow'},sp.label),h('span',{class:'badge badge-neutral'},sp.gender==='female'?t('Nữ','Female'):t('Nam','Male')),h('span',{class:'muted',style:{fontSize:'11px'}},`${sp.segments} ${t('đoạn','segs')}`)),h('div',{class:'field'},h('div',{class:'lbl mu'},h('span',null,t('Giọng lồng tiếng','Dubbing voice'))),sel([['',t('(Theo giọng mặc định của dự án)','(Use project default voice)')],...voices.map(([id,n,g])=>[id,`${n} · ${g==='F'?t('Nữ','Female'):t('Nam','Male')}`])],sp.voice||'',v=>{sp.voice=v;api.saveSpeaker(p.id,sp.id,{voice:v}).then(()=>toast(t('Đã lưu giọng cho '+sp.label,'Voice saved for '+sp.label),'success')).catch(()=>toast(t('Lưu thất bại','Save failed'),'error'));},{style:'height:30px;font-size:12px'})))))); panel.append(h('div',{class:'hr'}),h('div',{class:'field'},h('div',{class:'lbl mu'},h('span',null,t('Giọng mặc định của dự án','Project default voice'))),sel(voices.map(([id,n,g])=>[id,`${n} · ${g==='F'?t('Nữ','Female'):t('Nam','Male')}`]),providers().edgeVoice||voices[0][0],v=>{providers().edgeVoice=v;api.saveProviders({edge_voice:v});}))); } }
  return panel; }
/* ---- Bối cảnh ---- */
function visualPanel(p){ if(!isMax()) return lockedPanel('eye',t('Bối cảnh hình ảnh','Visual context'),t('AI xem qua hình ảnh của video để nắm bối cảnh, nhân vật và không khí, giúp bản dịch tự nhiên và đúng ngữ cảnh hơn. Tính năng dành cho gói Max.','The AI looks at the video\'s visuals to capture setting, characters and mood, making translations more natural and context-aware. Available on the Max plan.'));
  const a=S.visual; const panel=h('div',{class:'panel','data-tour':'visual-context-panel'}); panel.append(secHead('eye',t('Bối cảnh hình ảnh','Visual context')));
  const start=async(force)=>{ try{ await api.startAnalysis(p.id,'visual',force); S.visual.status='QUEUED'; renderSide(); watchAnalysis('visual'); }catch(e){ toast(e.message||t('Không thể bắt đầu phân tích','Failed to start analysis'),'error'); } };
  if(a.status==='NONE'||a.status==='FAILED'){ panel.append(h('p',{class:'hint',style:{margin:0,fontSize:'12px'}},t('Trích một số khung hình theo thời gian, mô tả bối cảnh và nhân vật rồi đưa cho AI dịch tham khảo — hữu ích khi lời thoại ngắn hoặc mơ hồ.','Samples frames over time, describes the setting and characters and passes that to the translation AI — useful when dialogue is short or ambiguous.'))); if(a.status==='FAILED'&&a.error) panel.append(h('div',{style:{fontSize:'12px',color:'var(--destructive)'}},a.error)); panel.append(btn({v:'primary',icon:'sparkles',label:a.status==='FAILED'?t('Thử lại','Retry'):t('Phân tích bối cảnh','Analyze visuals'),cls:'btn-block',onClick:()=>start(a.status==='FAILED')})); }
  if(a.status==='QUEUED'||a.status==='RUNNING') panel.append(h('div',{style:{display:'flex',alignItems:'center',gap:'8px',fontSize:'12px',color:'var(--muted-foreground)'}},ic('loader',14,'spin'),a.status==='QUEUED'?t('Đang chờ trong hàng đợi…','Waiting in queue…'):t('Đang phân tích…','Analyzing…')));
  if(a.status==='DONE'){ panel.append(btn({v:'outline',icon:'refresh',label:t('Phân tích lại','Re-analyze'),onClick:()=>start(true)})); if(a.summary) panel.append(h('div',null,h('div',{class:'mini-lbl'},t('Tóm tắt','Summary')),h('div',{style:{fontSize:'12.5px',lineHeight:1.55}},a.summary))); if(a.scenes&&a.scenes.length) panel.append(h('div',null,h('div',{class:'mini-lbl'},t('Các cảnh','Scenes')),a.scenes.map(sc=>h('div',{class:'scene'},h('button',{type:'button',class:'tm',onClick:()=>seekTo(sc.start)},fmt(sc.start,0)+'–'+fmt(sc.end,0)),h('span',null,sc.text))))); }
  return panel; }
/* ---- Cài đặt ---- */
function provCard(pr,cur,onSel,keys){ const needsKey=!pr.tags.includes('free'); const saved=pr.key?!!keys[pr.key]:false; const enabled=!needsKey||saved; const tags=[]; if(pr.tags.includes('free')) tags.push(h('span',{class:'tag tag-free'},t('Miễn phí','Free'))); if(pr.tags.includes('trial')) tags.push(h('span',{class:'tag tag-trial'},'Trial')); if(pr.key) tags.push(h('span',{class:'tag '+(saved?'tag-ok':'tag-key')},saved?t('Có key','Key saved'):'API key')); return h('button',{type:'button',class:'prov','data-on':cur===pr.id,disabled:!enabled,title:enabled?'':t('Thêm API key trong Cài đặt → API Keys để dùng nhà cung cấp này','Add an API key under Settings → API Keys to use this provider'),onClick:()=>onSel(pr.id)},h('span',{class:'rd'}),h('span',{class:'grow'},h('b',null,pr.name,...tags),h('small',null,lang==='vi'?pr.vi:pr.en))); }
function settingsPanel(p){ const panel=h('div',{class:'panel','data-tour':'settings-panel',style:{gap:'22px'}}); if(!S.settings){ panel.append(h('div',{class:'hint'},t('Đang tải cài đặt…','Loading settings…'))); return panel; } const pv=S.settings.providers, keys=S.settings.keys; const setP=(k,v,payload)=>{ pv[k]=v; renderSide(); api.saveProviders(payload).catch(()=>toast(t('Lưu cài đặt thất bại','Failed to save settings'),'error')); if(k==='refine'&&S.p){S.p.translateRefine=!!v;api.updateSettings(S.p.id,{translate_refine:!!v}).catch(()=>{});} };
  panel.append(h('div',{class:'card',style:{padding:'12px'}},h('div',{class:'table-wrap'},h('table',{class:'table'},h('thead',null,h('tr',null,h('th',null,t('Nhóm','Group')),h('th',null,t('Nhà cung cấp','Provider')),h('th',null,t('Trạng thái','Status')),h('th',null,t('Chọn','Select')))),h('tbody',null,...STT_PROVIDERS.concat(TX_PROVIDERS).concat(TTS_PROVIDERS).map(pr=>{ const group=STT_PROVIDERS.includes(pr)?t('STT','STT'):TX_PROVIDERS.includes(pr)?t('Dịch','Translation'):t('TTS','TTS'); const cur=group===t('STT','STT')?pv.stt:group===t('Dịch','Translation')?pv.translate:pv.tts; const selected=cur===pr.id; return h('tr',null,h('td',null,group),h('td',null,h('b',null,pr.name)),h('td',null,h('span',{class:'badge badge-'+(selected?'success':'neutral')},selected?t('Đang dùng','Active'):t('Sẵn sàng','Available'))),h('td',null,btn({v:selected?'primary':'outline',label:selected?t('Đã chọn','Selected'):t('Chọn','Select'),onClick:()=>{ if(STT_PROVIDERS.includes(pr)) setP('stt',pr.id,{stt_provider:pr.id}); else if(TX_PROVIDERS.includes(pr)) setP('translate',pr.id,{translate_provider:pr.id}); else setP('tts',pr.id,{tts_provider:pr.id}); }}))); }))))));
  panel.append(h('div',{class:'hr'}));
  const tx=h('div',{class:'stack'});
  if(pv.translate!=='google_translate'){ tx.append(h('button',{type:'button',class:'prov',style:{background:'var(--muted)',alignItems:'center'},onClick:()=>setP('refine',!pv.refine,{translate_refine:!pv.refine})},h('span',{class:'grow'},h('b',null,t('Soát lại bản dịch','Refine translations')),h('small',null,t('AI đọc lại toàn bộ bản dịch lần hai để mượt và đồng nhất hơn — thời gian dịch tăng khoảng gấp đôi.','A second AI pass re-reads the whole translation for smoother, more consistent wording — roughly doubles translation time.'))),sw(pv.refine,()=>{})));
    if(DEFAULT_MODELS[pv.translate]){ const pr=TX_PROVIDERS.find(x=>x.id===pv.translate); const canPick=isPaid()||(pr.key&&keys[pr.key]); const models=S.models[pv.translate]||[]; const card=h('div',{class:'subcard'}); const head=h('div',{class:'hd'},h('span',null,'Model')); if(canPick&&!models.length) head.append(h('button',{type:'button',class:'link-btn',onClick:async e=>{ e.currentTarget.replaceWith(ic('loader',11,'spin')); try{ S.models[pv.translate]=await api.getModels(pv.translate); }catch(err){ toast(t('Không tải được danh sách model','Could not load models'),'error'); } renderSide(); }},t('Tải danh sách','Load models'))); card.append(head,sel([['',t(`(Mặc định — ${DEFAULT_MODELS[pv.translate]})`,`(Default — ${DEFAULT_MODELS[pv.translate]})`)],...models.map(m=>[m,m])],models.includes(pv.model)?pv.model:'',v=>{pv.model=v;api.saveProviders({provider_config:{[pv.translate]:{model:v}}});},{disabled:!canPick||!models.length,style:canPick?'':'opacity:.6'})); if(!canPick) card.append(h('span',{class:'hint'},t('Nâng cấp lên Pro/Max hoặc dùng API key riêng để chọn model.','Upgrade to Pro/Max or use your own API key to pick a model.'))); tx.append(card); } }
  const reduceOriginalRow=h('div',{class:'subcard',style:{marginTop:'10px'}},
    h('div',{class:'hd'},h('span',null,t('Âm thanh gốc','Original audio'))),
    h('div',{style:{display:'flex',alignItems:'center',justifyContent:'space-between',gap:'10px'}},
      h('div',null,
        h('b',{style:{fontSize:'12px'}},t('Giảm giọng người nói gốc','Reduce original speech')),
        h('div',{class:'hint'},t('Giảm âm lượng audio gốc khi render; vẫn giữ phần âm thanh nền còn lại.','Lower the original track during render; the mixed background remains.'))
      ),
      sw(!!p.render.reduceOriginalVoice,v=>{
        p.render.reduceOriginalVoice=!!v;
        p.render.originalVoiceReduction=v?0.65:0;
        api.updateSettings(p.id,{render:{reduce_original_voice:!!v,original_voice_reduction:v?0.65:0}});
        renderSide();
      })
    )
  );
  panel.append(reduceOriginalRow);
  panel.append(h('div',null,secHead('languages',t('Dịch thuật','Translation')),tx,h('div',{class:'hr',style:{margin:'14px 0'}}),promptGlossary(p)));
  panel.append(h('div',{class:'hr'}));
  const tts=h('div',{class:'stack'});
  {
    const card=h('div',{class:'subcard'});
    const currentProvider=pv.tts||'xkira_tts';
    const currentVoice=currentProvider==='xkira_tts'?(pv.xkiraVoice||''):(pv.edgeVoice||'');
    const opts=[];
    XKIRA_VOICES.slice(0,4).forEach(v=>opts.push([`xkira_tts::${v.id}`,`xKiro · ${v.name}${v.gender?` · ${v.gender==='female'?t('Nữ','Female'):t('Nam','Male')}`:''}`]));
    voicesFor(p.tgt).slice(0,2).forEach(([id,name,g])=>opts.push([`edge_tts::${id}`,`Microsoft Edge · ${name} · ${g==='F'?t('Nữ','Female'):t('Nam','Male')}`]));
    const selected=opts.some(x=>x[0]===currentProvider+'::'+currentVoice)?currentProvider+'::'+currentVoice:(opts[0]?.[0]||'');
    const head=h('div',{class:'hd'},h('span',null,t('Chọn giọng đọc','Choose voice')),h('span',{class:'badge badge-cyan'},`${opts.length} ${t('giọng','voices')}`));
    const voiceSelect=sel(opts,selected,v=>{
      const parts=String(v).split('::'); const provider=parts.shift(); const voice=parts.join('::');
      pv.tts=provider; pv.voice=voice; if(provider==='xkira_tts') pv.xkiraVoice=voice; else pv.edgeVoice=voice;
      api.saveProviders({tts_provider:provider, ...(provider==='xkira_tts'?{xkira_voice:voice}:{edge_voice:voice})}).catch(()=>toast(t('Lưu giọng thất bại','Failed to save voice'),'error'));
    },{style:'height:36px;flex:1;min-width:0'});
    const preview=btn({v:'primary',icon:'volume',label:t('Nghe thử','Preview'),onClick:()=>{const parts=String(voiceSelect.value).split('::'); const provider=parts.shift(); const voice=parts.join('::'); if(voice) previewVoice(voice,provider);}});
    const reload=btn({v:'outline',icon:'refresh',title:t('Tải lại giọng xKiro','Reload xKiro voices'),onClick:async()=>{
      reload.disabled=true; try{ const live=await api.getXkiraVoices(true); XKIRA_VOICES=Array.isArray(live)?live.filter(v=>String(v.name||'').toLowerCase().includes('vietnamese')).slice(0,4):[]; renderSide(); }
      catch(e){toast(e.message||t('Không tải được giọng xKiro','Could not load xKiro voices'),'error');} finally{reload.disabled=false;}
    }});
    const selectedName=(()=>{const x=opts.find(o=>o[0]===selected);return x?x[1]:t('Chưa chọn giọng','No voice selected')})();
    card.append(head,h('div',{class:'voice-selected-chip'},h('span',null,h('i'),selectedName),h('span',{class:'mono muted'},currentProvider==='xkira_tts'?'xKiro':'Edge')), h('div',{class:'hint',style:{marginBottom:'7px'}},t('Bấm ô bên dưới để chọn 1 trong 4 giọng xKiro thật hoặc 2 giọng Microsoft Edge. Nút loa dùng để nghe thử.','Select one of 4 live xKiro voices or 2 Microsoft Edge voices. Use Preview to hear the voice.')), h('div',{style:{display:'flex',gap:'7px',alignItems:'center',minWidth:0}},voiceSelect,preview,reload), !XKIRA_VOICES.length?h('div',{class:'hint',style:{color:'var(--warning)',marginTop:'6px'}},t('Chưa nhận được catalog xKiro. Hãy bấm nút ↻ để tải lại.','xKiro catalog is not loaded. Click ↻ to reload.')):null);
    pv.speed=Number(pv.speed||1.3); const rateTitle=h('div',{class:'hd',style:{marginTop:'10px',marginBottom:'2px'}},h('span',null,t('Tốc độ đọc','Speech rate')),h('span',{class:'mono'},pv.speed.toFixed(2)+'x'));
    card.append(h('div',null,rateTitle,h('input',{type:'range',class:'rng',min:.7,max:1.4,step:.05,value:pv.speed,onInput:e=>{pv.speed=Number(e.target.value); rateTitle.querySelector('.mono').textContent=pv.speed.toFixed(2)+'x';},onChange:()=>api.saveProviders({tts_speed:pv.speed})})));
    tts.append(card);
  }
  panel.append(h('div',null,secHead('mic',t('Lồng tiếng','Dubbing'),'mg'),tts));
  return panel; }
function promptGlossary(p){ const wrap=h('div'); wrap.append(secHead('captions',t('Prompt & Từ điển (dự án này)','Prompt & glossary (this project)'))); const ta=h('textarea',{class:'input',rows:3,placeholder:t('Ví dụ: dịch giọng văn trang trọng, gọi khán giả là "quý vị"…','e.g. keep a formal tone and address the audience as "you"…')}); ta.value=p.additionalPrompt||'';
  wrap.append(h('div',{class:'field',style:{marginBottom:'14px'}},h('div',{class:'lbl'},h('span',null,t('Prompt bổ sung','Additional prompt'))),ta,h('div',{class:'hint'},t('Ghi chú thêm cho AI khi dịch: văn phong, bối cảnh, đối tượng người xem.','Extra guidance for the AI when translating: tone, context, audience.'))));
  const rows=h('div',{class:'stack'}); const list=p.glossary.length?p.glossary:[{source:'',target:''}]; const draw=()=>{ rows.innerHTML=''; list.forEach((g,i)=>rows.append(h('div',{style:{display:'flex',alignItems:'center',gap:'6px'}},h('input',{class:'input',placeholder:t('Tên gốc','Original'),value:g.source,onInput:e=>{g.source=e.target.value;}}),ic('arrowRight',13),h('input',{class:'input',placeholder:t('Bản dịch','Translation'),value:g.target,onInput:e=>{g.target=e.target.value;}}),btn({icon:'trash',onClick:()=>{list.splice(i,1);if(!list.length)list.push({source:'',target:''});draw();}})))); }; draw();
  wrap.append(h('div',{class:'field'},h('div',{class:'lbl'},h('span',null,t('Từ điển tên riêng','Proper-noun glossary'))),h('div',{class:'hint'},t('Giữ tên người, địa danh và thuật ngữ được dịch thống nhất trong cả video.','Keeps names, places and terms translated consistently across the video.')),rows,btn({v:'outline',icon:'plus',label:t('Thêm cặp từ','Add term'),cls:'',onClick:()=>{list.push({source:'',target:''});draw();}})));
  const save=btn({v:'primary',label:t('Lưu','Save'),cls:'btn-block',onClick:async()=>{ save.disabled=true; try{ p.additionalPrompt=ta.value; p.glossary=list.filter(g=>g.source.trim()).map(g=>({source:g.source.trim(),target:g.target.trim()})); await api.updateSettings(p.id,{additional_prompt:p.additionalPrompt,glossary:p.glossary}); save.innerHTML=''; save.append(ic('check',14),h('span',null,t('Đã lưu','Saved'))); setTimeout(()=>{save.innerHTML='';save.append(h('span',null,t('Lưu','Save')));},2000); }catch(e){ toast(t('Lưu thất bại','Save failed'),'error'); } finally{ save.disabled=false; } }}); save.style.marginTop='14px'; wrap.append(save); return wrap; }
async function previewVoice(voice,provider){ if(!voice) return; if(S.audioPlaying==='sample'){ stopDubAudio(); renderSide(); return; } stopDubAudio(); try{ const pv=providers(); const pid=provider||pv.tts||'xkira_tts'; const url=await api.previewVoice(voice,pid,S.p?.tgt||'vi'); dubAudio=new Audio(url); const done=()=>{S.audioPlaying=null;URL.revokeObjectURL(url);renderSide();}; dubAudio.onended=dubAudio.onerror=done; dubAudio.play().catch(done); S.audioPlaying='sample'; renderSide(); }catch(e){ toast(e.message||t('Nghe thử thất bại','Preview failed'),'error'); } }

/* =========================================================
   9) TIMELINE (canvas)
   ========================================================= */
const RULER=22;
function renderTlHead(){ const head=$('#tlHead'); head.innerHTML=''; const tl=$('#tl'); tl.toggleAttribute('data-open',S.tlOpen);
  head.append(h('button',{type:'button',class:'tl-toggle',title:S.tlOpen?t('Thu nhỏ timeline','Collapse timeline'):t('Mở rộng timeline','Expand timeline'),onClick:()=>{S.tlOpen=!S.tlOpen;renderTlHead();setTimeout(drawTimeline,220);}},ic(S.tlOpen?'chevDown':'chevUp',13),'Timeline'),h('div',{class:'vsep',style:{height:'18px',margin:0}}));
  head.append(btn({icon:'skipBack',onClick:()=>{seekTo(0);video&&video.pause();}}),btn({icon:S.playing?'pause':'play',onClick:togglePlay}),h('span',{class:'tl-time',id:'tlTimeNow'},fmt(S.time)),h('div',{class:'grow'}));
  const volRow=(icon,color,key,title,setter)=>{ const lab=h('small',null,S.vol[key]+'%'); const i=ic(icon,12); i.style.color=color; return h('div',{class:'vol'},i,h('input',{type:'range',class:'rng',min:0,max:100,value:S.vol[key],title,onInput:e=>{S.vol[key]=Number(e.target.value);lab.textContent=S.vol[key]+'%';setter(S.vol[key]);},onChange:()=>saveSettings({render:key==='orig'?{orig_volume:S.vol.orig/100}:{dub_volume:S.vol.dub/100}})}),lab); };
  const vols=h('div',{'data-tour':'timeline-volume',style:{display:'flex',alignItems:'center',gap:'6px'}},volRow('volume','var(--muted-foreground)','orig',t('Âm lượng gốc','Original volume'),v=>{if(video)video.volume=v/100;}),h('div',{class:'vsep',style:{height:'14px',margin:'0 2px'}}),volRow('mic','var(--neon-magenta)','dub',t('Âm lượng lồng tiếng','Dubbing volume'),v=>{if(dubAudio)dubAudio.volume=v/100;})); head.append(vols);
  if(S.tlOpen||isMobile()) head.append(btn({icon:'zoomOut',onClick:()=>{S.pps=clamp(S.pps/1.4,8,240);drawTimeline();}}),btn({icon:'zoomIn',onClick:()=>{S.pps=clamp(S.pps*1.4,8,240);drawTimeline();}}));
  head.append(h('span',{class:'mono muted',style:{fontSize:'11px',marginLeft:'8px'}},fmt(S.dur)));
  const labels=$('#tlLabels'); labels.innerHTML=''; labels.append(h('div',{class:'sp'}),...['Video',t('Phụ đề','Subtitle'),t('Lồng tiếng','Dubbing')].map(l=>h('div',{class:'lb'},l))); }
const canvas=$('#tlCanvas'), tlScroll=$('#tlScroll'); let drag=null;
/* Free-resize left subtitle list, preview/style panel, and timeline height. */
(function installEditorSplitters(){
  const app=$('#app'), body=document.querySelector('.ed-body'), segs=$('#segs'), center=$('#center'), side=$('#side'), tl=$('#tl');
  if(!app||!body||!segs||!center||!side||!tl) return;
  const make=(axis,label)=>{const el=document.createElement('div');el.className='panel-splitter '+(axis==='x'?'vertical':'horizontal');el.setAttribute('role','separator');el.setAttribute('aria-label',label);el.tabIndex=0;return el;};
  const leftGrip=make('x','Resize subtitle list'); body.insertBefore(leftGrip,center);
  const rightGrip=make('x','Resize settings panel'); body.insertBefore(rightGrip,side);
  const tlGrip=make('y','Resize timeline'); app.insertBefore(tlGrip,tl);
  const bind=(grip,axis,read,write,min,max)=>{
    const down=e=>{if(e.button!==0||window.matchMedia('(max-width: 900px)').matches)return;e.preventDefault();grip.dataset.dragging='1';const start=axis==='x'?e.clientX:e.clientY,initial=read();
      const move=ev=>{const pos=axis==='x'?ev.clientX:ev.clientY;write(Math.max(min,Math.min(max,initial+(axis==='x'?pos-start:start-pos))));};
      const up=()=>{delete grip.dataset.dragging;window.removeEventListener('pointermove',move);window.removeEventListener('pointerup',up);window.removeEventListener('pointercancel',up);if(typeof drawTimeline==='function')drawTimeline();if(typeof fitStageToContainer==='function')fitStageToContainer();if(typeof layoutOverlays==='function')layoutOverlays();};
      window.addEventListener('pointermove',move);window.addEventListener('pointerup',up);window.addEventListener('pointercancel',up);};
    grip.addEventListener('pointerdown',down);
    grip.addEventListener('keydown',e=>{if(e.key!=='ArrowLeft'&&e.key!=='ArrowRight'&&e.key!=='ArrowUp'&&e.key!=='ArrowDown')return;e.preventDefault();const d=(e.key==='ArrowLeft'||e.key==='ArrowUp')?-12:12;write(Math.max(min,Math.min(max,read()+d)));});
  };
  const saved=(k,d)=>{try{return Number(localStorage.getItem('lingvo_editor_'+k))||d;}catch(_){return d;}};
  const persist=(k,v)=>{try{localStorage.setItem('lingvo_editor_'+k,String(Math.round(v)));}catch(_){}};
  const setWidth=(k,v)=>{app.style.setProperty(k,v+'px');persist(k==='--segs-width'?'segs_width':'side_width',v);};
  setWidth('--segs-width',Math.max(220,Math.min(520,saved('segs_width',354))));
  setWidth('--side-width',Math.max(220,Math.min(480,saved('side_width',280))));
  bind(leftGrip,'x',()=>segs.getBoundingClientRect().width,v=>setWidth('--segs-width',v),220,520);
  bind(rightGrip,'x',()=>side.getBoundingClientRect().width,v=>setWidth('--side-width',v),220,480);
  const updateRightGrip=()=>{rightGrip.hidden=side.hidden;};
  new MutationObserver(updateRightGrip).observe(side,{attributes:true,attributeFilter:['hidden']});updateRightGrip();
  const tlHeight=()=>Number(getComputedStyle(app).getPropertyValue('--timeline-height').replace('px',''))||saved('timeline_height',220);
  const setTlHeight=v=>{const n=Math.max(90,Math.min(Math.round(window.innerHeight*.65),v));app.style.setProperty('--timeline-height',n+'px');if(typeof S!=='undefined')S.tlOpen=true;tl.setAttribute('data-open','');persist('timeline_height',n);};
  const oldTl=saved('timeline_height',220);app.style.setProperty('--timeline-height',oldTl+'px');
  bind(tlGrip,'y',()=>tl.getBoundingClientRect().height,v=>{setTlHeight(v);if(typeof drawTimeline==='function')drawTimeline();},90,Math.round(window.innerHeight*.65));
})();
function tlGeom(){ const w=tlScroll.clientWidth, hh=tlScroll.clientHeight; const speechMax=S.segs.length?Math.max(...S.segs.map(s=>speechSpan(s)[1])):0; const dubMax=S.segs.length?Math.max(...S.segs.map(s=>dubSpan(s)[1])):0; return {w,h:hh,rowH:(hh-RULER)/3,total:Math.max(S.dur,speechMax,dubMax,1)}; }
function dubSpan(s){
  const st=Number(s.dubStart??s.dub_start_sec??s.speechStart??s.source_start??s.start??0);
  const storedDur=Number(s.dubDuration??s.dub_duration??0);
  const storedEnd=Number(s.dub_end_sec??0);
  if(storedDur>0.001) return [Math.max(0,st), Math.max(st+0.05,st+storedDur)];
  if(storedEnd>st+0.001) return [Math.max(0,st), storedEnd];
  const en=Math.max(st+0.05,Number(s.speechEnd??s.source_end??s.end??st+0.05));
  return [Math.max(0,st),en];
}
function subtitleSpan(s){
  const timingSource=String(s?.timingSource||s?.timing_source||'').toLowerCase();
  const locked=!!s?.ocrLocked || !!s?.timingLocked || timingSource.includes('ocr');
  const a=Number(s?.source_start), b=Number(s?.source_end);
  if(locked && Number.isFinite(a) && Number.isFinite(b) && b>a) return [Math.max(0,a),b];
  if(Number.isFinite(a)&&Number.isFinite(b)&&b>a) return [Math.max(0,a),b];
  const st=Number(s?.start||0), en=Number(s?.end||0);
  return [Math.max(0,st),Math.max(st+0.05,en)];
}
function speechSpan(s){
  const a=Number(s.speechStart);
  const b=Number(s.speechEnd);
  if(Number.isFinite(a)&&Number.isFinite(b)&&b>a) return [Math.max(0,a),b];
  const words=Array.isArray(s.words)?s.words:[];
  const ws=words.map(w=>Number(w?.start)).filter(Number.isFinite);
  const we=words.map(w=>Number(w?.end)).filter(Number.isFinite);
  if(ws.length&&we.length){ const x=Math.min(...ws), y=Math.max(...we); if(y>x) return [x,y]; }
  return [Number(s.start||0), Number(s.end||Math.max(.05,Number(s.start||0)+.05))];
}
function drawTimeline(){ if(!canvas||!tlScroll.clientWidth||tlScroll.clientHeight<10) return; const g=tlGeom(); $('#tlSpacer').style.width=Math.max(g.total*S.pps,400)+'px'; const dpr=window.devicePixelRatio||1; if(canvas.width!==g.w*dpr||canvas.height!==g.h*dpr){ canvas.width=g.w*dpr; canvas.height=g.h*dpr; canvas.style.width=g.w+'px'; canvas.style.height=g.h+'px'; } const ctx=canvas.getContext('2d'); ctx.setTransform(dpr,0,0,dpr,0,0); const cs=getComputedStyle(document.documentElement); const C=k=>cs.getPropertyValue(k).trim(); const sl=tlScroll.scrollLeft; const x=tm=>tm*S.pps-sl; const dark=document.documentElement.classList.contains('dark');
  ctx.clearRect(0,0,g.w,g.h); ctx.fillStyle=C('--timeline-bg'); ctx.fillRect(0,0,g.w,g.h); ctx.fillStyle=dark?'rgba(255,255,255,.04)':'rgba(0,0,0,.04)'; ctx.fillRect(0,0,g.w,RULER);
  const step=S.pps>=120?1:S.pps>=60?2:S.pps>=30?5:S.pps>=15?10:30; ctx.font='10px '+C('--font-mono'); ctx.textBaseline='top'; for(let s=0;s<=g.total;s+=step){ const px=x(s); if(px<-40||px>g.w+40) continue; ctx.strokeStyle=C('--border'); ctx.beginPath(); ctx.moveTo(px+.5,RULER-6); ctx.lineTo(px+.5,g.h); ctx.stroke(); ctx.fillStyle=C('--muted-foreground'); ctx.fillText(fmt(s,0),px+4,6); }
  for(let i=1;i<=3;i++){ ctx.strokeStyle=C('--border'); ctx.beginPath(); ctx.moveTo(0,RULER+i*g.rowH-.5); ctx.lineTo(g.w,RULER+i*g.rowH-.5); ctx.stroke(); }
  const vy=RULER+4, vh=g.rowH-8, vw=(S.dur||g.total)*S.pps; const grad=ctx.createLinearGradient(x(0),0,x(0)+vw,0); grad.addColorStop(0,C('--video-track-from')); grad.addColorStop(1,C('--video-track-to')); rr(ctx,x(0),vy,vw,vh,6); ctx.fillStyle=grad; ctx.fill(); ctx.fillStyle=C('--video-track-text'); ctx.font='600 11px '+C('--font-sans'); ctx.textBaseline='middle'; ctx.fillText(S.p?S.p.name:'',Math.max(x(0)+10,10),vy+vh/2,Math.max(0,vw-20));
  const clip=(row,s,e,color,label,selected,dashed)=>{ const y=RULER+row*g.rowH+5, hh=g.rowH-10, px=x(s), pw=Math.max(1,(e-s)*S.pps-1); if(px+pw<0||px>g.w) return; rr(ctx,px,y,pw,hh,5); ctx.fillStyle=color; ctx.globalAlpha=dashed?.25:.45; ctx.fill(); ctx.globalAlpha=1; ctx.lineWidth=selected?2:1; ctx.strokeStyle=selected?C('--primary'):color; if(dashed) ctx.setLineDash([4,3]); ctx.stroke(); ctx.setLineDash([]); if(pw>24){ ctx.save(); ctx.beginPath(); ctx.rect(px+6,y,pw-12,hh); ctx.clip(); ctx.fillStyle=C('--foreground'); ctx.font='11px '+C('--font-sans'); ctx.textBaseline='middle'; ctx.fillText(label,px+7,y+hh/2); ctx.restore(); } };
  S.segs.forEach(s=>{ const [a,b]=subtitleSpan(s); if(s.txStatus==='done') clip(1,a,b,C('--neon-cyan'),s.txt,S.sel===s.id,false); else clip(1,a,b,C('--muted-foreground'),s.src,S.sel===s.id,true); });
  S.segs.forEach(s=>{ if(s.dubStatus==='done'){ const [a,b]=dubSpan(s); clip(2,a,b,C('--neon-magenta'),(s.speed&&s.speed!==1?`${s.speed.toFixed(2)}x · `:'')+s.txt,S.sel===s.id,false); } else if(s.dubStatus==='running'){ const [a,b]=speechSpan(s); clip(2,a,b,C('--neon-violet'),t('Đang tạo…','Generating…'),false,true); } });
  const ph=x(S.time); ctx.strokeStyle=C('--destructive'); ctx.lineWidth=1.5; ctx.beginPath(); ctx.moveTo(ph,0); ctx.lineTo(ph,g.h); ctx.stroke(); ctx.fillStyle=C('--destructive'); ctx.beginPath(); ctx.moveTo(ph-6,0); ctx.lineTo(ph+6,0); ctx.lineTo(ph,8); ctx.closePath(); ctx.fill(); }
function rr(ctx,x,y,w,h,r){ ctx.beginPath(); ctx.moveTo(x+r,y); ctx.arcTo(x+w,y,x+w,y+h,r); ctx.arcTo(x+w,y+h,x,y+h,r); ctx.arcTo(x,y+h,x,y,r); ctx.arcTo(x,y,x+w,y,r); ctx.closePath(); }
function hit(px,py){ const g=tlGeom(); const tm=(px+tlScroll.scrollLeft)/S.pps; if(py<RULER) return {zone:'ruler',tm}; const row=Math.floor((py-RULER)/g.rowH); if(row===1){ const s=S.segs.find(s=>{ const [a,b]=subtitleSpan(s); return tm>=a&&tm<=b; }); if(s){ const [a,b]=subtitleSpan(s); const l=a*S.pps-tlScroll.scrollLeft, r=b*S.pps-tlScroll.scrollLeft; return {zone:'sub',seg:s,tm,edge:px-l<7?'left':r-px<7?'right':null}; } return {zone:'sub',tm}; } if(row===2){ const s=S.segs.find(s=>{ if(s.dubStatus!=='done') return false; const [a,b]=dubSpan(s); return tm>=a&&tm<=b; }); if(s){ const [a,b]=dubSpan(s); const l=a*S.pps-tlScroll.scrollLeft, r=b*S.pps-tlScroll.scrollLeft; return {zone:'dub',seg:s,tm,edge:px-l<7?'left':r-px<7?'right':null}; } return {zone:'dub',tm}; } return {zone:'video',tm}; }
canvas.addEventListener('pointerdown',e=>{ if(e.button!==0) return; const r=canvas.getBoundingClientRect(); const px=e.clientX-r.left, py=e.clientY-r.top; const ht=hit(px,py); canvas.setPointerCapture(e.pointerId); e.preventDefault();
  if(ht.zone==='ruler'){ seekTo(ht.tm); drag={mode:'scrub'}; return; } if(ht.seg){ selectSeg(ht.seg.id,{seek:true,scroll:true}); if(ht.zone==='sub'&&S.p?.subtitleSource==='ocr'){ drag=null; return; } const [a,b]=dubSpan(ht.seg); const [sa,se]=subtitleSpan(ht.seg); drag={mode:ht.edge||'move',zone:ht.zone,seg:ht.seg,x0:e.clientX,s0:ht.zone==='sub'?sa:a,e0:ht.zone==='sub'?se:b,sp0:ht.seg.speed||1,moved:false}; return; } drag={mode:'pan',x0:e.clientX,sl0:tlScroll.scrollLeft}; });
canvas.addEventListener('pointermove',e=>{ const r=canvas.getBoundingClientRect(); const px=e.clientX-r.left, py=e.clientY-r.top; if(!drag){ const ht=hit(px,py); canvas.style.cursor=ht.zone==='ruler'?'crosshair':ht.seg?(ht.edge?'ew-resize':'grab'):'default'; return; }
  if(drag.mode==='scrub'){ seekTo(Math.max(0,(px+tlScroll.scrollLeft)/S.pps)); return; } if(drag.mode==='pan'){ tlScroll.scrollLeft=drag.sl0-(e.clientX-drag.x0); drawTimeline(); return; }
  const d=(e.clientX-drag.x0)/S.pps; if(Math.abs(e.clientX-drag.x0)>3) drag.moved=true; const s=drag.seg;
  if(drag.zone==='sub'){ if(drag.mode==='move'){ const len=drag.e0-drag.s0; s.start=clamp(drag.s0+d,0,Math.max(0,tlGeom().total-len)); s.end=s.start+len; } else if(drag.mode==='left') s.start=clamp(drag.s0+d,0,drag.e0-.1); else s.end=Math.max(drag.s0+.1,drag.e0+d); }
  else { const [da,db]=dubSpan(s); const base=Math.max(.2,db-da); if(drag.mode==='move') s.dubStart=Math.max(0,drag.s0+d); else if(drag.mode==='right'){ const newLen=Math.max(.2,base+d); s.dubDuration=newLen; } else { const ns=Math.max(0,drag.s0+d); const newLen=Math.max(.2,db-ns); s.dubStart=ns; s.dubDuration=newLen; } }
  drawTimeline(); });
const endDrag=()=>{ if(!drag) return; const d=drag; drag=null; if(d.seg&&d.moved){ if(d.zone==='sub') updateTiming(d.seg.id,d.seg.start,d.seg.end); else { d.seg.speed=Math.round(d.seg.speed*100)/100; api.updateSegment(S.p.id,d.seg.id,{speed:d.seg.speed}).catch(()=>toast(t('Lưu tốc độ audio thất bại','Failed to save audio speed'),'error')); renderSegList(); } } else if(d.seg&&!d.moved) seekTo(d.zone==='sub'?subtitleSpan(d.seg)[0]:dubSpan(d.seg)[0]); drawTimeline(); };
canvas.addEventListener('pointerup',endDrag); canvas.addEventListener('pointercancel',endDrag);
canvas.addEventListener('contextmenu',e=>{ e.preventDefault(); const r=canvas.getBoundingClientRect(); const ht=hit(e.clientX-r.left,e.clientY-r.top); if(!ht.seg) return; closeMenus(); const s=ht.seg; const menu=h('div',{class:'menu',style:{position:'fixed',left:Math.min(e.clientX,window.innerWidth-200)+'px',top:Math.min(e.clientY,window.innerHeight-140)+'px',zIndex:90,minWidth:'190px'}}); const item=(label,fn,danger)=>h('div',{class:'menu-item',style:danger?{color:'#f87171'}:null,onClick:()=>{closeMenus();fn();}},label);
  if(ht.zone==='sub'&&S.p.subtitleSource==='ocr'){ menu.append(item('lock',t('OCR MASTER TIMELINE đã khóa theo frame','OCR MASTER TIMELINE is frame-locked'),()=>{},false)); menu.append(item('play',t('Tới thời điểm phụ đề','Seek to subtitle'),()=>seekTo(subtitleSpan(s)[0]),false)); } else {
    if(ht.zone==='sub'&&s.txt&&isLong(s)) menu.append(item(t('Tách thành 2 phân đoạn','Split into 2 segments'),()=>splitSeg(s.id)));
    menu.append(item(ht.zone==='dub'?t('Chỉnh thời gian & tốc độ','Edit timing & speed'):t('Chỉnh thời gian','Edit timing'),()=>editTiming(s,ht.zone)));
    menu.append(item(ht.zone==='dub'?t('Xóa audio khỏi timeline','Remove audio from timeline'):t('Xóa khỏi timeline','Remove from timeline'),()=>{ if(ht.zone==='dub'){ s.dubStatus='none'; api.updateSegment(S.p.id,s.id,{has_dubbing:false}).catch(()=>{}); } else { s.txt=''; s.txStatus='pending'; s.dubStatus='none'; api.updateSegment(S.p.id,s.id,{translated_text:''}).catch(()=>{}); } renderSegList(); drawTimeline(); updateSub(); },true));
  }
  $('#layers').append(menu); S.ctxMenu=menu; setTimeout(()=>document.addEventListener('mousedown',outsideMenu),0); });
tlScroll.addEventListener('scroll',drawTimeline); tlScroll.addEventListener('wheel',e=>{ if(e.ctrlKey||e.metaKey){ e.preventDefault(); S.pps=clamp(S.pps*(e.deltaY<0?1.15:.87),8,240); drawTimeline(); } else if(Math.abs(e.deltaY)>Math.abs(e.deltaX)) tlScroll.scrollLeft+=e.deltaY; },{passive:false});
new ResizeObserver(()=>{fitStageToContainer();drawTimeline();layoutOverlays();}).observe(tlScroll); window.addEventListener('resize',()=>{fitStageToContainer();layoutOverlays();drawTimeline();});
function editTiming(s,zone){ if(zone==='sub'&&S.p?.subtitleSource==='ocr'){ dialog({title:t('Timeline OCR đã khóa','OCR timeline is locked'),desc:t('Start/end được lấy từ frame thật của phụ đề burn-in. Hãy chỉnh ROI và chạy OCR lại thay vì sửa timing thủ công.','Start/end come from the actual hard-subtitle frames. Adjust the ROI and rerun OCR instead of editing timing manually.'),footer:close=>[btn({v:'primary',label:t('Đã hiểu','OK'),onClick:close})]}); return; } const [ds]=dubSpan(s); const st=h('input',{class:'input mono',value:(zone==='dub'?ds:s.start).toFixed(2)}), en=h('input',{class:'input mono',value:s.end.toFixed(2)}), sp=h('input',{class:'input mono',value:(s.speed||1).toFixed(2)}); const body=h('div',{style:{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'10px'}},h('div',{class:'field'},h('div',{class:'lbl mu'},h('span',null,t('Bắt đầu (giây)','Start (sec)'))),st),zone==='dub'?h('div',{class:'field'},h('div',{class:'lbl mu'},h('span',null,t('Tốc độ phát (0.25 – 4.0)','Playback speed (0.25 – 4.0)'))),sp):h('div',{class:'field'},h('div',{class:'lbl mu'},h('span',null,t('Kết thúc (giây)','End (sec)'))),en));
  dialog({title:zone==='dub'?t('Chỉnh thời gian & tốc độ','Edit timing & speed'):t('Chỉnh thời gian','Edit timing'),body,footer:close=>[
    zone==='sub'?btn({v:'ghost',sm:false,icon:'trash',label:t('Xóa phân đoạn','Delete segment'),cls:'',attrs:{style:'color:var(--destructive);margin-right:auto'},onClick:()=>{close();deleteSeg(s.id);}}):null,
    btn({v:'ghost',sm:false,label:t('Hủy','Cancel'),onClick:close}),
    btn({v:'primary',sm:false,label:t('Lưu','Save'),onClick:()=>{ if(zone==='dub'){ s.dubStart=Math.max(0,Number(st.value)||0); s.speed=clamp(Number(sp.value)||1,.25,4); api.updateSegment(S.p.id,s.id,{speed:s.speed,dub_start_sec:s.dubStart}).catch(()=>{}); drawTimeline(); renderSegList(); } else { const a=Math.max(0,Number(st.value)||0), b=Math.max(a+.1,Number(en.value)||a+1); updateTiming(s.id,a,b); } close(); }})
  ].filter(Boolean)}); }

/* =========================================================
   10) KẾT XUẤT, TIẾN TRÌNH, KẾT QUẢ
   ========================================================= */
function openRenderDialog(){ const p=S.p; const r=p.render; if(!isPaid()) r.quality='720p'; const row=(label,desc,on,fn)=>h('div',{class:'field'},h('div',{class:'lbl'},h('span',null,label)),h('div',{style:{display:'flex',alignItems:'center',justifyContent:'space-between',marginTop:'4px'}},h('span',{style:{fontSize:'13px',color:'var(--muted-foreground)'}},desc),sw(on,fn)));
  const body=h('div',{style:{display:'flex',flexDirection:'column',gap:'18px'}}); const persist=()=>saveSettings({render:{include_subtitle:r.withSub,include_dubbing:r.withDub,quality:r.quality,reduce_original_voice:!!r.reduceOriginalVoice,original_voice_reduction:!!r.reduceOriginalVoice?0.65:0}});
  const rebuild=()=>{ body.innerHTML=''; body.append(row(t('Phụ đề','Subtitles'),t('Nhúng phụ đề vào video','Burn subtitles into the video'),r.withSub,v=>{r.withSub=v;persist();rebuild();}),row(t('Lồng tiếng','Dubbing'),t('Thêm âm thanh lồng tiếng AI','Include the AI dubbing audio'),r.withDub,v=>{r.withDub=v;persist();rebuild();}),row(t('Giảm giọng gốc','Reduce original speech'),t('Giảm âm giọng người nói gốc, vẫn giữ phần nền ở mức đang trộn','Lower original speech volume while retaining the mixed background'),!!r.reduceOriginalVoice,v=>{r.reduceOriginalVoice=v;persist();rebuild();}));
    const q=h('div',{class:'field'},h('div',{class:'lbl'},h('span',{style:{display:'flex',alignItems:'center',gap:'6px'}},t('Chất lượng xuất','Export quality'),isPaid()?null:h('span',{class:'max-tag'},'Pro+'))),h('div',{style:{marginTop:'4px',opacity:isPaid()?1:.45,pointerEvents:isPaid()?'auto':'none'}},sel([['720p','720p HD'],['1080p','1080p Full HD'],['4k','4K Ultra HD']],r.quality,v=>{r.quality=v;persist();}))); if(!isPaid()) q.append(h('div',{class:'hint',style:{fontSize:'12px'}},t('Nâng cấp lên Pro để chọn chất lượng cao hơn.','Upgrade to Pro to unlock higher quality.'))); body.append(q); }; rebuild();
  dialog({title:t('Kết xuất video','Render video'),desc:t('Chọn tùy chọn cho file xuất cuối cùng','Choose options for the final export'),body,footer:close=>[btn({v:'outline',sm:false,label:t('Hủy','Cancel'),onClick:close}),btn({v:'primary',sm:false,icon:'film',label:t('Bắt đầu kết xuất','Start render'),onClick:()=>{ close(); runJob('render',{include_subtitle:r.withSub,include_dubbing:r.withDub,quality:r.quality,orig_volume:S.vol.orig/100,dub_volume:S.vol.dub/100,reduce_original_voice:!!r.reduceOriginalVoice,original_voice_reduction:!!r.reduceOriginalVoice?0.65:0},t('Đang kết xuất','Rendering')); }})]}); }
let procClose=null;
function showProcessing(){ closeProcessing(); const wrap=h('div',{class:'overlay'},h('div',{class:'proc',id:'procCard'})); $('#layers').append(wrap); procClose=()=>{wrap.remove();procClose=null;}; renderProcessing(); }
function closeProcessing(){ procClose&&procClose(); }
function renderProcessing(){ const card=$('#procCard'); if(!card||!S.p) return; const p=S.p; card.innerHTML=''; const isTr=S.busyJob==='transcribe'; const stages=isTr?(p.subtitleSource==='ocr'?[['QUEUING','clock',t('Đang chờ trong hàng đợi','Waiting in queue')],['OCR_SCAN','captions',t('Quét ROI phụ đề','Scan subtitle ROI')],['OCR_RECOGNITION','captions',t('Adaptive OCR + khóa frame','Adaptive OCR + frame lock')]]:[['QUEUING','clock',t('Đang chờ trong hàng đợi','Waiting in queue')],['EXTRACT_AUDIO','audio',t('Tách âm thanh','Extract audio')],['STT','mic',t('Nhận dạng giọng nói','Transcribe')]]):[['QUEUING','clock',t('Đang chờ trong hàng đợi','Waiting in queue')],['RENDER','film',t('Kết xuất video','Render video')]]; let ai=stages.findIndex(s=>s[0]===p.stage); if(ai<0) ai=p.subtitleSource==='ocr'&&p.stage==='OCR'?2:0; const done=!busy()&&p.status!=='FAILED'&&p.status!=='CANCELLED';
  card.append(h('div',{class:'orb'},ic(done?'check':p.status==='FAILED'?'alert':stages[ai][1],38,done||p.status==='FAILED'?'':'')),h('div',null,h('div',{style:{fontWeight:700,fontSize:'18px',marginBottom:'6px'}},done?t('Hoàn thành!','All done!'):p.status==='FAILED'?t('Xử lý thất bại','Processing failed'):p.stage==='QUEUING'?(p.queuePosition?t(`Đang chờ trong hàng đợi… (vị trí #${p.queuePosition})`,`Waiting in queue… (#${p.queuePosition})`):t('Đang chờ trong hàng đợi…','Waiting in queue…')):stages[ai][2]),h('div',{class:'muted',style:{fontSize:'13px'}},p.name)));
  if(!done&&p.status!=='FAILED') card.append(h('div',{style:{width:'100%'}},h('div',{class:'progress'},h('i',{style:{width:p.progress+'%'}})),h('div',{class:'mono muted',style:{marginTop:'8px',fontSize:'12px',textAlign:'right'}},p.progress+'%')));
  if(p.status==='FAILED'&&p.error) card.append(h('div',{style:{width:'100%',textAlign:'left',fontSize:'13px',color:'var(--destructive)',background:'color-mix(in oklch, var(--destructive) 10%, transparent)',padding:'8px 14px',borderRadius:'8px'}},p.error));
  card.append(h('div',{class:'stage-list'},stages.map((s,i)=>h('div',{class:'stage-item','data-s':done||i<ai?'done':i===ai?'active':''},ic(done||i<ai?'check':s[1],15,i===ai&&!done&&p.status!=='FAILED'?'spin':''),s[2]))));
  if(busy()) card.append(btn({v:'outline',sm:false,icon:'x',label:t('Hủy tác vụ','Cancel job'),cls:'btn-block',onClick:cancelJob})); else card.append(btn({v:'ghost',sm:false,label:t('Đóng','Close'),onClick:closeProcessing})); }
const ARTS=()=>[['video_final','sparkles',t('Video cuối cùng','Final video'),t('Video hoàn chỉnh với phụ đề/lồng tiếng','Complete video with subs/dubbing')],['translated_srt','languages',t('Phụ đề đã dịch (SRT)','Translated SRT'),t('Phụ đề ngôn ngữ đích','Target language subtitles')],['transcript_srt','captions',t('Phụ đề gốc (SRT)','Source SRT'),t('Phụ đề ngôn ngữ nguồn','Source language subtitles')],['audio_dubbing','volume',t('Âm thanh lồng tiếng','Dubbed audio'),t('File MP3 AI lồng tiếng','AI-dubbed audio track')],['audio_original','audio',t('Âm thanh gốc','Original audio'),t('Âm thanh tách từ video gốc','Audio extracted from the original')],['video_original','film',t('Video gốc','Original video'),t('Video nguồn đã tải lên','Uploaded source video')],['project_config','settings',t('Cấu hình dự án (YAML)','Project config (YAML)'),t('Toàn bộ cài đặt và phân đoạn','All settings and segments')]];
async function showResults(){ let links; try{ links=await api.getLinks(S.p.id); }catch(e){ toast(t('Không tải được link tải xuống','Could not load download links'),'error'); return; } const avail=ARTS().filter(a=>links[a[0]]); const body=h('div',{style:{display:'flex',flexDirection:'column',gap:'8px'}});
  if(links.video_final) body.append(h('video',{src:(api.videoUrl?api.videoUrl(S.p.id):links.video_final),controls:true,preload:'metadata',style:{width:'100%',maxWidth:'100%',height:'auto',maxHeight:'52vh',objectFit:'contain',display:'block',margin:'0 auto',borderRadius:'8px',background:'#000'}}));
  avail.forEach(([k,icon,title,desc])=>body.append(h('div',{class:'art'},h('span',{class:'ic'},ic(icon,15)),h('div',{class:'grow'},h('b',null,title),h('small',null,desc)),h('a',{class:'btn btn-outline btn-sm',href:links[k],download:true,target:'_blank',rel:'noreferrer'},ic('download',13),h('span',null,t('Tải','Get'))))));
  if(!avail.length) body.append(h('div',{class:'muted',style:{textAlign:'center',padding:'12px'}},t('Chưa có file nào sẵn sàng.','No files available yet.')));
  body.append(h('div',{class:'muted',style:{display:'flex',alignItems:'center',gap:'6px',fontSize:'12px'}},ic('clock',13),t('Link tải có hiệu lực 7 ngày','Download links stay valid for 7 days')));
  dialog({title:t('Kết quả & tải xuống','Results & downloads'),desc:S.p.name,body,width:560,footer:close=>[btn({v:'outline',sm:false,icon:'download',label:t('Tải tất cả (ZIP)','Download all (ZIP)'),onClick:async()=>{ try{ const u=await api.getZip(S.p.id); if(u&&u!=='#') window.open(u,'_blank'); else toast(t('Bản demo không có file ZIP thật.','The demo has no real ZIP file.'),'info'); }catch(e){toast(e.message,'error');} }}),btn({v:'primary',sm:false,label:t('Đóng','Close'),onClick:close})]}); }

/* =========================================================
   11) TOUR HƯỚNG DẪN (spotlight)
   ========================================================= */
let tourState=null;
function tourSteps(){ const m=isMobile(); const openMenu=()=>{ if(!S.ctxMenu){ const b=$('[data-tour="segment-more-actions"]'); b&&openMoreMenu(b); } moreMenuKeepOpen=true; }; const closeMenu=()=>{ moreMenuKeepOpen=false; closeMenus(); };
  return [
    {sel:'[data-tour="timeline"]',title:t('Dòng thời gian','Timeline'),body:t('Video, phụ đề và lồng tiếng nằm trên 3 track. Kéo khối để dời, kéo mép để đổi thời lượng, chuột phải để xem thêm.','Video, subtitles and dubbing live on three tracks. Drag a block to move it, drag its edges to retime, right-click for more.'),onEnter:()=>{closeMenu(); if(!m&&!S.tlOpen){S.tlOpen=true;renderTlHead();setTimeout(drawTimeline,220);} if(m){S.mtab='timeline';applyMobile();}}},
    {sel:'[data-tour="timeline-volume"]',title:t('Âm lượng','Volume'),body:t('Chỉnh âm lượng của tiếng gốc và tiếng lồng khi xem trước — mức này cũng dùng khi kết xuất.','Balance the original and dubbed audio while previewing — the same mix is used when rendering.'),skip:m},
    {sel:'[data-tour="segment-panel-header"]',title:t('Phân đoạn','Segments'),body:t('Mỗi câu thoại là một phân đoạn: xem văn bản gốc, sửa bản dịch và tạo lồng tiếng ngay tại đây.','Each line of speech is a segment: read the source, edit the translation and create dubbing right here.'),onEnter:()=>{closeMenu(); if(m){S.mtab='segment';applyMobile();}}},
    {sel:'[data-tour="segment-lang-toggle"]',title:t('Ngôn ngữ & tìm kiếm','Language & search'),body:t('Bấm để đổi ngôn ngữ nguồn/đích hoặc tìm nhanh một câu.','Tap to change the source/target languages or search for a line.')},
    {sel:'[data-tour="segment-lang-row"]',title:t('Chọn ngôn ngữ','Pick languages'),body:t('Đổi ngôn ngữ đích rồi bấm "Dịch tất cả" để dịch lại toàn bộ.','Change the target language, then use "Translate all" to redo the translation.'),onEnter:()=>{ if(!S.showLang){S.showLang=true;renderSegs();} }},
    {sel:'[data-tour="segment-add-btn"]',title:t('Thêm phân đoạn','Add a segment'),body:t('Chèn một câu mới vào đầu video; dùng menu ⋮ trên timeline để tách hoặc gộp.','Insert a new line at the start; use the timeline context menu to split or merge.')},
    {sel:'[data-tour="segment-translate-btn"]',title:t('Dịch từng câu','Translate a line'),body:t('Dịch hoặc dịch lại riêng câu này bằng nhà cung cấp đã chọn trong Cài đặt.','Translate or re-translate just this line with the provider chosen in Settings.')},
    {sel:'[data-tour="segment-dub-btn"]',title:t('Lồng tiếng từng câu','Dub a line'),body:t('Tạo giọng đọc AI cho câu đã dịch. Nghe thử bằng nút ▶ bên cạnh.','Generate the AI voice for the translated line. Preview it with the ▶ button next to it.')},
    {sel:'[data-tour="segment-delete-btn"]',title:t('Xóa phân đoạn','Delete a segment'),body:t('Bỏ hẳn câu này khỏi dự án (kèm bản dịch và lồng tiếng).','Remove this line from the project, including its translation and dubbing.')},
    {sel:'[data-tour="segment-more-actions"]',title:t('Thao tác hàng loạt','Bulk actions'),body:t('Dịch tất cả, lồng tiếng tất cả và các thao tác dọn dẹp nằm trong menu này.','Translate all, dub all and clean-up actions live in this menu.'),onEnter:openMenu},
    {sel:'[data-tour="menu-translate-all"]',title:t('Dịch tất cả','Translate all'),body:t('Dịch mọi câu chưa có bản dịch trong một lượt; tiến độ hiện ngay trong menu.','Translates every untranslated line in one go; progress shows inside the menu.'),onEnter:openMenu},
    {sel:'[data-tour="menu-dub-all"]',title:t('Lồng tiếng tất cả','Dub all'),body:t('Tạo giọng đọc cho toàn bộ câu đã dịch.','Generates voices for every translated line.'),onEnter:openMenu},
    {sel:'[data-tour="menu-fit-dubbing"]',title:t('Khớp thời lượng','Fit duration'),body:t('Tự động tăng tốc audio lồng để không tràn sang câu kế tiếp.','Automatically speeds up dubbing so it never spills into the next line.'),onEnter:openMenu},
    {sel:'[data-tour="menu-split-all"]',title:t('Tách câu dài','Split long lines'),body:t('Chia các câu quá dài thành hai phân đoạn để phụ đề gọn trên một dòng.','Splits overly long lines into two segments so subtitles fit on one line.'),onEnter:openMenu},
    {sel:'[data-tour="menu-clear-tx"]',title:t('Xóa bản dịch','Clear translations'),body:t('Xóa toàn bộ bản dịch để bắt đầu lại.','Delete every translation to start over.'),onEnter:openMenu},
    {sel:'[data-tour="menu-clear-dub"]',title:t('Xóa lồng tiếng','Clear dubbing'),body:t('Xóa toàn bộ audio lồng tiếng, giữ nguyên bản dịch.','Delete all dubbing audio while keeping the translations.'),onEnter:openMenu},
    {sel:'[data-tour="menu-reset-all"]',title:t('Khôi phục gốc','Reset'),body:t('Quay về đúng transcript ban đầu sau khi nhận dạng.','Go back to the original transcript from recognition.'),onEnter:openMenu},
    {sel:'[data-tour="style-box"]',title:t('Kiểu phụ đề','Subtitle style'),body:t('Kéo khung nét đứt để dời phụ đề, kéo góc để đổi cỡ. Panel bên phải có phông, màu, nền và hiệu ứng.','Drag the dashed box to move the subtitle, drag a corner to resize. The right panel has fonts, colors, backgrounds and effects.'),onEnter:()=>{ closeMenu(); openSide('style'); if(!S.sel&&S.segs[0]) selectSeg(S.segs[0].id); updateSub(); refreshDragBoxes(); }},
    {sel:'[data-tour="transcript-panel"]',title:t('Phụ đề gốc','Transcript'),body:t('Chạy lại nhận dạng bằng giọng nói (STT) hoặc đọc phụ đề cứng (OCR).','Re-run recognition from speech (STT) or from burned-in subtitles (OCR).'),onEnter:()=>openSide('transcript')},
    {sel:'[data-tour="settings-panel"]',title:t('Cài đặt','Settings'),body:t('Chọn nhà cung cấp nhận dạng, dịch, lồng tiếng; thêm prompt và từ điển riêng cho dự án.','Choose recognition, translation and dubbing providers; add a project prompt and glossary.'),onEnter:()=>openSide('settings')},
    {sel:'[data-tour="speakers-panel"]',title:t('Người nói','Speakers'),body:t('Phân tích giọng để tách người nói và gán giọng lồng riêng (gói Max).','Analyze voices to separate speakers and assign each a voice (Max plan).'),onEnter:()=>openSide('speakers')},
    {sel:'[data-tour="visual-context-panel"]',title:t('Bối cảnh','Visual context'),body:t('AI mô tả hình ảnh của video để dịch sát ngữ cảnh hơn (gói Max).','The AI describes the video\'s visuals for more context-aware translation (Max plan).'),onEnter:()=>openSide('visual')},
  ].filter(s=>!s.skip); }
function startTour(){ endTour(); const steps=tourSteps(); tourState={steps,i:0,mask:h('div',{class:'tour-mask',onClick:endTour}),hole:h('div',{class:'tour-hole'}),card:h('div',{class:'tour-card'})}; $('#layers').append(tourState.mask,tourState.hole,tourState.card); showTourStep(0); tourState.timer=setInterval(placeTour,200); window.addEventListener('keydown',tourKey); }
function tourKey(e){ if(e.key==='Escape') endTour(); }
function endTour(){ if(!tourState) return; clearInterval(tourState.timer); tourState.mask.remove(); tourState.hole.remove(); tourState.card.remove(); tourState=null; moreMenuKeepOpen=false; closeMenus(); window.removeEventListener('keydown',tourKey); store.set('atv_tour_editor','1'); }
function showTourStep(i){ const ts=tourState; ts.i=i; const st=ts.steps[i]; st.onEnter&&st.onEnter(); const last=i===ts.steps.length-1; ts.card.innerHTML=''; ts.card.append(h('div',{class:'tt'},st.title),h('div',{class:'tb'},st.body),h('div',{class:'tf'},h('span',{class:'muted',style:{fontSize:'12px'}},`${i+1} / ${ts.steps.length}`),h('div',{class:'grow'}),btn({icon:'x',title:t('Bỏ qua tất cả','Skip all'),onClick:endTour}),i>0?btn({v:'outline',icon:'chevLeft',onClick:()=>showTourStep(i-1)}):null,btn({v:'primary',label:last?t('Xong','Done'):t('Tiếp theo','Next'),onClick:()=>last?endTour():showTourStep(i+1)}))); setTimeout(placeTour,60); }
function placeTour(){ const ts=tourState; if(!ts) return; const el=document.querySelector(ts.steps[ts.i].sel); const r=el?el.getBoundingClientRect():null; if(!r||!r.width){ ts.hole.style.display='none'; Object.assign(ts.card.style,{left:'50%',top:'50%',transform:'translate(-50%,-50%)'}); return; } ts.hole.style.display='block'; Object.assign(ts.hole.style,{top:(r.top-8)+'px',left:(r.left-8)+'px',width:(r.width+16)+'px',height:(r.height+16)+'px'}); const cw=ts.card.offsetWidth||300, ch=ts.card.offsetHeight||160, W=window.innerWidth, H=window.innerHeight; let left,top; if(W-(r.right+8)>=cw+16){ left=r.right+16; top=clamp(r.top,16,H-ch-16); } else if(r.left-8>=cw+16){ left=r.left-8-cw-16; top=clamp(r.top,16,H-ch-16); } else { top=H-(r.bottom+8)>=ch+16?r.bottom+16:r.top-8>=ch+16?r.top-8-ch-16:16; left=clamp(r.left,16,W-cw-16); } Object.assign(ts.card.style,{left:left+'px',top:top+'px',transform:'none'}); }

/* =========================================================
   12) MOBILE TABS + KHỞI ĐỘNG
   ========================================================= */
function renderMtabs(){ const nav=$('#mtabs'); nav.innerHTML=''; [['timeline','film','Timeline'],['segment','menu',t('Đoạn','Segments')],['style','captions',t('Kiểu','Style')],['transcript','audio',t('Gốc','Transcript')],['speakers','user',t('Người nói','Speakers')],['visual','eye',t('Bối cảnh','Visual')],['settings','settings',t('Cài đặt','Settings')]].forEach(([k,i,l])=>nav.append(h('button',{type:'button','data-on':S.mtab===k,onClick:()=>{S.mtab=k;applyMobile();}},ic(i,16),h('span',null,l)))); }
function applyMobile(){ const m=isMobile(); renderMtabs();
  if(!S.p){ $('#tl').hidden=true; $('#mtabs').hidden=true; $('#segs').hidden=false; $('#side').hidden=true; return; }
  $('#mtabs').hidden=false;
  if(m){ $('#segs').hidden=S.mtab!=='segment'; $('#tl').hidden=S.mtab!=='timeline'; } else { $('#segs').hidden=false; $('#tl').hidden=false; } renderSide(); renderTlHead(); setTimeout(drawTimeline,50); }
window.addEventListener('resize',()=>{ renderTop(); applyMobile(); layoutOverlays(); });
function renderAll(){ document.documentElement.lang=lang; renderConnBar(); renderTop(); renderSegs(); renderCenter(); renderTlHead(); applyMobile(); drawTimeline(); if(S.p&&busy()) renderProcessing(); }

/* =========================================================
   13) KẾT NỐI BACKEND
   ========================================================= */
function renderConnBar(){ const bar=$('#connBar'); if(!bar) return; bar.innerHTML=''; const cfgLabel=CFG.apiBase||t('(chưa cấu hình)','(not configured)');
  const map={ offline:{s:'off',label:t('Chưa kết nối backend','Backend not connected'),sub:t('Đặt LINGVO_CONFIG.apiBase để tải dữ liệu thật.','Set LINGVO_CONFIG.apiBase to load real data.')},
    checking:{s:'checking',label:t('Đang kết nối…','Connecting…'),sub:cfgLabel},
    connected:{s:'on',label:t('Đã kết nối backend','Backend connected'),sub:cfgLabel},
    error:{s:'off',label:t('Không thể kết nối backend','Could not reach the backend'),sub:S.connError||cfgLabel},
    demo:{s:'demo',label:t('Đang xem dữ liệu minh hoạ','Previewing sample data'),sub:t('Chưa kết nối backend thật.','No real backend connected.')} };
  const info=map[S.conn]||map.offline;
  bar.hidden=!!S.connBarClosed;
  if(S.connBarClosed) return;
  bar.append(h('span',{class:'conn-dot','data-s':info.s}),h('span',{class:'conn-label'},info.label),h('span',{class:'conn-sub mono trunc'},info.sub),h('div',{class:'grow'}));
  if(S.conn==='offline') bar.append(btn({v:'outline',icon:'sparkles',label:t('Xem dữ liệu minh hoạ','Preview sample data'),onClick:()=>loadDemoPreview()}));
  if(S.conn==='error') bar.append(btn({v:'outline',icon:'refresh',label:t('Thử lại','Retry'),onClick:()=>connectBackend()}),btn({v:'ghost',icon:'sparkles',label:t('Xem dữ liệu minh hoạ','Preview sample data'),onClick:()=>loadDemoPreview()}));
  if(S.conn==='demo'&&CFG.apiBase) bar.append(btn({v:'outline',icon:'refresh',label:t('Kết nối backend thật','Connect real backend'),onClick:()=>connectBackend()}));
  bar.append(h('button',{type:'button',class:'conn-close',title:t('Đóng thông báo','Dismiss notice'),onClick:()=>{S.connBarClosed=true;renderConnBar();renderTop();}},ic('x',14)));
}
async function connectBackend(){
  if(!CFG.apiBase){ S.conn='offline'; renderConnBar(); return; }
  S.conn='checking'; S.connError=''; renderConnBar();
  try{
    const ctrl=new AbortController(); const timer=setTimeout(()=>ctrl.abort(),6000);
    try{ await fetch(CFG.apiBase+'/api/health',{method:'GET',signal:ctrl.signal}); }
    catch(err){ throw new Error(err&&err.name==='AbortError'?t('Hết thời gian chờ kết nối','Connection timed out'):t('Không thể kết nối tới máy chủ backend','Could not reach the backend server')); }
    finally{ clearTimeout(timer); }
    S.conn='connected'; renderConnBar(); api=httpApiInstance; await loadProjectData();
  }catch(e){ S.conn='error'; S.connError=e.message; renderConnBar(); renderAll(); }
}
function loadDemoPreview(){ S.conn='demo'; renderConnBar(); api=demoApiInstance; loadProjectData(); }
async function loadProjectData(){ const id=CFG.projectId||store.get('lingvo_project_id')||''; if(!id){ $('#segs').innerHTML=''; $('#segs').append(emptyState('alert',t('Chưa chọn dự án','No project selected'),t('Mở một dự án từ danh sách để vào editor.','Open a project from the project list to enter the editor.'),false)); renderCenter(); return; } CFG.projectId=id; store.set('lingvo_project_id',id);
  $('#segs').innerHTML=''; $('#segs').append(h('div',{style:{padding:'14px'}},...Array.from({length:4},()=>h('div',{style:{height:'110px',marginBottom:'10px',borderRadius:'8px',background:'var(--muted)'}}))));
  try{ const [p,segs0]=await Promise.all([api.getProject(id),api.getSegments(id)]); const rawProjectSegs=Array.isArray(p?.segments)?p.segments:[]; const txs=Array.isArray(p?.translated_texts)?p.translated_texts:[]; const segs=(segs0||[]).map((x,i)=>{const ps=rawProjectSegs[i]||{}; const src=x.src||ps.source_text||ps.text||ps.source||ps.original||ps.clean_text||''; const txt=x.txt||txs[i]||ps.translated_text||ps.translation||''; return Object.assign({},x,{src:String(src||''),txt:String(txt||''),txStatus:txt?'done':'pending'});}); if(!segs.length&&rawProjectSegs.length){ for(let i=0;i<rawProjectSegs.length;i++){ const ps=rawProjectSegs[i]||{}; const txt=txs[i]||ps.translated_text||ps.translation||''; segs.push(mapSeg(Object.assign({index:i},ps),txt)); } } S.segs=Array.isArray(segs)?segs:[]; S.p=Object.assign({},p,{translationMissingSegments:Array.isArray(p.translation_missing_segments)?p.translation_missing_segments:[]}); S.p.ocrRegion=normalizedOcrRegion(S.p.ocrRegion); S.sel=S.segs[0]?S.segs[0].id:null; S.vol={orig:p.render?.origVolume,dub:p.render?.dubVolume}; if(busy()){ S.busyJob=p.stage==='RENDER'||(p.stage==='QUEUING'&&p.latestOutputId==null)?'render':p.stage==='TTS'?'dub':p.stage==='STT'||p.stage==='EXTRACT_AUDIO'||p.stage==='OCR'?'transcribe':'translate'; startPolling(); } renderAll();
    api.getSettings().then(async s=>{ S.settings=s; try{ { const liveVoices=await api.getXkiraVoices(); XKIRA_VOICES=Array.isArray(liveVoices)?liveVoices.filter(v=>String(v.name||'').toLowerCase().includes('vietnamese')).slice(0,4):[]; } }catch(e){ XKIRA_VOICES=[]; } if(!s.providers.edgeVoice) s.providers.edgeVoice=voicesFor(p.tgt)[0][0]; if(!s.providers.xkiraVoice&&XKIRA_VOICES[0]) s.providers.xkiraVoice=XKIRA_VOICES[0].id; if(S.side&&S.sideKey==='settings') renderSide(); }).catch(()=>{ S.settings={providers:Object.assign({},DEFAULT_PROV),keys:{}}; });
    if(isMax()) ['voice','visual'].forEach(k=>api.getAnalysis(id,k).then(a=>{ S[k]=Object.assign({},S[k],a); if(a.status==='QUEUED'||a.status==='RUNNING') watchAnalysis(k); if(S.side&&S.sideKey===(k==='voice'?'speakers':'visual')) renderSide(); }).catch(()=>{}));
    if(!store.get('atv_tour_editor')) setTimeout(startTour,900); }
  catch(e){ S.p=null; renderSegs(); renderCenter(); $('#segs').innerHTML=''; $('#segs').append(emptyState('alert',t('Không tải được dự án','Could not load the project'),e.message||'',S.conn==='offline')); toast(e.message||t('Không tải được dự án.','Could not load the project.'),'error'); } }
async function init(){ renderConnBar(); renderTop(); renderTlHead(); renderMtabs(); renderSegs(); renderCenter(); applyMobile(); await connectBackend(); }
init();
})();
